import express from 'express';
import dotenv from 'dotenv';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import {
  runAIMentorAgent,
  runCareerMatchingAgent,
  runLearningRecommendationAgent,
  runProfileAnalysisAgent,
  runProgressEvaluationAgent,
  runSkillGapAnalysisAgent,
} from './server/agents.ts';
import type {
  AssessmentAttempt,
  LearnerProfile,
  LearningRoadmap,
  MentorMessage,
  SkillGapAnalysis,
  TopicPerformance,
  UserSkill,
} from './src/shared/types.ts';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

interface FirebaseAppletConfig {
  apiKey?: string;
  projectId?: string;
}

let firebaseApiKey = '';
try {
  const cfgPath = path.join(__dirname, 'firebase-applet-config.json');
  if (fs.existsSync(cfgPath)) {
    const parsed = JSON.parse(fs.readFileSync(cfgPath, 'utf-8')) as FirebaseAppletConfig;
    firebaseApiKey = parsed.apiKey ?? '';
  }
} catch {
  firebaseApiKey = '';
}

async function verifyRequestAuth(
  req: express.Request,
  res: express.Response,
  next: express.NextFunction,
): Promise<void> {
  const isDemo = req.headers['x-demo-mode'] === 'true';
  const isLocalWorkspace = req.headers['x-workspace-mode'] === 'local';
  if (isDemo || isLocalWorkspace) {
    next();
    return;
  }

  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    res.status(401).json({ error: 'Missing Authorization Bearer token.' });
    return;
  }

  const idToken = authHeader.slice('Bearer '.length).trim();
  if (!idToken || !firebaseApiKey) {
    res.status(401).json({ error: 'Invalid authentication configuration.' });
    return;
  }

  try {
    const lookupRes = await fetch(
      `https://identitytoolkit.googleapis.com/v1/accounts:lookup?key=${encodeURIComponent(firebaseApiKey)}`,
      {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ idToken }),
      },
    );
    if (!lookupRes.ok) {
      const errBody = await lookupRes.text().catch(() => '');
      console.warn('Firebase token verification rejected:', lookupRes.status, errBody);
      res.status(401).json({ error: 'Firebase ID token verification failed. Please refresh your session and sign in again.' });
      return;
    }
    const lookupData = (await lookupRes.json()) as { users?: Array<{ localId: string }> };
    const uid = lookupData.users?.[0]?.localId;
    if (!uid) {
      res.status(401).json({ error: 'Unrecognized Firebase user.' });
      return;
    }
    res.locals.uid = uid;
    next();
  } catch {
    res.status(401).json({ error: 'Unable to verify Firebase authentication token.' });
  }
}

async function startServer() {
  const app = express();
  app.use(express.json({ limit: '1mb' }));

  app.get('/api/health', (_req, res) => {
    res.json({
      ok: true,
      geminiConfigured: Boolean(process.env.GEMINI_API_KEY && process.env.GEMINI_API_KEY !== 'MY_GEMINI_API_KEY'),
      timestamp: new Date().toISOString(),
    });
  });

  app.post('/api/agents/profile-analysis', verifyRequestAuth, async (req, res) => {
    const { profile, skills } = req.body as { profile?: LearnerProfile; skills?: UserSkill[] };
    if (!profile || !Array.isArray(skills)) {
      res.status(400).json({ error: 'Invalid request payload: profile and skills are required.' });
      return;
    }
    const result = await runProfileAnalysisAgent(profile, skills);
    res.status(result.status === 'error' ? 502 : 200).json(result);
  });

  app.post('/api/agents/skill-gap', verifyRequestAuth, async (req, res) => {
    const { profile, skills } = req.body as { profile?: LearnerProfile; skills?: UserSkill[] };
    if (!profile || !Array.isArray(skills)) {
      res.status(400).json({ error: 'Invalid request payload: profile and skills are required.' });
      return;
    }
    const result = await runSkillGapAnalysisAgent(profile, skills);
    res.status(result.status === 'error' ? 502 : 200).json(result);
  });

  app.post('/api/agents/career-matching', verifyRequestAuth, async (req, res) => {
    const { profile, skills } = req.body as { profile?: LearnerProfile; skills?: UserSkill[] };
    if (!profile || !Array.isArray(skills)) {
      res.status(400).json({ error: 'Invalid request payload: profile and skills are required.' });
      return;
    }
    const result = await runCareerMatchingAgent(profile, skills);
    res.status(result.status === 'error' ? 502 : 200).json(result);
  });

  app.post('/api/agents/learning-recommendation', verifyRequestAuth, async (req, res) => {
    const {
      profile,
      skills,
      analysis,
      adaptiveMode,
      adaptationReason,
      focusSkillId,
      weakTopics,
      orchestratorContext,
    } = req.body as {
      profile?: LearnerProfile;
      skills?: UserSkill[];
      analysis?: SkillGapAnalysis;
      adaptiveMode?: LearningRoadmap['adaptiveMode'];
      adaptationReason?: string;
      focusSkillId?: string;
      weakTopics?: string[];
      orchestratorContext?: {
        profileStrategy?: string;
        gapSummary?: string;
        careerAdvice?: string;
      };
    };
    if (!profile || !Array.isArray(skills) || !analysis) {
      res.status(400).json({ error: 'Invalid request payload: profile, skills, and analysis are required.' });
      return;
    }
    const result = await runLearningRecommendationAgent(
      profile,
      skills,
      analysis,
      adaptiveMode,
      adaptationReason,
      focusSkillId,
      weakTopics,
      orchestratorContext,
    );
    res.status(result.status === 'error' ? 502 : 200).json(result);
  });

  app.post('/api/agents/progress-evaluation', verifyRequestAuth, async (req, res) => {
    const { profile, skill, score, topicBreakdown, weakTopics } = req.body as {
      profile?: LearnerProfile;
      skill?: UserSkill;
      score?: number;
      topicBreakdown?: TopicPerformance[];
      weakTopics?: string[];
    };
    if (!profile || !skill || typeof score !== 'number' || !Array.isArray(topicBreakdown)) {
      res.status(400).json({ error: 'Invalid request payload for progress evaluation.' });
      return;
    }
    const result = await runProgressEvaluationAgent({
      profile,
      skill,
      score,
      topicBreakdown,
      weakTopics: Array.isArray(weakTopics) ? weakTopics : [],
    });
    res.status(result.status === 'error' ? 502 : 200).json(result);
  });

  app.post('/api/agents/mentor', verifyRequestAuth, async (req, res) => {
    const { question, profile, skills, analysis, roadmap, attempts, history } = req.body as {
      question?: string;
      profile?: LearnerProfile;
      skills?: UserSkill[];
      analysis?: SkillGapAnalysis;
      roadmap?: LearningRoadmap | null;
      attempts?: AssessmentAttempt[];
      history?: MentorMessage[];
    };
    if (!question || !profile || !Array.isArray(skills) || !analysis) {
      res.status(400).json({ error: 'Invalid request payload for AI Mentor.' });
      return;
    }
    const result = await runAIMentorAgent({
      question,
      profile,
      skills,
      analysis,
      roadmap: roadmap ?? null,
      attempts: Array.isArray(attempts) ? attempts : [],
      history: Array.isArray(history) ? history : [],
    });
    res.status(result.status === 'error' ? 502 : 200).json(result);
  });

  const isProd = process.env.NODE_ENV === 'production';
  if (!isProd) {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distDir = path.join(__dirname, 'dist');
    app.use(express.static(distDir));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distDir, 'index.html'));
    });
  }

  const PORT = 3000;
  app.listen(PORT, '0.0.0.0', () => {
    console.log(`SkillPath AI server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
