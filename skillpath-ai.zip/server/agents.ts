import { GoogleGenAI, ThinkingLevel, Type } from '@google/genai';
import type {
  AgentName,
  AssessmentAttempt,
  CareerGoal,
  CareerMatchResult,
  LearnerProfile,
  LearningRoadmap,
  MentorMessage,
  SkillGapAnalysis,
  TopicPerformance,
  UserSkill,
} from '../src/shared/types.ts';
import { PROFICIENCY_LABELS } from '../src/shared/types.ts';
import { VERIFIED_RESOURCES } from '../src/shared/catalog.ts';
import {
  buildDeterministicRoadmapStages,
  calculateSkillGaps,
  determineAdaptiveMode,
  matchAllCareers,
} from '../src/shared/skillEngine.ts';

function getGeminiClient(): GoogleGenAI {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey || apiKey === 'MY_GEMINI_API_KEY') {
    throw new Error('GEMINI_API_KEY is not configured in server environment secrets.');
  }
  return new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

const PRIMARY_MODEL = 'gemini-4-hydrogen';
const FALLBACK_MODEL = 'gemini-3.1-flash-lite';

function sleep(ms: number) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

function stripJsonFences(raw: string): string {
  const trimmed = raw.trim();
  if (trimmed.startsWith('```')) {
    return trimmed.replace(/^```(?:json)?\s*/i, '').replace(/\s*```$/, '').trim();
  }
  return trimmed;
}

async function generateAgentContent(
  ai: GoogleGenAI,
  params: {
    contents: string;
    systemInstruction: string;
    responseSchema: Record<string, unknown>;
    thinkingLevel?: ThinkingLevel;
  },
) {
  const level = params.thinkingLevel ?? ThinkingLevel.LOW;

  const invokePrimary = () =>
    ai.models.generateContent({
      model: PRIMARY_MODEL,
      contents: params.contents,
      config: {
        thinkingConfig: { thinkingLevel: level },
        systemInstruction: params.systemInstruction,
        responseMimeType: 'application/json',
        responseSchema: params.responseSchema,
      },
    });

  const invokeFallback = () =>
    ai.models.generateContent({
      model: FALLBACK_MODEL,
      contents: params.contents,
      config: {
        systemInstruction: params.systemInstruction,
        responseMimeType: 'application/json',
        responseSchema: params.responseSchema,
      },
    });

  try {
    return await invokePrimary();
  } catch (err) {
    const msg = err instanceof Error ? err.message : String(err);

    if (msg.includes('503') || msg.includes('500') || msg.includes('UNAVAILABLE') || msg.includes('fetch')) {
      await sleep(400);
      try {
        return await invokePrimary();
      } catch {
        return await invokeFallback();
      }
    }

    try {
      return await invokeFallback();
    } catch {
      throw err;
    }
  }
}

export interface AgentResult<T> {
  agentName: AgentName;
  status: 'completed' | 'error';
  durationMs: number;
  inputSummary: string;
  outputSummary: string;
  data?: T;
  errorMessage: string;
}

export interface ProfileAnalysisOutput {
  headline: string;
  backgroundSummary: string;
  strengths: string[];
  learningStrategy: string;
}

export async function runProfileAnalysisAgent(
  profile: LearnerProfile,
  skills: UserSkill[],
): Promise<AgentResult<ProfileAnalysisOutput>> {
  const start = Date.now();
  const activeSkills = skills
    .filter((s) => s.proficiency > 0)
    .map((s) => `${s.skillName} (${PROFICIENCY_LABELS[s.proficiency]})`);
  const inputSummary = `Learner: ${profile.name} · Goal: ${profile.careerGoal} · Active skills: ${activeSkills.join(', ') || 'None'} · Projects: ${profile.projects.length}`;

  try {
    const ai = getGeminiClient();
    const prompt = `Analyze this learner profile for SkillPath AI:
Name: ${profile.name}
Education: ${profile.education} (${profile.department}, ${profile.yearOfStudy}) at ${profile.college || 'University'}
Target Career: ${profile.careerGoal}
Existing Skills: ${activeSkills.join(', ') || 'None recorded yet'}
Certifications: ${profile.certifications.join(', ') || 'None'}
Portfolio Projects: ${profile.projects.map((p) => `${p.title} (${p.description}) [${p.techStack.join(', ')}]`).join('; ') || 'None'}
Study Capacity: ${profile.learningPreferences.weeklyHours} hrs/week · Style: ${profile.learningPreferences.learningStyle} · Pace: ${profile.learningPreferences.pace}

Produce:
1. A sharp executive headline reflecting their readiness posture.
2. A grounded backgroundSummary highlighting transferable project/academic strengths and proof gaps.
3. 3-5 concrete strengths grounded strictly in their listed skills/projects/certifications.
4. A realistic weekly learningStrategy calibrated to ${profile.learningPreferences.weeklyHours} hrs/week.`;

    const response = await generateAgentContent(ai, {
      contents: prompt,
      thinkingLevel: ThinkingLevel.LOW,
      systemInstruction:
        'You are the SkillPath Profile Analysis Agent. Never invent credentials or skills not present in the input. Be specific, incisive, and practical.',
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          headline: { type: Type.STRING },
          backgroundSummary: { type: Type.STRING },
          strengths: {
            type: Type.ARRAY,
            items: { type: Type.STRING },
          },
          learningStrategy: { type: Type.STRING },
        },
        required: ['headline', 'backgroundSummary', 'strengths', 'learningStrategy'],
      },
    });

    const raw = stripJsonFences(response.text ?? '');
    const parsed = JSON.parse(raw) as ProfileAnalysisOutput;
    if (!parsed.headline || !parsed.backgroundSummary || !Array.isArray(parsed.strengths)) {
      throw new Error('Profile Analysis Agent returned malformed JSON schema.');
    }

    return {
      agentName: 'Profile Analysis Agent',
      status: 'completed',
      durationMs: Date.now() - start,
      inputSummary,
      outputSummary: `${parsed.headline} — Identified ${parsed.strengths.length} core strengths.`,
      data: parsed,
      errorMessage: '',
    };
  } catch (err) {
    const message = err instanceof Error ? err.message : String(err);
    return {
      agentName: 'Profile Analysis Agent',
      status: 'error',
      durationMs: Date.now() - start,
      inputSummary,
      outputSummary: 'Execution failed before producing structured output.',
      errorMessage: message,
    };
  }
}

export interface SkillGapAgentOutput {
  summary: string;
  explanations: Array<{ skillId: string; skillName: string; reason: string }>;
}

export async function runSkillGapAnalysisAgent(
  profile: LearnerProfile,
  skills: UserSkill[],
): Promise<AgentResult<{ analysis: SkillGapAnalysis; narrativeSummary: string }>> {
  const start = Date.now();
  const baseAnalysis = calculateSkillGaps(profile.userId, profile.careerGoal, skills);
  const inputSummary = `Career: ${profile.careerGoal} · Readiness: ${baseAnalysis.readinessScore}% · Strong: ${baseAnalysis.strongSkills.length} · Weak: ${baseAnalysis.weakSkills.length} · Missing: ${baseAnalysis.missingSkills.length}`;

  try {
    const ai = getGeminiClient();
    const itemsForPrompt = [
      ...baseAnalysis.prioritySkills,
      ...baseAnalysis.strongSkills,
    ].map((item) => ({
      skillId: item.skillId,
      skillName: item.skillName,
      status: item.status,
      current: item.currentProficiency,
      required: item.requiredProficiency,
      weight: item.weight,
      unmetPrerequisites: item.unmetPrerequisites,
    }));

    const prompt = `Deterministic weighted skill gap matrix for ${profile.name} targeting ${profile.careerGoal} (Computed Readiness: ${baseAnalysis.readinessScore}%):
${JSON.stringify(itemsForPrompt)}

For each skillId, write a crisp, high-signal 1-2 sentence explanation covering:
- Why its importance weight (${itemsForPrompt.map((i) => `${i.skillName}:${i.weight}x`).join(', ')}) and prerequisite dependencies matter for ${profile.careerGoal}
- The exact concrete milestone needed to close the gap (or leverage it if already strong).`;

    const response = await generateAgentContent(ai, {
      contents: prompt,
      thinkingLevel: ThinkingLevel.LOW,
      systemInstruction:
        'You are the Skill Gap Analysis Agent. Never alter or invent readiness percentages. Base all explanations strictly on the deterministic matrix.',
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          summary: { type: Type.STRING },
          explanations: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                skillId: { type: Type.STRING },
                skillName: { type: Type.STRING },
                reason: { type: Type.STRING },
              },
              required: ['skillId', 'skillName', 'reason'],
            },
          },
        },
        required: ['summary', 'explanations'],
      },
    });

    const parsed = JSON.parse(stripJsonFences(response.text ?? '')) as SkillGapAgentOutput;
    if (!parsed.summary || !Array.isArray(parsed.explanations)) {
      throw new Error('Skill Gap Analysis Agent returned invalid structure.');
    }

    const enrichedAnalysis = calculateSkillGaps(
      profile.userId,
      profile.careerGoal,
      skills,
      parsed.explanations,
    );

    return {
      agentName: 'Skill Gap Analysis Agent',
      status: 'completed',
      durationMs: Date.now() - start,
      inputSummary,
      outputSummary: `Readiness ${enrichedAnalysis.readinessScore}% · ${enrichedAnalysis.prioritySkills.length} priority gaps diagnosed.`,
      data: {
        analysis: enrichedAnalysis,
        narrativeSummary: parsed.summary,
      },
      errorMessage: '',
    };
  } catch (err) {
    const message = err instanceof Error ? err.message : String(err);
    return {
      agentName: 'Skill Gap Analysis Agent',
      status: 'error',
      durationMs: Date.now() - start,
      inputSummary,
      outputSummary: 'Skill gap explanation generation failed.',
      errorMessage: message,
    };
  }
}

export interface CareerMatchingAgentOutput {
  recommendedCareer: CareerGoal;
  matches: CareerMatchResult[];
  executiveAdvice: string;
}

export async function runCareerMatchingAgent(
  profile: LearnerProfile,
  skills: UserSkill[],
): Promise<AgentResult<CareerMatchingAgentOutput>> {
  const start = Date.now();
  const deterministicMatches = matchAllCareers(profile.userId, skills);
  const inputSummary = `Comparing ${skills.filter((s) => s.proficiency > 0).length} existing skills against 4 career tracks. Goal: ${profile.careerGoal}.`;

  try {
    const ai = getGeminiClient();
    const prompt = `Learner ${profile.name} (Current goal: ${profile.careerGoal}, Capacity: ${profile.learningPreferences.weeklyHours} hrs/wk) deterministic career comparison:
${JSON.stringify(deterministicMatches)}

Provide:
1. A crisp rationale per careerId explaining transferable strengths vs highest-weight blockers and transition ROI.
2. Strategic executiveAdvice comparing their chosen goal (${profile.careerGoal}) against the top deterministic match (${deterministicMatches[0].careerGoal} at ${deterministicMatches[0].readinessScore}%).`;

    const response = await generateAgentContent(ai, {
      contents: prompt,
      thinkingLevel: ThinkingLevel.LOW,
      systemInstruction:
        'You are the Career Matching Agent. Ground rationales strictly in the provided deterministic readiness scores, matched strengths, and missing skills.',
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          executiveAdvice: { type: Type.STRING },
          rationales: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                careerId: { type: Type.STRING },
                rationale: { type: Type.STRING },
              },
              required: ['careerId', 'rationale'],
            },
          },
        },
        required: ['executiveAdvice', 'rationales'],
      },
    });

    const parsed = JSON.parse(stripJsonFences(response.text ?? '')) as {
      executiveAdvice: string;
      rationales: Array<{ careerId: string; rationale: string }>;
    };
    const rMap = new Map((parsed.rationales ?? []).map((r) => [r.careerId, r.rationale]));
    const enriched = deterministicMatches.map((m) => ({
      ...m,
      aiRationale: rMap.get(m.careerId) ?? m.description,
    }));

    return {
      agentName: 'Career Matching Agent',
      status: 'completed',
      durationMs: Date.now() - start,
      inputSummary,
      outputSummary: `Best deterministic fit: ${enriched[0].careerGoal} (${enriched[0].readinessScore}%).`,
      data: {
        recommendedCareer: enriched[0].careerGoal,
        matches: enriched,
        executiveAdvice: parsed.executiveAdvice,
      },
      errorMessage: '',
    };
  } catch (err) {
    const message = err instanceof Error ? err.message : String(err);
    return {
      agentName: 'Career Matching Agent',
      status: 'error',
      durationMs: Date.now() - start,
      inputSummary,
      outputSummary: 'Career matching analysis failed.',
      errorMessage: message,
    };
  }
}

export interface RoadmapOrchestratorContext {
  profileStrategy?: string;
  gapSummary?: string;
  careerAdvice?: string;
}

export async function runLearningRecommendationAgent(
  profile: LearnerProfile,
  skills: UserSkill[],
  analysis: SkillGapAnalysis,
  adaptiveMode: LearningRoadmap['adaptiveMode'] = 'baseline',
  adaptationReason = 'Initial personalized roadmap generated from deterministic skill gaps and prerequisites.',
  focusSkillId?: string,
  weakTopics: string[] = [],
  orchestratorContext?: RoadmapOrchestratorContext,
): Promise<AgentResult<LearningRoadmap>> {
  const start = Date.now();
  const baseStages = buildDeterministicRoadmapStages(
    profile,
    skills,
    analysis,
    adaptiveMode,
    focusSkillId,
    weakTopics,
  );
  const inputSummary = `Goal: ${profile.careerGoal} · Mode: ${adaptiveMode} · Stages: ${baseStages.length} · Hours/wk: ${profile.learningPreferences.weeklyHours}`;

  try {
    const ai = getGeminiClient();
    const stageBriefs = baseStages.slice(0, 6).map((s) => ({
      stageId: s.stageId,
      skillName: s.skillName,
      priorityTag: s.priorityTag,
      estimatedHours: s.estimatedHours,
      focusTopics: s.focusTopics ?? [],
      availableResources: s.resources.map((r) => `${r.title} (${r.platform})`),
    }));

    const contextSection = orchestratorContext
      ? `\nUpstream Agent Findings:
- Profile Strategy: ${orchestratorContext.profileStrategy ?? 'N/A'}
- Gap Synthesis: ${orchestratorContext.gapSummary ?? 'N/A'}
- Career Alignment: ${orchestratorContext.careerAdvice ?? 'N/A'}`
      : '';

    const prompt = `Synthesize a deeply practical, personalized roadmap for ${profile.name} targeting ${profile.careerGoal} (Readiness: ${analysis.readinessScore}%, Mode: ${adaptiveMode}, Capacity: ${profile.learningPreferences.weeklyHours} hrs/week, Style: ${profile.learningPreferences.learningStyle}).
Adaptation Reason: ${adaptationReason}${contextSection}
Existing Projects: ${profile.projects.map((p) => p.title).join(', ') || 'None yet'}
Prioritized Stages: ${JSON.stringify(stageBriefs)}

For each stageId:
- Write a crisp outcome-focused learningObjective (<= 175 chars).
- Provide 3 concrete, actionable activities tailored to their weak topics & preferred learning style (${profile.learningPreferences.learningStyle}).
- Design 1 portfolio-grade practicalExercise with a verifiable deliverable.`;

    const response = await generateAgentContent(ai, {
      contents: prompt,
      thinkingLevel: ThinkingLevel.MEDIUM,
      systemInstruction:
        'You are the Learning Recommendation Agent. Synthesize upstream Profile, Gap, and Career Matching insights into a high-craft learning sequence. Keep objectives under 180 chars and never invent external URLs.',
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          roadmapSummary: { type: Type.STRING },
          stageUpdates: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                stageId: { type: Type.STRING },
                learningObjective: { type: Type.STRING },
                activities: {
                  type: Type.ARRAY,
                  items: { type: Type.STRING },
                },
                practicalExercise: { type: Type.STRING },
              },
              required: ['stageId', 'learningObjective', 'activities', 'practicalExercise'],
            },
          },
        },
        required: ['roadmapSummary', 'stageUpdates'],
      },
    });

    const parsed = JSON.parse(stripJsonFences(response.text ?? '')) as {
      roadmapSummary: string;
      stageUpdates: Array<{
        stageId: string;
        learningObjective: string;
        activities: string[];
        practicalExercise: string;
      }>;
    };

    const updateMap = new Map((parsed.stageUpdates ?? []).map((u) => [u.stageId, u]));
    const mergedStages = baseStages.map((stage) => {
      const upd = updateMap.get(stage.stageId);
      if (!upd) return stage;
      return {
        ...stage,
        learningObjective: (upd.learningObjective || stage.learningObjective).slice(0, 195),
        activities: upd.activities?.length ? upd.activities.slice(0, 3) : stage.activities,
        practicalExercise: upd.practicalExercise || stage.practicalExercise,
      };
    });

    const roadmap: LearningRoadmap = {
      userId: profile.userId,
      careerGoal: profile.careerGoal,
      adaptiveMode,
      adaptationReason: (adaptationReason || 'Personalized roadmap updated.').slice(0, 950),
      summary: (parsed.roadmapSummary || `Personalized ${profile.careerGoal} roadmap across ${mergedStages.length} prioritized stages.`).slice(0, 950),
      stages: mergedStages,
    };

    return {
      agentName: 'Learning Recommendation Agent',
      status: 'completed',
      durationMs: Date.now() - start,
      inputSummary,
      outputSummary: `Synthesized ${mergedStages.length}-stage adaptive roadmap (${adaptiveMode} mode).`,
      data: roadmap,
      errorMessage: '',
    };
  } catch (err) {
    const message = err instanceof Error ? err.message : String(err);
    return {
      agentName: 'Learning Recommendation Agent',
      status: 'error',
      durationMs: Date.now() - start,
      inputSummary,
      outputSummary: 'Roadmap recommendation failed.',
      errorMessage: message,
    };
  }
}

export interface ProgressEvaluationOutput {
  adaptiveMode: 'recovery' | 'practice' | 'progression';
  evaluationSummary: string;
  adaptationReason: string;
  recommendedFocusTopics: string[];
  updatedProficiency: number;
  mastered: boolean;
}

export async function runProgressEvaluationAgent(params: {
  profile: LearnerProfile;
  skill: UserSkill;
  score: number;
  topicBreakdown: TopicPerformance[];
  weakTopics: string[];
}): Promise<AgentResult<ProgressEvaluationOutput>> {
  const start = Date.now();
  const { profile, skill, score, topicBreakdown, weakTopics } = params;
  const recoveryThreshold = profile.adaptiveConfig?.recoveryThreshold ?? 50;
  const progressionThreshold = profile.adaptiveConfig?.progressionThreshold ?? 85;
  const adaptiveMode = determineAdaptiveMode(score, recoveryThreshold, progressionThreshold);

  const nextEvidenceCount = skill.evidenceCount + 1;
  let updatedProficiency: UserSkill['proficiency'] = skill.proficiency;
  if (adaptiveMode === 'recovery') {
    updatedProficiency = skill.proficiency > 1 ? 1 : skill.proficiency;
  } else if (adaptiveMode === 'practice') {
    updatedProficiency = skill.proficiency < 2 ? 2 : skill.proficiency;
  } else if (adaptiveMode === 'progression') {
    updatedProficiency = nextEvidenceCount >= 2 ? 4 : skill.proficiency < 3 ? 3 : skill.proficiency;
  }
  const mastered = adaptiveMode === 'progression' && nextEvidenceCount >= 2 && updatedProficiency >= 3;

  const inputSummary = `Skill: ${skill.skillName} · Score: ${score}% · Weak topics: ${weakTopics.join(', ') || 'None'} · Evidence: ${skill.evidenceCount} quiz(zes)`;

  try {
    const ai = getGeminiClient();
    const prompt = `Perform a diagnostic progress evaluation for ${profile.name} (${profile.careerGoal}):
Skill Evaluated: ${skill.skillName}
Assessment Score: ${score}% -> Deterministic Adaptive Mode: ${adaptiveMode.toUpperCase()} (Recovery <${recoveryThreshold}%, Practice ${recoveryThreshold}-${progressionThreshold - 1}%, Progression >=${progressionThreshold}%)
Topic Accuracy Breakdown: ${JSON.stringify(topicBreakdown)}
Weak Topics Flagged (<70%): ${weakTopics.join(', ') || 'None'}
Evidence Policy: Single quiz never grants mastery. Updated proficiency: ${updatedProficiency}/4, Evidence count: ${nextEvidenceCount}, Mastered: ${mastered}.

Deliver:
1. evaluationSummary: Specific diagnostic breakdown of what the learner mastered vs where conceptual misconceptions exist.
2. adaptationReason: Clear explanation of why the roadmap shifted into ${adaptiveMode.toUpperCase()} mode and what changes next.
3. recommendedFocusTopics: Ranked list of 1-4 concrete topics/drills to target immediately.`;

    const response = await generateAgentContent(ai, {
      contents: prompt,
      thinkingLevel: ThinkingLevel.MEDIUM,
      systemInstruction:
        'You are the Progress Evaluation Agent. Diagnose topic-level gaps accurately and enforce the multi-assessment mastery rule.',
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          evaluationSummary: { type: Type.STRING },
          adaptationReason: { type: Type.STRING },
          recommendedFocusTopics: {
            type: Type.ARRAY,
            items: { type: Type.STRING },
          },
        },
        required: ['evaluationSummary', 'adaptationReason', 'recommendedFocusTopics'],
      },
    });

    const parsed = JSON.parse(stripJsonFences(response.text ?? '')) as {
      evaluationSummary: string;
      adaptationReason: string;
      recommendedFocusTopics: string[];
    };

    const output: ProgressEvaluationOutput = {
      adaptiveMode,
      evaluationSummary: parsed.evaluationSummary,
      adaptationReason: parsed.adaptationReason,
      recommendedFocusTopics: parsed.recommendedFocusTopics?.length ? parsed.recommendedFocusTopics : weakTopics,
      updatedProficiency,
      mastered,
    };

    return {
      agentName: 'Progress Evaluation Agent',
      status: 'completed',
      durationMs: Date.now() - start,
      inputSummary,
      outputSummary: `Mode: ${adaptiveMode.toUpperCase()} (${score}%) · ${output.evaluationSummary.slice(0, 120)}`,
      data: output,
      errorMessage: '',
    };
  } catch (err) {
    const message = err instanceof Error ? err.message : String(err);
    return {
      agentName: 'Progress Evaluation Agent',
      status: 'error',
      durationMs: Date.now() - start,
      inputSummary,
      outputSummary: 'Progress evaluation failed.',
      errorMessage: message,
    };
  }
}

export async function runAIMentorAgent(params: {
  question: string;
  profile: LearnerProfile;
  skills: UserSkill[];
  analysis: SkillGapAnalysis;
  roadmap: LearningRoadmap | null;
  attempts: AssessmentAttempt[];
  history: MentorMessage[];
}): Promise<
  AgentResult<{
    reply: string;
    suggestedNextAction: string;
    actionPlan: Array<{ step: string; durationMinutes: number; targetSkill: string }>;
    referencedMetrics: string[];
  }>
> {
  const start = Date.now();
  const { question, profile, skills, analysis, roadmap, attempts, history } = params;
  const inputSummary = `Question: "${question.slice(0, 140)}" · Goal: ${profile.careerGoal} · Readiness: ${analysis.readinessScore}%`;

  try {
    const ai = getGeminiClient();

    const prioritySkillIds = new Set(analysis.prioritySkills.map((p) => p.skillId));
    const relevantResources = VERIFIED_RESOURCES.filter((r) => prioritySkillIds.has(r.skillId))
      .slice(0, 8)
      .map((r) => ({
        title: r.title,
        skill: r.skillName,
        platform: r.platform,
        hours: r.estimatedHours,
        url: r.url,
      }));

    const contextPayload = {
      learner: {
        name: profile.name,
        education: `${profile.education} (${profile.department}, ${profile.yearOfStudy})`,
        careerGoal: profile.careerGoal,
        weeklyHours: profile.learningPreferences.weeklyHours,
        learningStyle: profile.learningPreferences.learningStyle,
        certifications: profile.certifications,
        projects: profile.projects.map((p) => ({
          title: p.title,
          stack: p.techStack,
        })),
      },
      readinessScore: `${analysis.readinessScore}%`,
      strongSkills: analysis.strongSkills.map((s) => `${s.skillName} (${s.currentProficiency}/${s.requiredProficiency}, weight ${s.weight}x)`),
      weakSkills: analysis.weakSkills.map((s) => `${s.skillName} (${s.currentProficiency}/${s.requiredProficiency}, weight ${s.weight}x)`),
      missingSkills: analysis.missingSkills.map((s) => `${s.skillName} (0/${s.requiredProficiency}, weight ${s.weight}x, needs: ${s.unmetPrerequisites.join(', ') || 'none'})`),
      priorityOrder: analysis.prioritySkills.map((s) => s.skillName),
      weakTopicsRecorded: skills.flatMap((s) => s.weakTopics.map((t) => `${s.skillName}: ${t}`)),
      activeRoadmap: roadmap
        ? {
            adaptiveMode: roadmap.adaptiveMode,
            adaptationReason: roadmap.adaptationReason,
            nextStages: roadmap.stages.slice(0, 5).map((st) => ({
              order: st.order,
              skill: st.skillName,
              priority: st.priorityTag,
              status: st.status,
              hours: st.estimatedHours,
              exercise: st.practicalExercise,
            })),
          }
        : null,
      recentAssessments: attempts.slice(0, 5).map((a) => ({
        skill: a.skillName,
        score: `${a.score}%`,
        mode: a.adaptiveMode,
        weakTopics: a.weakTopics,
        summary: a.evaluationSummary,
      })),
      verifiedResourcesForGaps: relevantResources,
      recentMessages: history.slice(-6).map((m) => `${m.role}: ${m.content}`),
    };

    const prompt = `Learner Telemetry & Context:\n${JSON.stringify(contextPayload)}\n\nLearner Question:\n${question}

Respond as a world-class principal career mentor:
1. Directly cite the learner's exact numbers (readiness %, skill levels, weak topics, projects, or assessment scores).
2. Recommend specific verified resources from verifiedResourcesForGaps by exact title/platform when helpful (never invent URLs).
3. Provide a 3-step time-boxed actionPlan calibrated to ${profile.learningPreferences.weeklyHours} hrs/week and one sharp suggestedNextAction.`;

    const response = await generateAgentContent(ai, {
      contents: prompt,
      thinkingLevel: ThinkingLevel.MEDIUM,
      systemInstruction:
        'You are the SkillPath AI Mentor Agent — an elite principal engineering & career coach. Always ground your coaching in the learner’s real metrics, gaps, assessment history, and verified resources. Avoid generic platitudes.',
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          reply: { type: Type.STRING },
          suggestedNextAction: { type: Type.STRING },
          actionPlan: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                step: { type: Type.STRING },
                durationMinutes: { type: Type.INTEGER },
                targetSkill: { type: Type.STRING },
              },
              required: ['step', 'durationMinutes', 'targetSkill'],
            },
          },
          referencedMetrics: {
            type: Type.ARRAY,
            items: { type: Type.STRING },
          },
        },
        required: ['reply', 'suggestedNextAction', 'actionPlan', 'referencedMetrics'],
      },
    });

    const parsed = JSON.parse(stripJsonFences(response.text ?? '')) as {
      reply: string;
      suggestedNextAction: string;
      actionPlan: Array<{ step: string; durationMinutes: number; targetSkill: string }>;
      referencedMetrics: string[];
    };

    if (!parsed.reply) {
      throw new Error('AI Mentor Agent returned an empty response.');
    }

    return {
      agentName: 'AI Mentor Agent',
      status: 'completed',
      durationMs: Date.now() - start,
      inputSummary,
      outputSummary: `Coached on ${parsed.referencedMetrics?.length ?? 0} live metrics · Next action: ${parsed.suggestedNextAction}`,
      data: parsed,
      errorMessage: '',
    };
  } catch (err) {
    const message = err instanceof Error ? err.message : String(err);
    return {
      agentName: 'AI Mentor Agent',
      status: 'error',
      durationMs: Date.now() - start,
      inputSummary,
      outputSummary: 'AI Mentor generation failed.',
      errorMessage: message,
    };
  }
}
