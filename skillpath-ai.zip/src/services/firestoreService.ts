import {
  collection,
  deleteDoc,
  doc,
  getDoc,
  getDocs,
  query,
  serverTimestamp,
  setDoc,
  updateDoc,
  where,
  writeBatch,
} from 'firebase/firestore';
import { auth, db, handleFirestoreError, OperationType } from '../lib/firebase.ts';
import {
  ASSESSMENT_BANK,
  CAREER_CATALOG,
  SKILLS_CATALOG,
  VERIFIED_RESOURCES,
} from '../shared/catalog.ts';
import type {
  AgentLogEntry,
  AssessmentAttempt,
  LearnerProfile,
  LearningRoadmap,
  LearningTask,
  MentorMessage,
  ProgressRecord,
  SkillGapAnalysis,
  UserResourceState,
  UserSkill,
} from '../shared/types.ts';

function sanitizeId(raw: string): string {
  return raw.replace(/[^a-zA-Z0-9_\-]/g, '_').slice(0, 120) || 'id';
}

function assertCloudOwner(targetUserId: string | undefined): string | null {
  const currentUid = auth.currentUser?.uid;
  if (!currentUid || !targetUserId) return null;
  if (targetUserId !== currentUid) return null;
  if (targetUserId.startsWith('demo') || targetUserId.startsWith('local_')) return null;
  return sanitizeId(currentUid);
}

function clampStr(val: string | undefined, max: number): string {
  return (val ?? '').slice(0, max);
}

function nonEmptyClamp(val: string | undefined, fallback: string, max: number): string {
  const trimmed = (val ?? '').trim();
  return (trimmed.length > 0 ? trimmed : fallback).slice(0, max);
}

function stripUndefined<T>(value: T): T {
  if (Array.isArray(value)) {
    return value.map((item) => stripUndefined(item)) as unknown as T;
  }
  if (value !== null && typeof value === 'object') {
    const out: Record<string, unknown> = {};
    for (const [k, v] of Object.entries(value as Record<string, unknown>)) {
      if (v !== undefined) {
        out[k] = stripUndefined(v);
      }
    }
    return out as T;
  }
  return value;
}

const VALID_ADAPTIVE_MODES = new Set<LearningRoadmap['adaptiveMode']>([
  'baseline',
  'recovery',
  'practice',
  'progression',
  'career_switch',
]);

const writeQueues = new Map<string, Promise<unknown>>();

function enqueueWrite<T>(queueKey: string, task: () => Promise<T>): Promise<T> {
  const prev = writeQueues.get(queueKey) ?? Promise.resolve();
  const next = prev.catch(() => undefined).then(task);
  writeQueues.set(queueKey, next);
  return next;
}

function toIsoTimestamp(ts: unknown): string {
  if (!ts) return new Date().toISOString();
  if (typeof ts === 'string') return ts;
  if (
    typeof ts === 'object' &&
    ts !== null &&
    'toDate' in ts &&
    typeof (ts as { toDate: () => Date }).toDate === 'function'
  ) {
    return (ts as { toDate: () => Date }).toDate().toISOString();
  }
  return new Date().toISOString();
}

export async function fetchLearnerWorkspace(userId: string): Promise<{
  profile: LearnerProfile | null;
  skills: UserSkill[];
  analysis: SkillGapAnalysis | null;
  roadmap: LearningRoadmap | null;
  tasks: LearningTask[];
  resources: UserResourceState[];
  attempts: AssessmentAttempt[];
  progress: ProgressRecord[];
  agentLogs: AgentLogEntry[];
  mentorMessages: MentorMessage[];
}> {
  let profile: LearnerProfile | null = null;
  try {
    const snap = await getDoc(doc(db, 'learnerProfiles', userId));
    if (snap.exists()) {
      profile = snap.data() as LearnerProfile;
    }
  } catch (err) {
    handleFirestoreError(err, OperationType.GET, `learnerProfiles/${userId}`);
  }

  // Fetch collections in parallel for faster workspace load
  const [
    skillsSnap,
    gapSnap,
    roadmapSnap,
    tasksSnap,
    resourcesSnap,
    attemptsSnap,
    progressSnap,
    logsSnap,
    mentorSnap,
  ] = await Promise.all([
    getDocs(query(collection(db, 'skills'), where('userId', '==', userId))).catch((err) =>
      handleFirestoreError(err, OperationType.LIST, 'skills'),
    ),
    getDocs(query(collection(db, 'skillGapAnalyses'), where('userId', '==', userId))).catch((err) =>
      handleFirestoreError(err, OperationType.LIST, 'skillGapAnalyses'),
    ),
    getDocs(query(collection(db, 'learningRoadmaps'), where('userId', '==', userId))).catch((err) =>
      handleFirestoreError(err, OperationType.LIST, 'learningRoadmaps'),
    ),
    getDocs(query(collection(db, 'learningTasks'), where('userId', '==', userId))).catch((err) =>
      handleFirestoreError(err, OperationType.LIST, 'learningTasks'),
    ),
    getDocs(query(collection(db, 'resources'), where('userId', '==', userId))).catch((err) =>
      handleFirestoreError(err, OperationType.LIST, 'resources'),
    ),
    getDocs(query(collection(db, 'assessmentAttempts'), where('userId', '==', userId))).catch((err) =>
      handleFirestoreError(err, OperationType.LIST, 'assessmentAttempts'),
    ),
    getDocs(query(collection(db, 'progressRecords'), where('userId', '==', userId))).catch((err) =>
      handleFirestoreError(err, OperationType.LIST, 'progressRecords'),
    ),
    getDocs(query(collection(db, 'agentLogs'), where('userId', '==', userId))).catch((err) =>
      handleFirestoreError(err, OperationType.LIST, 'agentLogs'),
    ),
    getDocs(query(collection(db, 'mentorConversations'), where('userId', '==', userId))).catch((err) =>
      handleFirestoreError(err, OperationType.LIST, 'mentorConversations'),
    ),
  ]);

  const skills = skillsSnap.docs.map((d) => ({ id: d.id, ...(d.data() as UserSkill) }));

  const allAnalyses = gapSnap.docs.map((d) => ({ id: d.id, ...(d.data() as SkillGapAnalysis) }));
  allAnalyses.sort((a, b) => toIsoTimestamp(b.updatedAt).localeCompare(toIsoTimestamp(a.updatedAt)));
  const analysis = allAnalyses[0] ?? null;

  const allRoadmaps = roadmapSnap.docs.map((d) => ({ id: d.id, ...(d.data() as LearningRoadmap) }));
  allRoadmaps.sort((a, b) => toIsoTimestamp(b.updatedAt).localeCompare(toIsoTimestamp(a.updatedAt)));
  const roadmap = allRoadmaps[0] ?? null;

  const tasks = tasksSnap.docs
    .map((d) => ({ id: d.id, ...(d.data() as LearningTask) }))
    .sort((a, b) => a.stageOrder - b.stageOrder);

  const storedResourceMap = new Map(
    resourcesSnap.docs.map((d) => {
      const data = d.data() as { resourceId: string; bookmarked: boolean; completed: boolean };
      return [data.resourceId, data];
    }),
  );
  const resources = VERIFIED_RESOURCES.map((res) => {
    const saved = storedResourceMap.get(res.resourceId);
    return {
      ...res,
      userId,
      bookmarked: saved?.bookmarked ?? false,
      completed: saved?.completed ?? false,
    };
  });

  const attempts = attemptsSnap.docs
    .map((d) => {
      const data = d.data() as AssessmentAttempt;
      return { id: d.id, ...data, timestampIso: toIsoTimestamp(data.createdAt) };
    })
    .sort((a, b) => (b.timestampIso ?? '').localeCompare(a.timestampIso ?? ''));

  const progress = progressSnap.docs
    .map((d) => {
      const data = d.data() as ProgressRecord;
      return { id: d.id, ...data, timestampIso: toIsoTimestamp(data.createdAt) };
    })
    .sort((a, b) => (b.timestampIso ?? '').localeCompare(a.timestampIso ?? ''));

  const agentLogs = logsSnap.docs
    .map((d) => {
      const data = d.data() as AgentLogEntry;
      return { id: d.id, ...data, timestampIso: toIsoTimestamp(data.createdAt) };
    })
    .sort((a, b) => {
      const cmp = (b.timestampIso ?? '').localeCompare(a.timestampIso ?? '');
      return cmp !== 0 ? cmp : b.stepOrder - a.stepOrder;
    });

  const mentorMessages = mentorSnap.docs
    .map((d) => {
      const data = d.data() as MentorMessage;
      return { id: d.id, ...data, timestampIso: toIsoTimestamp(data.createdAt) };
    })
    .sort((a, b) => (a.timestampIso ?? '').localeCompare(b.timestampIso ?? ''));

  return {
    profile,
    skills,
    analysis,
    roadmap,
    tasks,
    resources,
    attempts,
    progress,
    agentLogs,
    mentorMessages,
  };
}

export async function initializeUserCatalogInFirestore(userId: string): Promise<void> {
  const safeUid = assertCloudOwner(userId);
  if (!safeUid) return;
  try {
    const [existingCareersSnap, existingResourcesSnap, existingAssessmentsSnap] = await Promise.all([
      getDocs(query(collection(db, 'careerRequirements'), where('userId', '==', safeUid))),
      getDocs(query(collection(db, 'resources'), where('userId', '==', safeUid))),
      getDocs(query(collection(db, 'assessments'), where('userId', '==', safeUid))),
    ]);

    const existingCareerIds = new Set(existingCareersSnap.docs.map((d) => d.id));
    const existingResourceIds = new Set(existingResourcesSnap.docs.map((d) => d.id));
    const existingAssessmentIds = new Set(existingAssessmentsSnap.docs.map((d) => d.id));

    const batch = writeBatch(db);
    let writeCount = 0;

    for (const career of CAREER_CATALOG) {
      const docId = sanitizeId(`${safeUid}_${career.careerId}`);
      if (existingCareerIds.has(docId)) continue;
      batch.set(doc(db, 'careerRequirements', docId), {
        userId: safeUid,
        careerId: sanitizeId(career.careerId),
        title: nonEmptyClamp(career.title, 'Career Track', 100),
        description: nonEmptyClamp(career.description, 'Career requirements', 600),
        requirements: stripUndefined(career.requirements.slice(0, 30)),
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });
      writeCount += 1;
    }

    for (const res of VERIFIED_RESOURCES) {
      const docId = sanitizeId(`${safeUid}_${res.resourceId}`);
      if (existingResourceIds.has(docId)) continue;
      batch.set(doc(db, 'resources', docId), {
        userId: safeUid,
        resourceId: sanitizeId(res.resourceId),
        skillId: sanitizeId(res.skillId),
        title: nonEmptyClamp(res.title, 'Learning Resource', 200),
        platform: nonEmptyClamp(res.platform, 'Docs', 80),
        url: nonEmptyClamp(res.url, 'https://developer.mozilla.org', 500),
        bookmarked: false,
        completed: false,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });
      writeCount += 1;
    }

    for (const assess of ASSESSMENT_BANK) {
      const docId = sanitizeId(`${safeUid}_${assess.assessmentId}`);
      if (existingAssessmentIds.has(docId)) continue;
      batch.set(doc(db, 'assessments', docId), {
        userId: safeUid,
        assessmentId: sanitizeId(assess.assessmentId),
        skillId: sanitizeId(assess.skillId),
        title: nonEmptyClamp(assess.title, 'Skill Assessment', 160),
        difficulty: assess.difficulty,
        questionCount: assess.questions.length,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });
      writeCount += 1;
    }

    if (writeCount > 0) {
      await batch.commit();
    }
  } catch (err) {
    handleFirestoreError(err, OperationType.WRITE, 'catalog_seed');
  }
}

export async function saveLearnerProfile(profile: LearnerProfile): Promise<void> {
  const safeUid = assertCloudOwner(profile.userId);
  if (!safeUid) return;
  const docRef = doc(db, 'learnerProfiles', safeUid);
  const editableFields = {
    name: nonEmptyClamp(profile.name, 'Learner', 120),
    email: nonEmptyClamp(profile.email, `${safeUid}@learner.skillpath.local`, 254),
    education: clampStr(profile.education, 160),
    college: clampStr(profile.college, 200),
    department: clampStr(profile.department, 160),
    yearOfStudy: clampStr(profile.yearOfStudy, 60),
    careerGoal: profile.careerGoal,
    certifications: (profile.certifications ?? []).slice(0, 30).map((c) => clampStr(String(c), 160)),
    projects: stripUndefined((profile.projects ?? []).slice(0, 30)),
    learningPreferences: {
      weeklyHours: Math.min(80, Math.max(1, Number(profile.learningPreferences?.weeklyHours) || 10)),
      learningStyle: nonEmptyClamp(profile.learningPreferences?.learningStyle, 'Hands-on Projects & Assessments', 60),
      pace: nonEmptyClamp(profile.learningPreferences?.pace, 'Balanced Weekly Milestones', 60),
    },
    adaptiveConfig: {
      recoveryThreshold: Math.min(70, Math.max(20, Number(profile.adaptiveConfig?.recoveryThreshold) || 50)),
      progressionThreshold: Math.min(95, Math.max(70, Number(profile.adaptiveConfig?.progressionThreshold) || 85)),
    },
  };

  try {
    const existingSnap = await getDoc(docRef);
    if (existingSnap.exists() && existingSnap.data()?.createdAt) {
      await updateDoc(docRef, {
        ...editableFields,
        updatedAt: serverTimestamp(),
      });
    } else {
      if (existingSnap.exists()) {
        await deleteDoc(docRef);
      }
      await setDoc(docRef, {
        userId: safeUid,
        ...editableFields,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });
    }
  } catch (err) {
    handleFirestoreError(err, OperationType.WRITE, `learnerProfiles/${safeUid}`);
  }
}

export async function saveUserSkills(userId: string, skills: UserSkill[]): Promise<void> {
  const safeUid = assertCloudOwner(userId);
  if (!safeUid) return;
  try {
    const existingSnap = await getDocs(query(collection(db, 'skills'), where('userId', '==', safeUid)));
    const existingMap = new Map(existingSnap.docs.map((d) => [d.id, d]));

    const preDeleteRefs = existingSnap.docs
      .filter((d) => !d.data()?.createdAt)
      .map((d) => d.ref);
    if (preDeleteRefs.length > 0) {
      const preBatch = writeBatch(db);
      for (const ref of preDeleteRefs) {
        preBatch.delete(ref);
        existingMap.delete(ref.id);
      }
      await preBatch.commit();
    }

    const batch = writeBatch(db);

    for (const skill of skills) {
      const safeSkillId = sanitizeId(skill.skillId);
      const docId = sanitizeId(`${safeUid}_${safeSkillId}`);
      const catalogDef = SKILLS_CATALOG.find((s) => s.skillId === skill.skillId);
      const cleanTopics = (skill.weakTopics ?? []).slice(0, 30).map((t) => clampStr(String(t), 120));

      const existingDoc = existingMap.get(docId);
      if (existingDoc && existingDoc.data()?.skillId === safeSkillId) {
        batch.update(doc(db, 'skills', docId), {
          proficiency: Math.min(4, Math.max(0, Math.round(skill.proficiency))),
          evidenceCount: Math.min(1000, Math.max(0, Math.round(skill.evidenceCount))),
          weakTopics: cleanTopics,
          mastered: Boolean(skill.mastered),
          updatedAt: serverTimestamp(),
        });
      } else {
        batch.set(doc(db, 'skills', docId), {
          userId: safeUid,
          skillId: safeSkillId,
          skillName: nonEmptyClamp(skill.skillName || catalogDef?.skillName, safeSkillId, 100),
          category: nonEmptyClamp(skill.category || catalogDef?.category, 'Core Engineering', 80),
          proficiency: Math.min(4, Math.max(0, Math.round(skill.proficiency))),
          evidenceCount: Math.min(1000, Math.max(0, Math.round(skill.evidenceCount))),
          weakTopics: cleanTopics,
          mastered: Boolean(skill.mastered),
          createdAt: serverTimestamp(),
          updatedAt: serverTimestamp(),
        });
      }
    }

    await batch.commit();
  } catch (err) {
    handleFirestoreError(err, OperationType.WRITE, 'skills');
  }
}

export async function saveSkillGapAnalysis(analysis: SkillGapAnalysis): Promise<string> {
  const safeUid = assertCloudOwner(analysis.userId);
  if (!safeUid) return '';
  const docId = sanitizeId(`${safeUid}_active_gap`);

  return enqueueWrite(`gap_${safeUid}`, async () => {
    const docRef = doc(db, 'skillGapAnalyses', docId);
    const editableFields = {
      careerGoal: nonEmptyClamp(analysis.careerGoal, 'Full Stack Developer', 100),
      readinessScore: Math.min(100, Math.max(0, Number(analysis.readinessScore) || 0)),
      strongSkills: stripUndefined((analysis.strongSkills ?? []).slice(0, 30)),
      weakSkills: stripUndefined((analysis.weakSkills ?? []).slice(0, 30)),
      missingSkills: stripUndefined((analysis.missingSkills ?? []).slice(0, 30)),
      prioritySkills: stripUndefined((analysis.prioritySkills ?? []).slice(0, 30)),
      explanations: stripUndefined((analysis.explanations ?? []).slice(0, 30)),
    };

    try {
      const existingSnap = await getDocs(
        query(collection(db, 'skillGapAnalyses'), where('userId', '==', safeUid)),
      );
      const existingDoc = existingSnap.docs.find((d) => d.id === docId);
      if (existingDoc && existingDoc.data()?.createdAt) {
        await updateDoc(docRef, {
          ...editableFields,
          updatedAt: serverTimestamp(),
        });
      } else {
        if (existingDoc) {
          await deleteDoc(docRef);
        }
        await setDoc(docRef, {
          userId: safeUid,
          ...editableFields,
          createdAt: serverTimestamp(),
          updatedAt: serverTimestamp(),
        });
      }
      return docId;
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, `skillGapAnalyses/${docId}`);
    }
  });
}

export async function saveLearningRoadmapAndTasks(roadmap: LearningRoadmap): Promise<string> {
  const safeUid = assertCloudOwner(roadmap.userId);
  if (!safeUid) return '';
  const roadmapId = sanitizeId(`${safeUid}_active_roadmap`);

  return enqueueWrite(`roadmap_${safeUid}`, async () => {
    const docRef = doc(db, 'learningRoadmaps', roadmapId);
    const safeMode: LearningRoadmap['adaptiveMode'] = VALID_ADAPTIVE_MODES.has(roadmap.adaptiveMode)
      ? roadmap.adaptiveMode
      : 'baseline';

    const editableFields = {
      careerGoal: nonEmptyClamp(roadmap.careerGoal, 'Full Stack Developer', 100),
      adaptiveMode: safeMode,
      adaptationReason: nonEmptyClamp(roadmap.adaptationReason, 'Personalized roadmap generated.', 1000),
      summary: nonEmptyClamp(roadmap.summary, 'Sequenced stages based on skill gaps.', 1000),
      stages: stripUndefined((roadmap.stages ?? []).slice(0, 30)),
    };

    try {
      const existingSnap = await getDocs(
        query(collection(db, 'learningRoadmaps'), where('userId', '==', safeUid)),
      );
      const existingDoc = existingSnap.docs.find((d) => d.id === roadmapId);
      if (existingDoc && existingDoc.data()?.createdAt) {
        await updateDoc(docRef, {
          ...editableFields,
          updatedAt: serverTimestamp(),
        });
      } else {
        if (existingDoc) {
          await deleteDoc(docRef);
        }
        await setDoc(docRef, {
          userId: safeUid,
          ...editableFields,
          createdAt: serverTimestamp(),
          updatedAt: serverTimestamp(),
        });
      }
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, `learningRoadmaps/${roadmapId}`);
    }

    try {
      const existingTasksSnap = await getDocs(
        query(collection(db, 'learningTasks'), where('userId', '==', safeUid)),
      );
      const existingTaskMap = new Map(existingTasksSnap.docs.map((d) => [d.id, d]));
      const stages = (roadmap.stages ?? []).slice(0, 30);

      const preDeleteIds = new Set<string>();
      const nextTaskIds = new Set<string>();
      const uniqueStages: Array<{ taskId: string; stage: typeof stages[number] }> = [];

      for (const stage of stages) {
        let taskId = sanitizeId(`${safeUid}_${stage.stageId}_${stage.order}`);
        if (nextTaskIds.has(taskId)) {
          taskId = sanitizeId(`${taskId}_${uniqueStages.length}`);
        }
        nextTaskIds.add(taskId);
        uniqueStages.push({ taskId, stage });

        const safeSkillId = sanitizeId(stage.skillId);
        const existingTask = existingTaskMap.get(taskId);
        if (
          existingTask &&
          (!existingTask.data()?.createdAt ||
            existingTask.data()?.roadmapId !== roadmapId ||
            existingTask.data()?.skillId !== safeSkillId)
        ) {
          preDeleteIds.add(taskId);
          existingTaskMap.delete(taskId);
        }
      }

      if (preDeleteIds.size > 0) {
        const preBatch = writeBatch(db);
        for (const tDoc of existingTasksSnap.docs) {
          if (preDeleteIds.has(tDoc.id)) {
            preBatch.delete(tDoc.ref);
          }
        }
        await preBatch.commit();
      }

      const batch = writeBatch(db);
      let mutationCount = 0;

      for (const tDoc of existingTasksSnap.docs) {
        if (!nextTaskIds.has(tDoc.id) && !preDeleteIds.has(tDoc.id)) {
          batch.delete(tDoc.ref);
          mutationCount += 1;
        }
      }

      for (const { taskId, stage } of uniqueStages) {
        const safeSkillId = sanitizeId(stage.skillId);
        const safeStatus =
          stage.status === 'in_progress' || stage.status === 'completed' ? stage.status : 'pending';
        const safeOrder = Math.max(0, Math.min(100, Math.round(Number(stage.order) || 0)));
        const safeHours = Math.max(0, Math.min(500, Number(stage.estimatedHours) || 4));
        const safeTitle = nonEmptyClamp(stage.learningObjective, `Study ${stage.skillName}`, 200);

        const existingTask = existingTaskMap.get(taskId);
        if (existingTask) {
          batch.update(doc(db, 'learningTasks', taskId), {
            stageOrder: safeOrder,
            status: safeStatus,
            estimatedHours: safeHours,
            title: safeTitle,
            updatedAt: serverTimestamp(),
          });
        } else {
          batch.set(doc(db, 'learningTasks', taskId), {
            userId: safeUid,
            roadmapId,
            skillId: safeSkillId,
            title: safeTitle,
            stageOrder: safeOrder,
            status: safeStatus,
            estimatedHours: safeHours,
            createdAt: serverTimestamp(),
            updatedAt: serverTimestamp(),
          });
        }
        mutationCount += 1;
      }

      if (mutationCount > 0) {
        await batch.commit();
      }
      return roadmapId;
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, 'learningTasks');
    }
  });
}

export async function updateResourceState(
  userId: string,
  resource: UserResourceState,
): Promise<void> {
  const safeUid = assertCloudOwner(userId);
  if (!safeUid) return;
  const docId = sanitizeId(`${safeUid}_${resource.resourceId}`);
  const docRef = doc(db, 'resources', docId);
  try {
    const existingSnap = await getDocs(
      query(collection(db, 'resources'), where('userId', '==', safeUid)),
    );
    const existingDoc = existingSnap.docs.find((d) => d.id === docId);
    const safeResId = sanitizeId(resource.resourceId);
    if (existingDoc && existingDoc.data()?.createdAt && existingDoc.data()?.resourceId === safeResId) {
      await updateDoc(docRef, {
        bookmarked: Boolean(resource.bookmarked),
        completed: Boolean(resource.completed),
        updatedAt: serverTimestamp(),
      });
    } else {
      if (existingDoc) {
        await deleteDoc(docRef);
      }
      await setDoc(docRef, {
        userId: safeUid,
        resourceId: safeResId,
        skillId: sanitizeId(resource.skillId),
        title: nonEmptyClamp(resource.title, 'Learning Resource', 200),
        platform: nonEmptyClamp(resource.platform, 'Docs', 80),
        url: nonEmptyClamp(resource.url, 'https://developer.mozilla.org', 500),
        bookmarked: Boolean(resource.bookmarked),
        completed: Boolean(resource.completed),
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });
    }
  } catch (err) {
    handleFirestoreError(err, OperationType.WRITE, `resources/${docId}`);
  }
}

export async function appendAssessmentAttempt(attempt: AssessmentAttempt): Promise<string> {
  const safeUid = assertCloudOwner(attempt.userId);
  if (!safeUid) return '';
  const docId = sanitizeId(`att_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`);
  const safeTotal = Math.max(1, Math.min(100, Math.round(attempt.totalQuestions)));
  const safeCorrect = Math.min(safeTotal, Math.max(0, Math.round(attempt.correctCount)));
  try {
    await setDoc(doc(db, 'assessmentAttempts', docId), {
      userId: safeUid,
      assessmentId: sanitizeId(attempt.assessmentId),
      skillId: sanitizeId(attempt.skillId),
      skillName: nonEmptyClamp(attempt.skillName, 'Skill', 100),
      score: Math.min(100, Math.max(0, Math.round(attempt.score))),
      totalQuestions: safeTotal,
      correctCount: safeCorrect,
      adaptiveMode: attempt.adaptiveMode,
      weakTopics: (attempt.weakTopics ?? []).slice(0, 20).map((t) => clampStr(String(t), 120)),
      topicBreakdown: stripUndefined((attempt.topicBreakdown ?? []).slice(0, 20)),
      evaluationSummary: nonEmptyClamp(
        attempt.evaluationSummary,
        `Assessment scored ${attempt.score}%.`,
        1000,
      ),
      createdAt: serverTimestamp(),
    });
    return docId;
  } catch (err) {
    handleFirestoreError(err, OperationType.CREATE, `assessmentAttempts/${docId}`);
  }
}

export async function appendProgressRecord(record: ProgressRecord): Promise<string> {
  const safeUid = assertCloudOwner(record.userId);
  if (!safeUid) return '';
  const docId = sanitizeId(`prog_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`);
  try {
    await setDoc(doc(db, 'progressRecords', docId), {
      userId: safeUid,
      eventType: record.eventType,
      skillId: sanitizeId(record.skillId),
      skillName: nonEmptyClamp(record.skillName, 'Skill', 100),
      readinessScore: Math.min(100, Math.max(0, Number(record.readinessScore) || 0)),
      detail: nonEmptyClamp(record.detail, 'Progress updated.', 500),
      createdAt: serverTimestamp(),
    });
    return docId;
  } catch (err) {
    handleFirestoreError(err, OperationType.CREATE, `progressRecords/${docId}`);
  }
}

export async function appendAgentLogs(logs: AgentLogEntry[]): Promise<void> {
  const ownedLogs = logs.filter((l) => assertCloudOwner(l.userId) !== null);
  if (ownedLogs.length === 0) return;
  try {
    for (let i = 0; i < ownedLogs.length; i += 400) {
      const chunk = ownedLogs.slice(i, i + 400);
      const batch = writeBatch(db);
      for (const log of chunk) {
        const docId = sanitizeId(`log_${Date.now()}_${log.stepOrder}_${Math.random().toString(36).slice(2, 6)}`);
        batch.set(doc(db, 'agentLogs', docId), {
          userId: sanitizeId(log.userId),
          runId: sanitizeId(log.runId),
          agentName: nonEmptyClamp(log.agentName, 'AI Agent', 80),
          stepOrder: Math.max(1, Math.min(20, Math.round(log.stepOrder))),
          status: log.status === 'error' ? 'error' : 'completed',
          inputSummary: nonEmptyClamp(log.inputSummary, 'Agent input payload', 800),
          outputSummary: nonEmptyClamp(log.outputSummary, 'Agent completed execution', 1200),
          errorMessage: clampStr(log.errorMessage, 500),
          durationMs: Math.max(0, Math.min(300000, Math.round(log.durationMs))),
          createdAt: serverTimestamp(),
        });
      }
      await batch.commit();
    }
  } catch (err) {
    handleFirestoreError(err, OperationType.CREATE, 'agentLogs');
  }
}

export async function appendMentorMessage(msg: MentorMessage): Promise<string> {
  const safeUid = assertCloudOwner(msg.userId);
  if (!safeUid) return '';
  const docId = sanitizeId(`msg_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`);
  try {
    await setDoc(doc(db, 'mentorConversations', docId), {
      userId: safeUid,
      role: msg.role,
      content: nonEmptyClamp(msg.content, 'Message', 4000),
      careerGoal: nonEmptyClamp(msg.careerGoal, 'Full Stack Developer', 100),
      createdAt: serverTimestamp(),
    });
    return docId;
  } catch (err) {
    handleFirestoreError(err, OperationType.CREATE, `mentorConversations/${docId}`);
  }
}

export async function clearMentorConversation(userId: string): Promise<void> {
  const safeUid = assertCloudOwner(userId);
  if (!safeUid) return;
  try {
    const snap = await getDocs(query(collection(db, 'mentorConversations'), where('userId', '==', safeUid)));
    for (let i = 0; i < snap.docs.length; i += 400) {
      const batch = writeBatch(db);
      for (const d of snap.docs.slice(i, i + 400)) {
        batch.delete(d.ref);
      }
      await batch.commit();
    }
  } catch (err) {
    handleFirestoreError(err, OperationType.DELETE, 'mentorConversations');
  }
}

export async function deleteAllUserData(userId: string): Promise<void> {
  const safeUid = assertCloudOwner(userId);
  if (!safeUid) return;
  const collections = [
    'skills',
    'careerRequirements',
    'skillGapAnalyses',
    'learningRoadmaps',
    'learningTasks',
    'resources',
    'assessments',
    'assessmentAttempts',
    'progressRecords',
    'agentLogs',
    'mentorConversations',
  ];

  try {
    for (const colName of collections) {
      const snap = await getDocs(query(collection(db, colName), where('userId', '==', safeUid)));
      for (let i = 0; i < snap.docs.length; i += 400) {
        const batch = writeBatch(db);
        for (const d of snap.docs.slice(i, i + 400)) {
          batch.delete(d.ref);
        }
        await batch.commit();
      }
    }
    await deleteDoc(doc(db, 'learnerProfiles', safeUid));
  } catch (err) {
    handleFirestoreError(err, OperationType.DELETE, 'user_workspace');
  }
}
