import { auth } from '../lib/firebase.ts';
import { calculateSkillGaps } from '../shared/skillEngine.ts';
import type {
  AgentLogEntry,
  AgentName,
  AgentRuntimeStatus,
  AssessmentAttempt,
  CareerMatchResult,
  LearnerProfile,
  LearningRoadmap,
  MentorMessage,
  SkillGapAnalysis,
  TopicPerformance,
  UserSkill,
} from '../shared/types.ts';

interface ServerAgentResponse<T> {
  agentName: AgentName;
  status: 'completed' | 'error';
  durationMs: number;
  inputSummary: string;
  outputSummary: string;
  data?: T;
  errorMessage: string;
}

export type WorkspaceExecutionMode = 'firebase' | 'local' | 'demo';

async function callAgentApi<T>(
  endpoint: string,
  body: unknown,
  mode: WorkspaceExecutionMode,
): Promise<ServerAgentResponse<T>> {
  const headers: Record<string, string> = {
    'Content-Type': 'application/json',
  };

  if (mode === 'demo') {
    headers['X-Demo-Mode'] = 'true';
  } else if (mode === 'local') {
    headers['X-Workspace-Mode'] = 'local';
  } else {
    const token = await auth.currentUser?.getIdToken();
    if (!token) {
      throw new Error('Authentication token unavailable. Please sign in again.');
    }
    headers['Authorization'] = `Bearer ${token}`;
  }

  const res = await fetch(endpoint, {
    method: 'POST',
    headers,
    body: JSON.stringify(body),
  });

  const json = (await res.json()) as ServerAgentResponse<T> & { error?: string };
  if (!res.ok && !json.agentName) {
    throw new Error(json.error || `Agent endpoint ${endpoint} failed with HTTP ${res.status}.`);
  }
  return json;
}

export type AgentStatusMap = Record<AgentName, AgentRuntimeStatus>;

export const INITIAL_AGENT_STATUSES: AgentStatusMap = {
  'Profile Analysis Agent': 'idle',
  'Skill Gap Analysis Agent': 'idle',
  'Career Matching Agent': 'idle',
  'Learning Recommendation Agent': 'idle',
  'Progress Evaluation Agent': 'idle',
  'AI Mentor Agent': 'idle',
};

export interface OrchestrationHooks {
  mode: WorkspaceExecutionMode;
  onStatusChange: (agent: AgentName, status: AgentRuntimeStatus) => void;
}

export interface FullPipelineResult {
  profileAnalysis?: {
    headline: string;
    backgroundSummary: string;
    strengths: string[];
    learningStrategy: string;
  };
  analysis?: SkillGapAnalysis;
  careerMatches?: {
    recommendedCareer: string;
    matches: CareerMatchResult[];
    executiveAdvice: string;
  };
  roadmap?: LearningRoadmap;
  logs: AgentLogEntry[];
  errors: string[];
}

function makeLog(
  userId: string,
  runId: string,
  agentName: AgentName,
  stepOrder: number,
  res: ServerAgentResponse<unknown>,
): AgentLogEntry {
  return {
    userId,
    runId,
    agentName,
    stepOrder,
    status: res.status,
    inputSummary: res.inputSummary,
    outputSummary: res.outputSummary,
    errorMessage: res.errorMessage ?? '',
    durationMs: res.durationMs,
    timestampIso: new Date().toISOString(),
  };
}

function makeErrorLog(
  userId: string,
  runId: string,
  agentName: AgentName,
  stepOrder: number,
  inputSummary: string,
  err: unknown,
): AgentLogEntry {
  const msg = err instanceof Error ? err.message : String(err);
  return {
    userId,
    runId,
    agentName,
    stepOrder,
    status: 'error',
    inputSummary,
    outputSummary: 'Agent invocation did not complete.',
    errorMessage: msg.slice(0, 480),
    durationMs: 0,
    timestampIso: new Date().toISOString(),
  };
}

/**
 * Parallelized AgentOrchestrator workflow:
 * Phase 1 (parallel): Agent 1 (Profile Analysis) + Agent 2 (Skill Gap) + Agent 3 (Career Matching)
 * Phase 2: Agent 4 (Learning Recommendation) using Agent 2's analysis or deterministic fallback
 */
export async function executeFullOrchestrationPipeline(
  params: {
    profile: LearnerProfile;
    skills: UserSkill[];
    adaptiveMode?: LearningRoadmap['adaptiveMode'];
    adaptationReason?: string;
    focusSkillId?: string;
    weakTopics?: string[];
  },
  hooks: OrchestrationHooks,
): Promise<FullPipelineResult> {
  const { profile, skills, adaptiveMode = 'baseline', adaptationReason, focusSkillId, weakTopics } = params;
  const runId = `run_${Date.now()}`;
  const logs: AgentLogEntry[] = [];
  const errors: string[] = [];

  hooks.onStatusChange('Profile Analysis Agent', 'running');
  hooks.onStatusChange('Skill Gap Analysis Agent', 'running');
  hooks.onStatusChange('Career Matching Agent', 'running');

  let profileAnalysis: FullPipelineResult['profileAnalysis'];
  let analysis: SkillGapAnalysis | undefined;
  let skillGapNarrative: string | undefined;
  let careerMatches: FullPipelineResult['careerMatches'];

  const [p1, p2, p3] = await Promise.all([
    callAgentApi<FullPipelineResult['profileAnalysis']>(
      '/api/agents/profile-analysis',
      { profile, skills },
      hooks.mode,
    )
      .then((res) => {
        logs.push(makeLog(profile.userId, runId, 'Profile Analysis Agent', 1, res));
        if (res.status === 'completed' && res.data) {
          profileAnalysis = res.data;
          hooks.onStatusChange('Profile Analysis Agent', 'completed');
        } else {
          errors.push(res.errorMessage || 'Profile Analysis Agent failed.');
          hooks.onStatusChange('Profile Analysis Agent', 'error');
        }
      })
      .catch((err) => {
        const msg = err instanceof Error ? err.message : String(err);
        errors.push(msg);
        logs.push(makeErrorLog(profile.userId, runId, 'Profile Analysis Agent', 1, `Profile: ${profile.name}`, err));
        hooks.onStatusChange('Profile Analysis Agent', 'error');
      }),

    callAgentApi<{ analysis: SkillGapAnalysis; narrativeSummary: string }>(
      '/api/agents/skill-gap',
      { profile, skills },
      hooks.mode,
    )
      .then((res) => {
        logs.push(makeLog(profile.userId, runId, 'Skill Gap Analysis Agent', 2, res));
        if (res.status === 'completed' && res.data) {
          analysis = res.data.analysis;
          skillGapNarrative = res.data.narrativeSummary;
          hooks.onStatusChange('Skill Gap Analysis Agent', 'completed');
        } else {
          errors.push(res.errorMessage || 'Skill Gap Analysis Agent failed.');
          hooks.onStatusChange('Skill Gap Analysis Agent', 'error');
        }
      })
      .catch((err) => {
        const msg = err instanceof Error ? err.message : String(err);
        errors.push(msg);
        logs.push(makeErrorLog(profile.userId, runId, 'Skill Gap Analysis Agent', 2, `Goal: ${profile.careerGoal}`, err));
        hooks.onStatusChange('Skill Gap Analysis Agent', 'error');
      }),

    callAgentApi<FullPipelineResult['careerMatches']>(
      '/api/agents/career-matching',
      { profile, skills },
      hooks.mode,
    )
      .then((res) => {
        logs.push(makeLog(profile.userId, runId, 'Career Matching Agent', 3, res));
        if (res.status === 'completed' && res.data) {
          careerMatches = res.data;
          hooks.onStatusChange('Career Matching Agent', 'completed');
        } else {
          errors.push(res.errorMessage || 'Career Matching Agent failed.');
          hooks.onStatusChange('Career Matching Agent', 'error');
        }
      })
      .catch((err) => {
        const msg = err instanceof Error ? err.message : String(err);
        errors.push(msg);
        logs.push(makeErrorLog(profile.userId, runId, 'Career Matching Agent', 3, `Goal: ${profile.careerGoal}`, err));
        hooks.onStatusChange('Career Matching Agent', 'error');
      }),
  ]);

  void p1;
  void p2;
  void p3;

  const analysisForRoadmap = analysis ?? calculateSkillGaps(profile.userId, profile.careerGoal, skills);
  let roadmap: LearningRoadmap | undefined;
  hooks.onStatusChange('Learning Recommendation Agent', 'running');
  try {
    const res4 = await callAgentApi<LearningRoadmap>(
      '/api/agents/learning-recommendation',
      {
        profile,
        skills,
        analysis: analysisForRoadmap,
        adaptiveMode,
        adaptationReason,
        focusSkillId,
        weakTopics,
        orchestratorContext: {
          profileStrategy: profileAnalysis?.learningStrategy,
          gapSummary: skillGapNarrative,
          careerAdvice: careerMatches?.executiveAdvice,
        },
      },
      hooks.mode,
    );
    logs.push(makeLog(profile.userId, runId, 'Learning Recommendation Agent', 4, res4));
    if (res4.status === 'completed' && res4.data) {
      roadmap = res4.data;
      hooks.onStatusChange('Learning Recommendation Agent', 'completed');
    } else {
      errors.push(res4.errorMessage || 'Learning Recommendation Agent failed.');
      hooks.onStatusChange('Learning Recommendation Agent', 'error');
    }
  } catch (err) {
    const msg = err instanceof Error ? err.message : String(err);
    errors.push(msg);
    logs.push(makeErrorLog(profile.userId, runId, 'Learning Recommendation Agent', 4, `Goal: ${profile.careerGoal}`, err));
    hooks.onStatusChange('Learning Recommendation Agent', 'error');
  }

  return {
    profileAnalysis,
    analysis,
    careerMatches,
    roadmap,
    logs,
    errors,
  };
}

/**
 * Fast targeted runner for Skill Analysis refresh (~1-2s).
 */
export async function executeSkillGapRefresh(
  params: { profile: LearnerProfile; skills: UserSkill[] },
  hooks: OrchestrationHooks,
): Promise<{
  analysis?: SkillGapAnalysis;
  log: AgentLogEntry;
  error?: string;
}> {
  const { profile, skills } = params;
  const runId = `gap_${Date.now()}`;
  hooks.onStatusChange('Skill Gap Analysis Agent', 'running');

  try {
    const res = await callAgentApi<{ analysis: SkillGapAnalysis; narrativeSummary: string }>(
      '/api/agents/skill-gap',
      { profile, skills },
      hooks.mode,
    );
    const log = makeLog(profile.userId, runId, 'Skill Gap Analysis Agent', 1, res);
    if (res.status === 'completed' && res.data) {
      hooks.onStatusChange('Skill Gap Analysis Agent', 'completed');
      return { analysis: res.data.analysis, log };
    }
    hooks.onStatusChange('Skill Gap Analysis Agent', 'error');
    return { log, error: res.errorMessage || 'Skill Gap Analysis Agent failed.' };
  } catch (err) {
    const msg = err instanceof Error ? err.message : String(err);
    hooks.onStatusChange('Skill Gap Analysis Agent', 'error');
    return {
      log: makeErrorLog(profile.userId, runId, 'Skill Gap Analysis Agent', 1, `Goal: ${profile.careerGoal}`, err),
      error: msg,
    };
  }
}

/**
 * Fast targeted runner for Career Switching:
 * Runs Career Matching Agent (3) + Learning Recommendation Agent (4) in parallel (~1.5-2s).
 */
export async function executeCareerSwitchPipeline(
  params: {
    profile: LearnerProfile;
    skills: UserSkill[];
    analysis: SkillGapAnalysis;
    adaptationReason: string;
  },
  hooks: OrchestrationHooks,
): Promise<{
  careerMatches?: FullPipelineResult['careerMatches'];
  roadmap?: LearningRoadmap;
  logs: AgentLogEntry[];
  errors: string[];
}> {
  const { profile, skills, analysis, adaptationReason } = params;
  const runId = `career_${Date.now()}`;
  const logs: AgentLogEntry[] = [];
  const errors: string[] = [];

  hooks.onStatusChange('Career Matching Agent', 'running');
  hooks.onStatusChange('Learning Recommendation Agent', 'running');

  let careerMatches: FullPipelineResult['careerMatches'];
  let roadmap: LearningRoadmap | undefined;

  await Promise.all([
    callAgentApi<FullPipelineResult['careerMatches']>(
      '/api/agents/career-matching',
      { profile, skills },
      hooks.mode,
    )
      .then((res) => {
        logs.push(makeLog(profile.userId, runId, 'Career Matching Agent', 1, res));
        if (res.status === 'completed' && res.data) {
          careerMatches = res.data;
          hooks.onStatusChange('Career Matching Agent', 'completed');
        } else {
          errors.push(res.errorMessage || 'Career Matching Agent failed.');
          hooks.onStatusChange('Career Matching Agent', 'error');
        }
      })
      .catch((err) => {
        const msg = err instanceof Error ? err.message : String(err);
        errors.push(msg);
        logs.push(makeErrorLog(profile.userId, runId, 'Career Matching Agent', 1, `Goal: ${profile.careerGoal}`, err));
        hooks.onStatusChange('Career Matching Agent', 'error');
      }),

    callAgentApi<LearningRoadmap>(
      '/api/agents/learning-recommendation',
      {
        profile,
        skills,
        analysis,
        adaptiveMode: 'career_switch',
        adaptationReason,
      },
      hooks.mode,
    )
      .then((res) => {
        logs.push(makeLog(profile.userId, runId, 'Learning Recommendation Agent', 2, res));
        if (res.status === 'completed' && res.data) {
          roadmap = res.data;
          hooks.onStatusChange('Learning Recommendation Agent', 'completed');
        } else {
          errors.push(res.errorMessage || 'Learning Recommendation Agent failed.');
          hooks.onStatusChange('Learning Recommendation Agent', 'error');
        }
      })
      .catch((err) => {
        const msg = err instanceof Error ? err.message : String(err);
        errors.push(msg);
        logs.push(makeErrorLog(profile.userId, runId, 'Learning Recommendation Agent', 2, `Goal: ${profile.careerGoal}`, err));
        hooks.onStatusChange('Learning Recommendation Agent', 'error');
      }),
  ]);

  return { careerMatches, roadmap, logs, errors };
}

/**
 * Fast targeted runner for post-assessment Roadmap adaptation (~1-2s).
 */
export async function executeLearningRecommendationOnly(
  params: {
    profile: LearnerProfile;
    skills: UserSkill[];
    analysis: SkillGapAnalysis;
    adaptiveMode: LearningRoadmap['adaptiveMode'];
    adaptationReason: string;
    focusSkillId?: string;
    weakTopics?: string[];
  },
  hooks: OrchestrationHooks,
): Promise<{
  roadmap?: LearningRoadmap;
  log: AgentLogEntry;
  error?: string;
}> {
  const runId = `adapt_${Date.now()}`;
  hooks.onStatusChange('Learning Recommendation Agent', 'running');
  try {
    const res = await callAgentApi<LearningRoadmap>(
      '/api/agents/learning-recommendation',
      params,
      hooks.mode,
    );
    const log = makeLog(params.profile.userId, runId, 'Learning Recommendation Agent', 2, res);
    if (res.status === 'completed' && res.data) {
      hooks.onStatusChange('Learning Recommendation Agent', 'completed');
      return { roadmap: res.data, log };
    }
    hooks.onStatusChange('Learning Recommendation Agent', 'error');
    return { log, error: res.errorMessage || 'Learning Recommendation Agent failed.' };
  } catch (err) {
    const msg = err instanceof Error ? err.message : String(err);
    hooks.onStatusChange('Learning Recommendation Agent', 'error');
    return {
      log: makeErrorLog(params.profile.userId, runId, 'Learning Recommendation Agent', 2, `Mode: ${params.adaptiveMode}`, err),
      error: msg,
    };
  }
}

export interface EvaluationPipelineResult {
  adaptiveMode: 'recovery' | 'practice' | 'progression';
  evaluationSummary: string;
  adaptationReason: string;
  recommendedFocusTopics: string[];
  updatedProficiency: number;
  mastered: boolean;
  logs: AgentLogEntry[];
  error?: string;
}

export async function executeProgressEvaluationAgent(
  params: {
    profile: LearnerProfile;
    skill: UserSkill;
    score: number;
    topicBreakdown: TopicPerformance[];
    weakTopics: string[];
  },
  hooks: OrchestrationHooks,
): Promise<EvaluationPipelineResult> {
  const runId = `eval_${Date.now()}`;
  hooks.onStatusChange('Progress Evaluation Agent', 'running');

  try {
    const res = await callAgentApi<{
      adaptiveMode: 'recovery' | 'practice' | 'progression';
      evaluationSummary: string;
      adaptationReason: string;
      recommendedFocusTopics: string[];
      updatedProficiency: number;
      mastered: boolean;
    }>('/api/agents/progress-evaluation', params, hooks.mode);

    const log = makeLog(params.profile.userId, runId, 'Progress Evaluation Agent', 1, res);

    if (res.status === 'error' || !res.data) {
      hooks.onStatusChange('Progress Evaluation Agent', 'error');
      return {
        adaptiveMode: 'practice',
        evaluationSummary: '',
        adaptationReason: '',
        recommendedFocusTopics: params.weakTopics,
        updatedProficiency: params.skill.proficiency,
        mastered: false,
        logs: [log],
        error: res.errorMessage || 'Progress Evaluation Agent failed.',
      };
    }

    hooks.onStatusChange('Progress Evaluation Agent', 'completed');
    return {
      ...res.data,
      logs: [log],
    };
  } catch (err) {
    const msg = err instanceof Error ? err.message : String(err);
    hooks.onStatusChange('Progress Evaluation Agent', 'error');
    return {
      adaptiveMode: 'practice',
      evaluationSummary: '',
      adaptationReason: '',
      recommendedFocusTopics: params.weakTopics,
      updatedProficiency: params.skill.proficiency,
      mastered: false,
      logs: [
        makeErrorLog(
          params.profile.userId,
          runId,
          'Progress Evaluation Agent',
          1,
          `${params.skill.skillName} (${params.score}%)`,
          err,
        ),
      ],
      error: msg,
    };
  }
}

export async function executeAIMentorAgent(
  params: {
    question: string;
    profile: LearnerProfile;
    skills: UserSkill[];
    analysis: SkillGapAnalysis;
    roadmap: LearningRoadmap | null;
    attempts: AssessmentAttempt[];
    history: MentorMessage[];
  },
  hooks: OrchestrationHooks,
): Promise<{
  reply: string;
  suggestedNextAction: string;
  actionPlan: Array<{ step: string; durationMinutes: number; targetSkill: string }>;
  referencedMetrics: string[];
  log: AgentLogEntry;
}> {
  const runId = `mentor_${Date.now()}`;
  hooks.onStatusChange('AI Mentor Agent', 'running');

  const res = await callAgentApi<{
    reply: string;
    suggestedNextAction: string;
    actionPlan?: Array<{ step: string; durationMinutes: number; targetSkill: string }>;
    referencedMetrics?: string[];
  }>('/api/agents/mentor', params, hooks.mode);

  const log = makeLog(params.profile.userId, runId, 'AI Mentor Agent', 1, res);

  if (res.status === 'error' || !res.data) {
    hooks.onStatusChange('AI Mentor Agent', 'error');
    throw new Error(res.errorMessage || 'AI Mentor Agent failed.');
  }

  hooks.onStatusChange('AI Mentor Agent', 'completed');
  return {
    reply: res.data.reply,
    suggestedNextAction: res.data.suggestedNextAction,
    actionPlan: res.data.actionPlan ?? [],
    referencedMetrics: res.data.referencedMetrics ?? [],
    log,
  };
}
