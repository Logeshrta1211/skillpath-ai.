export {
  auth,
  db,
  googleProvider,
  handleFirestoreError,
  initializeFirebaseAuth,
  OperationType,
  testFirestoreConnection,
  type FirestoreErrorInfo,
} from './lib/firebase.ts';
