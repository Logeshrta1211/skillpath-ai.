import React, { createContext, useCallback, useContext, useEffect, useState } from 'react';
import {
  getRedirectResult,
  onAuthStateChanged,
  signInWithPopup,
  signInWithRedirect,
  signOut,
  type User,
} from 'firebase/auth';
import {
  auth,
  googleProvider,
  initializeFirebaseAuth,
  testFirestoreConnection,
} from '../lib/firebase.ts';
import {
  ASSESSMENT_BANK,
  DEMO_ALEX_SEED,
  SKILLS_CATALOG,
  VERIFIED_RESOURCES,
} from '../shared/catalog.ts';
import {
  buildDeterministicRoadmapStages,
  calculateSkillGaps,
  determineAdaptiveMode,
  matchAllCareers,
  normalizeProficiency,
} from '../shared/skillEngine.ts';
import type {
  AgentLogEntry,
  AgentName,
  AgentRuntimeStatus,
  AssessmentAttempt,
  AssessmentSpec,
  CareerGoal,
  CareerMatchResult,
  LearnerProfile,
  LearningRoadmap,
  LearningTask,
  MentorMessage,
  PageId,
  ProgressRecord,
  SkillGapAnalysis,
  TaskStatus,
  TopicPerformance,
  UserResourceState,
  UserSkill,
} from '../shared/types.ts';
import {
  executeAIMentorAgent,
  executeCareerSwitchPipeline,
  executeFullOrchestrationPipeline,
  executeLearningRecommendationOnly,
  executeProgressEvaluationAgent,
  executeSkillGapRefresh,
  INITIAL_AGENT_STATUSES,
  type AgentStatusMap,
  type FullPipelineResult,
  type WorkspaceExecutionMode,
} from '../services/agentOrchestrator.ts';
import {
  appendAgentLogs,
  appendAssessmentAttempt,
  appendMentorMessage,
  appendProgressRecord,
  clearMentorConversation,
  deleteAllUserData,
  fetchLearnerWorkspace,
  initializeUserCatalogInFirestore,
  saveLearnerProfile,
  saveLearningRoadmapAndTasks,
  saveSkillGapAnalysis,
  saveUserSkills,
  updateResourceState,
} from '../services/firestoreService.ts';

const LOCAL_WORKSPACE_KEY = 'skillpath_local_workspace_v1';

interface LocalWorkspaceSnapshot {
  profile: LearnerProfile;
  skills: UserSkill[];
  analysis: SkillGapAnalysis | null;
  careerMatches: CareerMatchResult[];
  profileInsight: FullPipelineResult['profileAnalysis'] | null;
  careerAdvice: string | null;
  roadmap: LearningRoadmap | null;
  tasks: LearningTask[];
  resources: UserResourceState[];
  attempts: AssessmentAttempt[];
  progress: ProgressRecord[];
  agentLogs: AgentLogEntry[];
  mentorMessages: MentorMessage[];
}

interface AppContextValue {
  currentPage: PageId;
  setCurrentPage: (page: PageId) => void;
  user: User | null;
  authReady: boolean;
  isDemoMode: boolean;
  isLocalSession: boolean;
  isLoadingWorkspace: boolean;
  isOrchestrating: boolean;
  orchestratorError: string | null;
  authErrorCode: string | null;
  clearError: () => void;
  agentStatuses: AgentStatusMap;

  profile: LearnerProfile | null;
  skills: UserSkill[];
  analysis: SkillGapAnalysis | null;
  careerMatches: CareerMatchResult[];
  profileInsight: FullPipelineResult['profileAnalysis'] | null;
  careerAdvice: string | null;
  roadmap: LearningRoadmap | null;
  tasks: LearningTask[];
  resources: UserResourceState[];
  attempts: AssessmentAttempt[];
  progress: ProgressRecord[];
  agentLogs: AgentLogEntry[];
  mentorMessages: MentorMessage[];

  signInWithGoogle: () => Promise<void>;
  signInWithGoogleRedirect: () => Promise<void>;
  createLocalLearnerWorkspace: (params: {
    name: string;
    email: string;
    careerGoal: CareerGoal;
    weeklyHours?: number;
  }) => Promise<void>;
  resumeLocalLearnerWorkspace: () => boolean;
  hasSavedLocalWorkspace: boolean;
  signOutUser: () => Promise<void>;
  enterDemoMode: () => Promise<void>;
  resetDemoScenario: () => Promise<void>;

  saveProfileAndSkills: (
    updatedProfile: LearnerProfile,
    updatedSkills: UserSkill[],
  ) => Promise<void>;
  switchCareerGoal: (newGoal: CareerGoal) => Promise<void>;
  refreshSkillGapOnly: () => Promise<void>;
  runOrchestrationNow: () => Promise<void>;
  submitAssessment: (
    assessment: AssessmentSpec,
    selectedAnswers: number[],
  ) => Promise<AssessmentAttempt>;
  runDemoScenario: (scenario: 'A' | 'B' | 'C') => Promise<void>;
  updateStageStatus: (stageId: string, nextStatus: TaskStatus) => Promise<void>;
  toggleResourceFlag: (resourceId: string, field: 'bookmarked' | 'completed') => Promise<void>;
  askMentor: (question: string) => Promise<void>;
  clearMentorChat: () => Promise<void>;
  wipeAuthenticatedAccountData: () => Promise<void>;
}

const AppContext = createContext<AppContextValue | null>(null);

function createDefaultUserWorkspace(
  uid: string,
  name: string,
  email: string,
  careerGoal: CareerGoal = 'Full Stack Developer',
  weeklyHours = 10,
): {
  profile: LearnerProfile;
  skills: UserSkill[];
} {
  return {
    profile: {
      userId: uid,
      name: (name || 'New Learner').trim(),
      email: (email || `${uid}@learner.skillpath.local`).trim(),
      education: 'Undergraduate Computer Science',
      college: '',
      department: 'Computer Science',
      yearOfStudy: '3rd Year',
      careerGoal,
      certifications: [],
      projects: [],
      learningPreferences: {
        weeklyHours: Math.min(80, Math.max(1, weeklyHours || 10)),
        learningStyle: 'Hands-on Projects & Interactive Quizzes',
        pace: 'Balanced Weekly Milestones',
      },
      adaptiveConfig: {
        recoveryThreshold: 50,
        progressionThreshold: 85,
      },
    },
    skills: SKILLS_CATALOG.map((s) => ({
      userId: uid,
      skillId: s.skillId,
      skillName: s.skillName,
      category: s.category,
      proficiency: 0,
      evidenceCount: 0,
      weakTopics: [],
      mastered: false,
    })),
  };
}

function formatFirebaseAuthError(err: unknown): { message: string; code: string | null } {
  const code =
    typeof err === 'object' && err !== null && 'code' in err
      ? String((err as { code: unknown }).code)
      : null;
  const host = typeof window !== 'undefined' ? window.location.hostname : 'this domain';

  if (code === 'auth/unauthorized-domain') {
    return {
      code,
      message: `Google Sign-In is blocked on "${host}" because this preview hostname is not listed in Firebase Authentication Authorized Domains. Add "${host}" in Firebase Console or launch your Personal Local Workspace below.`,
    };
  }
  if (code === 'auth/popup-blocked' || code === 'auth/operation-not-supported-in-this-environment') {
    return {
      code,
      message: `Your browser or embedded preview iframe blocked the Google Sign-In popup. Try "Continue via Google Redirect" or launch your Personal Local Workspace below.`,
    };
  }
  if (code === 'auth/popup-closed-by-user' || code === 'auth/cancelled-popup-request') {
    return {
      code,
      message: 'Google Sign-In popup was closed before finishing. Click Continue with Google to retry.',
    };
  }
  if (code === 'auth/web-storage-unsupported' || code === 'auth/internal-error') {
    return {
      code,
      message:
        'Browser storage restrictions interrupted Google authentication in this preview frame. Please retry or launch your Personal Local Workspace below.',
    };
  }
  return {
    code,
    message: err instanceof Error ? err.message : 'Google Sign-In failed.',
  };
}

export function AppProvider({ children }: { children: React.ReactNode }) {
  const [currentPage, setCurrentPage] = useState<PageId>('landing');
  const [user, setUser] = useState<User | null>(null);
  const [authReady, setAuthReady] = useState(false);
  const [isDemoMode, setIsDemoMode] = useState(false);
  const [isLocalSession, setIsLocalSession] = useState(false);
  const [isLoadingWorkspace, setIsLoadingWorkspace] = useState(false);
  const [isOrchestrating, setIsOrchestrating] = useState(false);
  const [orchestratorError, setOrchestratorError] = useState<string | null>(null);
  const [authErrorCode, setAuthErrorCode] = useState<string | null>(null);
  const [agentStatuses, setAgentStatuses] = useState<AgentStatusMap>(INITIAL_AGENT_STATUSES);

  const [profile, setProfile] = useState<LearnerProfile | null>(null);
  const [skills, setSkills] = useState<UserSkill[]>([]);
  const [analysis, setAnalysis] = useState<SkillGapAnalysis | null>(null);
  const [careerMatches, setCareerMatches] = useState<CareerMatchResult[]>([]);
  const [profileInsight, setProfileInsight] = useState<FullPipelineResult['profileAnalysis'] | null>(null);
  const [careerAdvice, setCareerAdvice] = useState<string | null>(null);
  const [roadmap, setRoadmap] = useState<LearningRoadmap | null>(null);
  const [tasks, setTasks] = useState<LearningTask[]>([]);
  const [resources, setResources] = useState<UserResourceState[]>([]);
  const [attempts, setAttempts] = useState<AssessmentAttempt[]>([]);
  const [progress, setProgress] = useState<ProgressRecord[]>([]);
  const [agentLogs, setAgentLogs] = useState<AgentLogEntry[]>([]);
  const [mentorMessages, setMentorMessages] = useState<MentorMessage[]>([]);
  const [hasSavedLocalWorkspace, setHasSavedLocalWorkspace] = useState<boolean>(() => {
    try {
      return Boolean(typeof window !== 'undefined' && window.localStorage.getItem(LOCAL_WORKSPACE_KEY));
    } catch {
      return false;
    }
  });

  const executionMode: WorkspaceExecutionMode = isDemoMode
    ? 'demo'
    : isLocalSession || !user
      ? 'local'
      : 'firebase';

  const handleAgentStatus = useCallback((agent: AgentName, status: AgentRuntimeStatus) => {
    setAgentStatuses((prev) => ({ ...prev, [agent]: status }));
  }, []);

  const clearError = useCallback(() => {
    setOrchestratorError(null);
    setAuthErrorCode(null);
  }, []);

  // Persist local learner workspace whenever state changes in local session mode
  useEffect(() => {
    if (!isLocalSession || isDemoMode || user || !profile) return;
    try {
      const snapshot: LocalWorkspaceSnapshot = {
        profile,
        skills,
        analysis,
        careerMatches,
        profileInsight,
        careerAdvice,
        roadmap,
        tasks,
        resources,
        attempts,
        progress,
        agentLogs,
        mentorMessages,
      };
      window.localStorage.setItem(LOCAL_WORKSPACE_KEY, JSON.stringify(snapshot));
      setHasSavedLocalWorkspace(true);
    } catch {
      // Ignore storage quota errors
    }
  }, [
    isLocalSession,
    isDemoMode,
    user,
    profile,
    skills,
    analysis,
    careerMatches,
    profileInsight,
    careerAdvice,
    roadmap,
    tasks,
    resources,
    attempts,
    progress,
    agentLogs,
    mentorMessages,
  ]);

  // Test Firestore connection on boot
  useEffect(() => {
    void testFirestoreConnection();
  }, []);

  // Load authenticated user workspace from Firestore (with resilient fallback so UI never stalls blank)
  const loadAuthenticatedWorkspace = useCallback(async (firebaseUser: User) => {
    setIsLoadingWorkspace(true);
    setOrchestratorError(null);

    const safeName = firebaseUser.displayName || 'Learner';
    const safeEmail = firebaseUser.email || `${firebaseUser.uid}@learner.skillpath.local`;
    const defaults = createDefaultUserWorkspace(firebaseUser.uid, safeName, safeEmail);

    try {
      await firebaseUser.getIdToken();
      const ws = await fetchLearnerWorkspace(firebaseUser.uid);

      if (!ws.profile) {
        const initialAnalysis = calculateSkillGaps(
          firebaseUser.uid,
          defaults.profile.careerGoal,
          defaults.skills,
        );
        const initialStages = buildDeterministicRoadmapStages(
          defaults.profile,
          defaults.skills,
          initialAnalysis,
          'baseline',
        );
        const initialRoadmap: LearningRoadmap = {
          userId: firebaseUser.uid,
          careerGoal: defaults.profile.careerGoal,
          adaptiveMode: 'baseline',
          adaptationReason: 'Initial baseline roadmap created upon account registration.',
          summary: `Baseline ${defaults.profile.careerGoal} learning plan across ${initialStages.length} prioritized skills.`,
          stages: initialStages,
        };

        // Populate UI immediately so there is zero blank delay
        setProfile(defaults.profile);
        setSkills(defaults.skills);
        setAnalysis(initialAnalysis);
        setCareerMatches(matchAllCareers(firebaseUser.uid, defaults.skills));
        setRoadmap(initialRoadmap);
        setTasks(
          initialStages.map((s) => ({
            userId: firebaseUser.uid,
            roadmapId: `${firebaseUser.uid}_active_roadmap`,
            skillId: s.skillId,
            title: s.learningObjective,
            stageOrder: s.order,
            status: s.status,
            estimatedHours: s.estimatedHours,
          })),
        );
        setResources(
          VERIFIED_RESOURCES.map((r) => ({
            ...r,
            userId: firebaseUser.uid,
            bookmarked: false,
            completed: false,
          })),
        );
        setAttempts([]);
        setProgress([]);
        setAgentLogs([]);
        setMentorMessages([]);

        // Persist core profile & workspace to Firestore in parallel
        await Promise.all([
          saveLearnerProfile(defaults.profile),
          saveUserSkills(firebaseUser.uid, defaults.skills),
          saveSkillGapAnalysis(initialAnalysis),
          saveLearningRoadmapAndTasks(initialRoadmap),
        ]);

        // Seed catalog collections non-blockingly so first login is snappy
        void initializeUserCatalogInFirestore(firebaseUser.uid).catch((seedErr) => {
          console.warn('Non-blocking catalog seed warning:', seedErr);
        });
      } else {
        const mergedSkills: UserSkill[] = SKILLS_CATALOG.map((cat) => {
          const existing = ws.skills.find((s) => s.skillId === cat.skillId);
          return (
            existing ?? {
              userId: firebaseUser.uid,
              skillId: cat.skillId,
              skillName: cat.skillName,
              category: cat.category,
              proficiency: 0,
              evidenceCount: 0,
              weakTopics: [],
              mastered: false,
            }
          );
        });
        const computedAnalysis =
          ws.analysis ?? calculateSkillGaps(firebaseUser.uid, ws.profile.careerGoal, mergedSkills);
        const computedRoadmap =
          ws.roadmap ?? {
            userId: firebaseUser.uid,
            careerGoal: ws.profile.careerGoal,
            adaptiveMode: 'baseline' as const,
            adaptationReason: 'Baseline roadmap restored from learner profile.',
            summary: `Personalized roadmap for ${ws.profile.careerGoal}.`,
            stages: buildDeterministicRoadmapStages(ws.profile, mergedSkills, computedAnalysis, 'baseline'),
          };

        setProfile(ws.profile);
        setSkills(mergedSkills);
        setAnalysis(computedAnalysis);
        setCareerMatches(matchAllCareers(firebaseUser.uid, mergedSkills));
        setRoadmap(computedRoadmap);
        setTasks(ws.tasks);
        setResources(ws.resources);
        setAttempts(ws.attempts);
        setProgress(ws.progress);
        setAgentLogs(ws.agentLogs);
        setMentorMessages(ws.mentorMessages);
      }
    } catch (err) {
      const msg = err instanceof Error ? err.message : 'Failed to load learner workspace from Firestore.';
      setOrchestratorError(msg);
      // Fallback to active session state so user is never trapped on a blank screen
      const fallbackAnalysis = calculateSkillGaps(
        firebaseUser.uid,
        defaults.profile.careerGoal,
        defaults.skills,
      );
      const fallbackStages = buildDeterministicRoadmapStages(
        defaults.profile,
        defaults.skills,
        fallbackAnalysis,
        'baseline',
      );
      setProfile((prev) => prev ?? defaults.profile);
      setSkills((prev) => (prev.length > 0 ? prev : defaults.skills));
      setAnalysis((prev) => prev ?? fallbackAnalysis);
      setCareerMatches(matchAllCareers(firebaseUser.uid, defaults.skills));
      setRoadmap((prev) =>
        prev ?? {
          userId: firebaseUser.uid,
          careerGoal: defaults.profile.careerGoal,
          adaptiveMode: 'baseline',
          adaptationReason: 'Local fallback workspace loaded while Cloud Firestore sync resolves.',
          summary: `Baseline ${defaults.profile.careerGoal} plan across ${fallbackStages.length} prioritized stages.`,
          stages: fallbackStages,
        },
      );
    } finally {
      setIsLoadingWorkspace(false);
    }
  }, []);

  // Initialize Firebase Auth persistence & redirect state BEFORE attaching auth listener or allowing interactions
  useEffect(() => {
    let active = true;
    let unsub: (() => void) | undefined;

    (async () => {
      await initializeFirebaseAuth();
      if (!active) return;

      if (!auth.currentUser) {
        try {
          await getRedirectResult(auth);
        } catch (err) {
          const code =
            typeof err === 'object' && err !== null && 'code' in err
              ? String((err as { code: unknown }).code)
              : '';
          if (code !== 'auth/no-auth-event' && code !== 'auth/null-user') {
            const formatted = formatFirebaseAuthError(err);
            setAuthErrorCode(formatted.code);
            setOrchestratorError(formatted.message);
          }
        }
      }

      if (!active) return;
      unsub = onAuthStateChanged(auth, async (firebaseUser) => {
        if (!active) return;
        setUser(firebaseUser);
        setAuthReady(true);
        if (firebaseUser) {
          setIsDemoMode(false);
          setIsLocalSession(false);
          await loadAuthenticatedWorkspace(firebaseUser);
          if (active) {
            setCurrentPage((prev) => (prev === 'landing' || prev === 'auth' ? 'dashboard' : prev));
          }
        }
      });
    })();

    return () => {
      active = false;
      if (unsub) unsub();
    };
  }, [loadAuthenticatedWorkspace]);

  const signInWithGoogle = useCallback(async () => {
    setOrchestratorError(null);
    setAuthErrorCode(null);
    try {
      await initializeFirebaseAuth();
      await signInWithPopup(auth, googleProvider);
    } catch (err) {
      const formatted = formatFirebaseAuthError(err);
      setAuthErrorCode(formatted.code);
      setOrchestratorError(formatted.message);
      throw err;
    }
  }, []);

  const signInWithGoogleRedirect = useCallback(async () => {
    setOrchestratorError(null);
    setAuthErrorCode(null);
    try {
      await initializeFirebaseAuth();
      await signInWithRedirect(auth, googleProvider);
    } catch (err) {
      const formatted = formatFirebaseAuthError(err);
      setAuthErrorCode(formatted.code);
      setOrchestratorError(formatted.message);
      throw err;
    }
  }, []);

  const createLocalLearnerWorkspace = useCallback(
    async (params: {
      name: string;
      email: string;
      careerGoal: CareerGoal;
      weeklyHours?: number;
    }) => {
      setOrchestratorError(null);
      setAuthErrorCode(null);
      const localUid = `local_${Date.now()}`;
      const defaults = createDefaultUserWorkspace(
        localUid,
        params.name,
        params.email,
        params.careerGoal,
        params.weeklyHours ?? 10,
      );
      const baseAnalysis = calculateSkillGaps(localUid, defaults.profile.careerGoal, defaults.skills);
      const baseStages = buildDeterministicRoadmapStages(
        defaults.profile,
        defaults.skills,
        baseAnalysis,
        'baseline',
      );
      const baseRoadmap: LearningRoadmap = {
        userId: localUid,
        careerGoal: defaults.profile.careerGoal,
        adaptiveMode: 'baseline',
        adaptationReason: `Personal workspace initialized for ${defaults.profile.name} targeting ${defaults.profile.careerGoal}.`,
        summary: `Prioritized ${defaults.profile.careerGoal} roadmap across ${baseStages.length} skill stages.`,
        stages: baseStages,
      };

      setIsDemoMode(false);
      setIsLocalSession(true);
      setProfile(defaults.profile);
      setSkills(defaults.skills);
      setAnalysis(baseAnalysis);
      setCareerMatches(matchAllCareers(localUid, defaults.skills));
      setProfileInsight(null);
      setCareerAdvice(null);
      setRoadmap(baseRoadmap);
      setTasks(
        baseStages.map((s) => ({
          userId: localUid,
          roadmapId: `${localUid}_active_roadmap`,
          skillId: s.skillId,
          title: s.learningObjective,
          stageOrder: s.order,
          status: s.status,
          estimatedHours: s.estimatedHours,
        })),
      );
      setResources(
        VERIFIED_RESOURCES.map((r) => ({
          ...r,
          userId: localUid,
          bookmarked: false,
          completed: false,
        })),
      );
      setAttempts([]);
      setProgress([
        {
          userId: localUid,
          eventType: 'profile_update',
          skillId: 'profile',
          skillName: defaults.profile.careerGoal,
          readinessScore: baseAnalysis.readinessScore,
          detail: `Created personal learner workspace for ${defaults.profile.name}.`,
          timestampIso: new Date().toISOString(),
        },
      ]);
      setAgentLogs([]);
      setMentorMessages([]);
      setAgentStatuses(INITIAL_AGENT_STATUSES);
      setCurrentPage('dashboard');
    },
    [],
  );

  const resumeLocalLearnerWorkspace = useCallback((): boolean => {
    try {
      const raw = window.localStorage.getItem(LOCAL_WORKSPACE_KEY);
      if (!raw) return false;
      const saved = JSON.parse(raw) as LocalWorkspaceSnapshot;
      if (!saved?.profile) return false;

      setOrchestratorError(null);
      setAuthErrorCode(null);
      setIsDemoMode(false);
      setIsLocalSession(true);
      setProfile(saved.profile);
      setSkills(saved.skills ?? []);
      setAnalysis(saved.analysis ?? null);
      setCareerMatches(saved.careerMatches ?? []);
      setProfileInsight(saved.profileInsight ?? null);
      setCareerAdvice(saved.careerAdvice ?? null);
      setRoadmap(saved.roadmap ?? null);
      setTasks(saved.tasks ?? []);
      setResources(saved.resources ?? []);
      setAttempts(saved.attempts ?? []);
      setProgress(saved.progress ?? []);
      setAgentLogs(saved.agentLogs ?? []);
      setMentorMessages(saved.mentorMessages ?? []);
      setCurrentPage('dashboard');
      return true;
    } catch {
      return false;
    }
  }, []);

  const signOutUser = useCallback(async () => {
    try {
      if (auth.currentUser) {
        await signOut(auth);
      }
    } catch {
      // Ignore Firebase signOut error in non-Firebase sessions
    }
    setIsDemoMode(false);
    setIsLocalSession(false);
    setOrchestratorError(null);
    setAuthErrorCode(null);
    setProfile(null);
    setSkills([]);
    setAnalysis(null);
    setCareerMatches([]);
    setProfileInsight(null);
    setCareerAdvice(null);
    setRoadmap(null);
    setTasks([]);
    setResources([]);
    setAttempts([]);
    setProgress([]);
    setAgentLogs([]);
    setMentorMessages([]);
    setAgentStatuses(INITIAL_AGENT_STATUSES);
    setCurrentPage('landing');
  }, []);

  const buildDemoBaseline = useCallback(
    async (runAgents: boolean) => {
      const seedProfile = structuredClone(DEMO_ALEX_SEED.profile);
      const seedSkills = structuredClone(DEMO_ALEX_SEED.skills);
      const allSeededSkills: UserSkill[] = SKILLS_CATALOG.map((cat) => {
        const existing = seedSkills.find((s) => s.skillId === cat.skillId);
        return (
          existing ?? {
            userId: seedProfile.userId,
            skillId: cat.skillId,
            skillName: cat.skillName,
            category: cat.category,
            proficiency: 0,
            evidenceCount: 0,
            weakTopics: [],
            mastered: false,
          }
        );
      });

      const baseAnalysis = calculateSkillGaps(seedProfile.userId, seedProfile.careerGoal, allSeededSkills);
      const baseStages = buildDeterministicRoadmapStages(
        seedProfile,
        allSeededSkills,
        baseAnalysis,
        'baseline',
      );
      const baseRoadmap: LearningRoadmap = {
        userId: seedProfile.userId,
        careerGoal: seedProfile.careerGoal,
        adaptiveMode: 'baseline',
        adaptationReason: 'Initial baseline generated for Alex Rivera targeting Full Stack Developer.',
        summary: `Prioritized Full Stack roadmap addressing JavaScript, CSS, React, and Node.js gaps while leveraging Python and SQL strengths.`,
        stages: baseStages,
      };

      setIsDemoMode(true);
      setIsLocalSession(false);
      setProfile(seedProfile);
      setSkills(allSeededSkills);
      setAnalysis(baseAnalysis);
      setCareerMatches(matchAllCareers(seedProfile.userId, allSeededSkills));
      setRoadmap(baseRoadmap);
      setTasks(
        baseStages.map((s) => ({
          userId: seedProfile.userId,
          roadmapId: 'demo_roadmap',
          skillId: s.skillId,
          title: s.learningObjective,
          stageOrder: s.order,
          status: s.status,
          estimatedHours: s.estimatedHours,
        })),
      );
      setResources(
        VERIFIED_RESOURCES.map((r) => ({
          ...r,
          userId: seedProfile.userId,
          bookmarked: false,
          completed: false,
        })),
      );
      setAttempts([]);
      setProgress([
        {
          userId: seedProfile.userId,
          eventType: 'profile_update',
          skillId: 'javascript',
          skillName: 'Full Stack Developer',
          readinessScore: baseAnalysis.readinessScore,
          detail: 'Initialized demo learner Alex Rivera (Python: Intermediate, SQL: Intermediate, HTML: Beginner).',
          timestampIso: new Date().toISOString(),
        },
      ]);
      setAgentLogs([]);
      setMentorMessages([]);
      setAgentStatuses(INITIAL_AGENT_STATUSES);
      setCurrentPage('dashboard');

      if (runAgents) {
        setIsOrchestrating(true);
        try {
          const res = await executeFullOrchestrationPipeline(
            { profile: seedProfile, skills: allSeededSkills, adaptiveMode: 'baseline' },
            { mode: 'demo', onStatusChange: handleAgentStatus },
          );
          if (res.profileAnalysis) setProfileInsight(res.profileAnalysis);
          if (res.analysis) setAnalysis(res.analysis);
          if (res.careerMatches) {
            setCareerMatches(res.careerMatches.matches);
            setCareerAdvice(res.careerMatches.executiveAdvice);
          }
          if (res.roadmap) setRoadmap(res.roadmap);
          setAgentLogs((prev) => [...res.logs, ...prev]);
        } catch (err) {
          setOrchestratorError(err instanceof Error ? err.message : 'Agent pipeline encountered an error.');
        } finally {
          setIsOrchestrating(false);
        }
      }
      return { profile: seedProfile, skills: allSeededSkills };
    },
    [handleAgentStatus],
  );

  const enterDemoMode = useCallback(async () => {
    setOrchestratorError(null);
    await buildDemoBaseline(true);
  }, [buildDemoBaseline]);

  const resetDemoScenario = useCallback(async () => {
    setOrchestratorError(null);
    await buildDemoBaseline(true);
  }, [buildDemoBaseline]);

  const persistRoadmapAndLogs = useCallback(
    async (
      nextProfile: LearnerProfile,
      nextAnalysis: SkillGapAnalysis,
      nextRoadmap: LearningRoadmap,
      newLogs: AgentLogEntry[],
      progressEvent?: ProgressRecord,
    ) => {
      setAnalysis(nextAnalysis);
      setRoadmap(nextRoadmap);
      setTasks(
        nextRoadmap.stages.map((s) => ({
          userId: nextProfile.userId,
          roadmapId: `${nextProfile.userId}_active_roadmap`,
          skillId: s.skillId,
          title: s.learningObjective,
          stageOrder: s.order,
          status: s.status,
          estimatedHours: s.estimatedHours,
        })),
      );
      if (newLogs.length > 0) {
        setAgentLogs((prev) => [...newLogs, ...prev]);
      }
      if (progressEvent) {
        setProgress((prev) => [progressEvent, ...prev]);
      }

      if (!isDemoMode && !isLocalSession && user && nextProfile.userId === user.uid) {
        await Promise.all([
          saveSkillGapAnalysis(nextAnalysis),
          saveLearningRoadmapAndTasks(nextRoadmap),
          appendAgentLogs(newLogs),
          progressEvent ? appendProgressRecord(progressEvent) : Promise.resolve(''),
        ]);
      }
    },
    [isDemoMode, isLocalSession, user],
  );

  const runOrchestrationNow = useCallback(async () => {
    if (!profile) return;
    setIsOrchestrating(true);
    setOrchestratorError(null);
    try {
      const res = await executeFullOrchestrationPipeline(
        {
          profile,
          skills,
          adaptiveMode: roadmap?.adaptiveMode ?? 'baseline',
          adaptationReason: roadmap?.adaptationReason,
        },
        { mode: executionMode, onStatusChange: handleAgentStatus },
      );

      if (res.profileAnalysis) setProfileInsight(res.profileAnalysis);
      if (res.careerMatches) {
        setCareerMatches(res.careerMatches.matches);
        setCareerAdvice(res.careerMatches.executiveAdvice);
      }

      const nextAnalysis = res.analysis ?? calculateSkillGaps(profile.userId, profile.careerGoal, skills);
      const nextRoadmap = res.roadmap ?? roadmap ?? {
        userId: profile.userId,
        careerGoal: profile.careerGoal,
        adaptiveMode: 'baseline',
        adaptationReason: 'Updated via deterministic skill gap calculation.',
        summary: `Roadmap for ${profile.careerGoal}`,
        stages: buildDeterministicRoadmapStages(profile, skills, nextAnalysis, 'baseline'),
      };

      await persistRoadmapAndLogs(profile, nextAnalysis, nextRoadmap, res.logs);
      if (res.errors.length > 0 && !res.analysis && !res.roadmap) {
        setOrchestratorError(res.errors[0]);
      }
    } catch (err) {
      setOrchestratorError(err instanceof Error ? err.message : 'Orchestration failed.');
    } finally {
      setIsOrchestrating(false);
    }
  }, [profile, skills, roadmap, executionMode, handleAgentStatus, persistRoadmapAndLogs]);

  const refreshSkillGapOnly = useCallback(async () => {
    if (!profile) return;
    setIsOrchestrating(true);
    setOrchestratorError(null);

    // Immediately recompute deterministic baseline
    const baseAnalysis = calculateSkillGaps(profile.userId, profile.careerGoal, skills);
    setAnalysis(baseAnalysis);

    try {
      const res = await executeSkillGapRefresh(
        { profile, skills },
        { mode: executionMode, onStatusChange: handleAgentStatus },
      );
      const finalAnalysis = res.analysis ?? baseAnalysis;
      setAnalysis(finalAnalysis);
      setAgentLogs((prev) => [res.log, ...prev]);

      if (!isDemoMode && !isLocalSession && user && profile.userId === user.uid) {
        await Promise.all([
          saveSkillGapAnalysis(finalAnalysis),
          appendAgentLogs([res.log]),
        ]);
      }
    } catch (err) {
      setOrchestratorError(err instanceof Error ? err.message : 'Skill gap refresh failed.');
    } finally {
      setIsOrchestrating(false);
    }
  }, [profile, skills, executionMode, isDemoMode, isLocalSession, user, handleAgentStatus]);

  const saveProfileAndSkills = useCallback(
    async (updatedProfile: LearnerProfile, updatedSkills: UserSkill[]) => {
      setIsOrchestrating(true);
      setOrchestratorError(null);

      // 1. Instant deterministic updates + persistence FIRST (never blocked by AI)
      const baseAnalysis = calculateSkillGaps(
        updatedProfile.userId,
        updatedProfile.careerGoal,
        updatedSkills,
      );
      const baseMatches = matchAllCareers(updatedProfile.userId, updatedSkills);
      const baseRoadmap: LearningRoadmap = {
        userId: updatedProfile.userId,
        careerGoal: updatedProfile.careerGoal,
        adaptiveMode: 'baseline',
        adaptationReason: `Profile and skill baseline updated for ${updatedProfile.careerGoal}.`,
        summary: `Personalized roadmap for ${updatedProfile.careerGoal}.`,
        stages: buildDeterministicRoadmapStages(updatedProfile, updatedSkills, baseAnalysis, 'baseline'),
      };
      const progEvent: ProgressRecord = {
        userId: updatedProfile.userId,
        eventType: 'profile_update',
        skillId: 'profile',
        skillName: updatedProfile.careerGoal,
        readinessScore: baseAnalysis.readinessScore,
        detail: `Updated learner profile & skill matrix. Career readiness: ${baseAnalysis.readinessScore}%.`,
        timestampIso: new Date().toISOString(),
      };

      setProfile(updatedProfile);
      setSkills(updatedSkills);
      setCareerMatches(baseMatches);
      setAnalysis(baseAnalysis);
      setRoadmap(baseRoadmap);
      setTasks(
        baseRoadmap.stages.map((s) => ({
          userId: updatedProfile.userId,
          roadmapId: `${updatedProfile.userId}_active_roadmap`,
          skillId: s.skillId,
          title: s.learningObjective,
          stageOrder: s.order,
          status: s.status,
          estimatedHours: s.estimatedHours,
        })),
      );
      setProgress((prev) => [progEvent, ...prev]);

      try {
        if (!isDemoMode && !isLocalSession && user && updatedProfile.userId === user.uid) {
          await Promise.all([
            saveLearnerProfile(updatedProfile),
            saveUserSkills(updatedProfile.userId, updatedSkills),
            saveSkillGapAnalysis(baseAnalysis),
            saveLearningRoadmapAndTasks(baseRoadmap),
            appendProgressRecord(progEvent),
          ]);
        }
      } catch (err) {
        setIsOrchestrating(false);
        const msg = err instanceof Error ? err.message : 'Failed to save profile to Firestore.';
        setOrchestratorError(msg);
        throw err;
      }

      // 2. Non-fatal parallel AI enrichment (Agents 1-3 parallel, then 4)
      try {
        const res = await executeFullOrchestrationPipeline(
          {
            profile: updatedProfile,
            skills: updatedSkills,
            adaptiveMode: 'baseline',
            adaptationReason: `Profile and skill baseline updated for ${updatedProfile.careerGoal}.`,
          },
          { mode: executionMode, onStatusChange: handleAgentStatus },
        );

        if (res.profileAnalysis) setProfileInsight(res.profileAnalysis);
        if (res.careerMatches) {
          setCareerMatches(res.careerMatches.matches);
          setCareerAdvice(res.careerMatches.executiveAdvice);
        }

        const nextAnalysis = res.analysis ?? baseAnalysis;
        const nextRoadmap = res.roadmap ?? baseRoadmap;
        await persistRoadmapAndLogs(updatedProfile, nextAnalysis, nextRoadmap, res.logs);
      } catch (aiErr) {
        console.warn('AI enrichment after profile save fell back to deterministic baseline:', aiErr);
      } finally {
        setIsOrchestrating(false);
      }
    },
    [isDemoMode, isLocalSession, user, executionMode, handleAgentStatus, persistRoadmapAndLogs],
  );

  const switchCareerGoal = useCallback(
    async (
      newGoal: CareerGoal,
      override?: { profile: LearnerProfile; skills: UserSkill[]; mode: WorkspaceExecutionMode },
    ) => {
      const activeProfile = override?.profile ?? profile;
      const activeSkills = override?.skills ?? skills;
      const activeMode = override?.mode ?? executionMode;
      if (!activeProfile) return;
      const previousGoal = activeProfile.careerGoal;
      const updatedProfile: LearnerProfile = { ...activeProfile, careerGoal: newGoal };
      const reason = `Career goal switched from ${previousGoal} to ${newGoal}. Completed assessment history and existing skill proficiencies were preserved while recalculating gaps and reordering stages.`;

      setIsOrchestrating(true);
      setOrchestratorError(null);

      // 1. Instant deterministic career switch update
      const baseAnalysis = calculateSkillGaps(updatedProfile.userId, newGoal, activeSkills);
      const baseRoadmap: LearningRoadmap = {
        userId: updatedProfile.userId,
        careerGoal: newGoal,
        adaptiveMode: 'career_switch',
        adaptationReason: reason,
        summary: `Transition roadmap for ${newGoal} preserving completed learning history.`,
        stages: buildDeterministicRoadmapStages(updatedProfile, activeSkills, baseAnalysis, 'career_switch'),
      };
      const progEvent: ProgressRecord = {
        userId: updatedProfile.userId,
        eventType: 'goal_switch',
        skillId: 'career-goal',
        skillName: newGoal,
        readinessScore: baseAnalysis.readinessScore,
        detail: `Switched goal from ${previousGoal} to ${newGoal}. Recalculated readiness: ${baseAnalysis.readinessScore}%.`,
        timestampIso: new Date().toISOString(),
      };

      setProfile(updatedProfile);
      setAnalysis(baseAnalysis);
      setRoadmap(baseRoadmap);
      setTasks(
        baseRoadmap.stages.map((s) => ({
          userId: updatedProfile.userId,
          roadmapId: `${updatedProfile.userId}_active_roadmap`,
          skillId: s.skillId,
          title: s.learningObjective,
          stageOrder: s.order,
          status: s.status,
          estimatedHours: s.estimatedHours,
        })),
      );
      setProgress((prev) => [progEvent, ...prev]);

      const shouldPersistCloud =
        activeMode === 'firebase' && Boolean(user) && updatedProfile.userId === user?.uid;

      try {
        if (shouldPersistCloud) {
          await Promise.all([
            saveLearnerProfile(updatedProfile),
            saveSkillGapAnalysis(baseAnalysis),
            saveLearningRoadmapAndTasks(baseRoadmap),
            appendProgressRecord(progEvent),
          ]);
        }

        // 2. Fast parallel Agent 3 + Agent 4 enrichment (~1.5-2s)
        const res = await executeCareerSwitchPipeline(
          {
            profile: updatedProfile,
            skills: activeSkills,
            analysis: baseAnalysis,
            adaptationReason: reason,
          },
          { mode: activeMode, onStatusChange: handleAgentStatus },
        );

        if (res.careerMatches) {
          setCareerMatches(res.careerMatches.matches);
          setCareerAdvice(res.careerMatches.executiveAdvice);
        }
        const finalRoadmap = res.roadmap ?? baseRoadmap;
        await persistRoadmapAndLogs(updatedProfile, baseAnalysis, finalRoadmap, res.logs);
      } catch (err) {
        console.warn('Career switch AI enrichment warning:', err);
      } finally {
        setIsOrchestrating(false);
      }
    },
    [profile, skills, user, executionMode, handleAgentStatus, persistRoadmapAndLogs],
  );

  const submitAssessment = useCallback(
    async (
      assessment: AssessmentSpec,
      selectedAnswers: number[],
      override?: { profile: LearnerProfile; skills: UserSkill[]; mode: WorkspaceExecutionMode },
    ): Promise<AssessmentAttempt> => {
      const activeProfile = override?.profile ?? profile;
      const activeSkills = override?.skills ?? skills;
      const activeMode = override?.mode ?? executionMode;
      if (!activeProfile) {
        throw new Error('Active learner profile is required before submitting assessments.');
      }
      setIsOrchestrating(true);
      setOrchestratorError(null);

      try {
        const topicMap = new Map<string, { total: number; correct: number }>();
        let correctCount = 0;

        assessment.questions.forEach((q, idx) => {
          const isCorrect = selectedAnswers[idx] === q.correctIndex;
          if (isCorrect) correctCount += 1;
          const prev = topicMap.get(q.topic) ?? { total: 0, correct: 0 };
          topicMap.set(q.topic, {
            total: prev.total + 1,
            correct: prev.correct + (isCorrect ? 1 : 0),
          });
        });

        const totalQuestions = assessment.questions.length;
        const score = Math.round((correctCount / totalQuestions) * 100);
        const topicBreakdown: TopicPerformance[] = Array.from(topicMap.entries()).map(
          ([topic, stats]) => ({
            topic,
            total: stats.total,
            correct: stats.correct,
            accuracy: Math.round((stats.correct / stats.total) * 100),
          }),
        );
        const weakTopics = topicBreakdown.filter((t) => t.accuracy < 70).map((t) => t.topic);

        const targetSkill: UserSkill = activeSkills.find((s) => s.skillId === assessment.skillId) ?? {
          userId: activeProfile.userId,
          skillId: assessment.skillId,
          skillName: assessment.skillName,
          category: 'Core Engineering',
          proficiency: 0,
          evidenceCount: 0,
          weakTopics: [],
          mastered: false,
        };

        // Deterministic adaptive calculation (works 100% even if AI fails/throttles)
        const recoveryThreshold = activeProfile.adaptiveConfig?.recoveryThreshold ?? 50;
        const progressionThreshold = activeProfile.adaptiveConfig?.progressionThreshold ?? 85;
        const detAdaptiveMode = determineAdaptiveMode(score, recoveryThreshold, progressionThreshold);
        const nextEvidenceCount = targetSkill.evidenceCount + 1;
        let detProficiency = targetSkill.proficiency;
        if (detAdaptiveMode === 'recovery') {
          detProficiency = targetSkill.proficiency > 1 ? 1 : targetSkill.proficiency;
        } else if (detAdaptiveMode === 'practice') {
          detProficiency = targetSkill.proficiency < 2 ? 2 : targetSkill.proficiency;
        } else if (detAdaptiveMode === 'progression') {
          detProficiency = nextEvidenceCount >= 2 ? 4 : targetSkill.proficiency < 3 ? 3 : targetSkill.proficiency;
        }
        const detMastered =
          detAdaptiveMode === 'progression' && nextEvidenceCount >= 2 && detProficiency >= 3;

        // Call Agent 5: Progress Evaluation Agent (resilient — falls back to deterministic evaluation if needed)
        const evalRes = await executeProgressEvaluationAgent(
          {
            profile: activeProfile,
            skill: targetSkill,
            score,
            topicBreakdown,
            weakTopics,
          },
          { mode: activeMode, onStatusChange: handleAgentStatus },
        );

        const adaptiveMode = evalRes.error ? detAdaptiveMode : evalRes.adaptiveMode;
        const updatedProficiency = evalRes.error
          ? detProficiency
          : normalizeProficiency(evalRes.updatedProficiency);
        const mastered = evalRes.error ? detMastered : evalRes.mastered;
        const focusTopics = evalRes.recommendedFocusTopics?.length
          ? evalRes.recommendedFocusTopics
          : weakTopics;
        const evaluationSummary =
          evalRes.evaluationSummary ||
          `Scored ${score}% (${correctCount}/${totalQuestions}) on ${assessment.title}, activating ${adaptiveMode.toUpperCase()} mode.${
            focusTopics.length > 0 ? ` Focus topics: ${focusTopics.join(', ')}.` : ''
          }`;
        const adaptationReason =
          evalRes.adaptationReason ||
          `Adaptive Engine transitioned ${assessment.skillName} roadmap to ${adaptiveMode.toUpperCase()} mode based on ${score}% assessment performance.`;

        const updatedSkill: UserSkill = {
          ...targetSkill,
          proficiency: updatedProficiency,
          evidenceCount: nextEvidenceCount,
          weakTopics: focusTopics,
          mastered,
        };

        const nextSkills = activeSkills.some((s) => s.skillId === updatedSkill.skillId)
          ? activeSkills.map((s) => (s.skillId === updatedSkill.skillId ? updatedSkill : s))
          : [...activeSkills, updatedSkill];

        const shouldPersistCloud =
          activeMode === 'firebase' && Boolean(user) && activeProfile.userId === user?.uid;

        setSkills(nextSkills);
        setCareerMatches(matchAllCareers(activeProfile.userId, nextSkills));
        if (shouldPersistCloud) {
          await saveUserSkills(activeProfile.userId, nextSkills);
        }

        // Deterministic Gap + Targeted Agent 4 Recommendation ONLY (fast!)
        const nextAnalysis = calculateSkillGaps(activeProfile.userId, activeProfile.careerGoal, nextSkills);
        const recRes = await executeLearningRecommendationOnly(
          {
            profile: activeProfile,
            skills: nextSkills,
            analysis: nextAnalysis,
            adaptiveMode,
            adaptationReason,
            focusSkillId: assessment.skillId,
            weakTopics: focusTopics,
          },
          { mode: activeMode, onStatusChange: handleAgentStatus },
        );

        const finalRoadmap = recRes.roadmap ?? {
          userId: activeProfile.userId,
          careerGoal: activeProfile.careerGoal,
          adaptiveMode,
          adaptationReason,
          summary: `Adaptive ${adaptiveMode} update following ${assessment.skillName} (${score}%).`,
          stages: buildDeterministicRoadmapStages(
            activeProfile,
            nextSkills,
            nextAnalysis,
            adaptiveMode,
            assessment.skillId,
            focusTopics,
          ),
        };

        const attempt: AssessmentAttempt = {
          userId: activeProfile.userId,
          assessmentId: assessment.assessmentId,
          skillId: assessment.skillId,
          skillName: assessment.skillName,
          score,
          totalQuestions,
          correctCount,
          adaptiveMode,
          weakTopics: focusTopics,
          topicBreakdown,
          evaluationSummary,
          timestampIso: new Date().toISOString(),
        };

        setAttempts((prev) => [attempt, ...prev]);
        if (shouldPersistCloud) {
          await appendAssessmentAttempt(attempt);
        }

        const allNewLogs = [recRes.log, ...evalRes.logs];
        await persistRoadmapAndLogs(activeProfile, nextAnalysis, finalRoadmap, allNewLogs, {
          userId: activeProfile.userId,
          eventType: 'assessment',
          skillId: assessment.skillId,
          skillName: assessment.skillName,
          readinessScore: nextAnalysis.readinessScore,
          detail: `Scored ${score}% on ${assessment.title} -> Triggered ${adaptiveMode.toUpperCase()} mode.`,
          timestampIso: new Date().toISOString(),
        });

        return attempt;
      } catch (err) {
        const msg = err instanceof Error ? err.message : 'Assessment evaluation failed.';
        setOrchestratorError(msg);
        throw err;
      } finally {
        setIsOrchestrating(false);
      }
    },
    [
      profile,
      skills,
      user,
      executionMode,
      handleAgentStatus,
      persistRoadmapAndLogs,
    ],
  );

  const runDemoScenario = useCallback(
    async (scenario: 'A' | 'B' | 'C') => {
      let demoOverride: { profile: LearnerProfile; skills: UserSkill[]; mode: WorkspaceExecutionMode } | undefined;
      if (!isDemoMode || profile?.userId !== DEMO_ALEX_SEED.profile.userId) {
        const seeded = await buildDemoBaseline(false);
        demoOverride = { profile: seeded.profile, skills: seeded.skills, mode: 'demo' };
      }
      if (scenario === 'A') {
        const jsQuiz = ASSESSMENT_BANK.find((a) => a.assessmentId === 'assess-js-core')!;
        const answers = jsQuiz.questions.map((q, idx) =>
          idx < 4 ? q.correctIndex : (q.correctIndex + 1) % 4,
        );
        await submitAssessment(jsQuiz, answers, demoOverride);
        setCurrentPage('roadmap');
      } else if (scenario === 'B') {
        const jsQuiz = ASSESSMENT_BANK.find((a) => a.assessmentId === 'assess-js-core')!;
        const answers = jsQuiz.questions.map((q, idx) =>
          idx < 9 ? q.correctIndex : (q.correctIndex + 1) % 4,
        );
        await submitAssessment(jsQuiz, answers, demoOverride);
        setCurrentPage('roadmap');
      } else if (scenario === 'C') {
        await switchCareerGoal('Data Analyst', demoOverride);
        setCurrentPage('careers');
      }
    },
    [isDemoMode, profile, buildDemoBaseline, submitAssessment, switchCareerGoal],
  );

  const updateStageStatus = useCallback(
    async (stageId: string, nextStatus: TaskStatus) => {
      if (!profile || !roadmap) return;
      const updatedStages = roadmap.stages.map((st) =>
        st.stageId === stageId ? { ...st, status: nextStatus } : st,
      );
      const updatedRoadmap: LearningRoadmap = { ...roadmap, stages: updatedStages };
      setRoadmap(updatedRoadmap);
      setTasks(
        updatedStages.map((s) => ({
          userId: profile.userId,
          roadmapId: `${profile.userId}_active_roadmap`,
          skillId: s.skillId,
          title: s.learningObjective,
          stageOrder: s.order,
          status: s.status,
          estimatedHours: s.estimatedHours,
        })),
      );

      const changedStage = updatedStages.find((s) => s.stageId === stageId);
      const prog: ProgressRecord | undefined =
        nextStatus === 'completed' && changedStage
          ? {
              userId: profile.userId,
              eventType: 'task_completed',
              skillId: changedStage.skillId,
              skillName: changedStage.skillName,
              readinessScore: analysis?.readinessScore ?? 0,
              detail: `Completed roadmap stage: ${changedStage.skillName} (${changedStage.priorityTag}).`,
              timestampIso: new Date().toISOString(),
            }
          : undefined;

      if (prog) {
        setProgress((prev) => [prog, ...prev]);
      }

      if (!isDemoMode && !isLocalSession && user && profile.userId === user.uid) {
        try {
          await saveLearningRoadmapAndTasks(updatedRoadmap);
          if (prog) await appendProgressRecord(prog);
        } catch (err) {
          setOrchestratorError(
            err instanceof Error ? err.message : 'Failed to save roadmap stage status.',
          );
        }
      }
    },
    [profile, roadmap, analysis, isDemoMode, isLocalSession, user],
  );

  const toggleResourceFlag = useCallback(
    async (resourceId: string, field: 'bookmarked' | 'completed') => {
      if (!profile) return;
      const current = resources.find((r) => r.resourceId === resourceId);
      if (!current) return;
      const targetUpdated: UserResourceState = { ...current, [field]: !current[field] };
      setResources((prev) =>
        prev.map((r) => (r.resourceId === resourceId ? targetUpdated : r)),
      );
      if (!isDemoMode && !isLocalSession && user && profile.userId === user.uid) {
        try {
          await updateResourceState(profile.userId, targetUpdated);
        } catch (err) {
          setOrchestratorError(
            err instanceof Error ? err.message : 'Failed to save resource state.',
          );
        }
      }
    },
    [profile, resources, isDemoMode, isLocalSession, user],
  );

  const askMentor = useCallback(
    async (question: string) => {
      if (!profile || !analysis) return;
      setIsOrchestrating(true);
      setOrchestratorError(null);

      const userMsg: MentorMessage = {
        userId: profile.userId,
        role: 'user',
        content: question,
        careerGoal: profile.careerGoal,
        timestampIso: new Date().toISOString(),
      };
      setMentorMessages((prev) => [...prev, userMsg]);

      try {
        if (!isDemoMode && !isLocalSession && user && profile.userId === user.uid) {
          await appendMentorMessage(userMsg);
        }

        const res = await executeAIMentorAgent(
          {
            question,
            profile,
            skills,
            analysis,
            roadmap,
            attempts,
            history: mentorMessages,
          },
          { mode: executionMode, onStatusChange: handleAgentStatus },
        );

        const planText =
          res.actionPlan && res.actionPlan.length > 0
            ? `\n\nAction Plan:\n${res.actionPlan
                .map(
                  (item, idx) =>
                    `${idx + 1}. [${item.targetSkill} · ${item.durationMinutes} min] ${item.step}`,
                )
                .join('\n')}`
            : '';
        const metricsText =
          res.referencedMetrics && res.referencedMetrics.length > 0
            ? `\n\nGrounded Telemetry: ${res.referencedMetrics.join(' · ')}`
            : '';

        const mentorReply: MentorMessage = {
          userId: profile.userId,
          role: 'mentor',
          content: `${res.reply}${planText}${metricsText}\n\nRecommended Next Step: ${res.suggestedNextAction}`,
          careerGoal: profile.careerGoal,
          timestampIso: new Date().toISOString(),
        };

        setMentorMessages((prev) => [...prev, mentorReply]);
        setAgentLogs((prev) => [res.log, ...prev]);

        if (!isDemoMode && !isLocalSession && user && profile.userId === user.uid) {
          await Promise.all([
            appendMentorMessage(mentorReply),
            appendAgentLogs([res.log]),
          ]);
        }
      } catch (err) {
        const msg = err instanceof Error ? err.message : 'AI Mentor request failed.';
        setOrchestratorError(msg);
      } finally {
        setIsOrchestrating(false);
      }
    },
    [
      profile,
      analysis,
      skills,
      roadmap,
      attempts,
      mentorMessages,
      isDemoMode,
      isLocalSession,
      user,
      executionMode,
      handleAgentStatus,
    ],
  );

  const clearMentorChat = useCallback(async () => {
    setMentorMessages([]);
    if (!isDemoMode && !isLocalSession && user) {
      try {
        await clearMentorConversation(user.uid);
      } catch (err) {
        setOrchestratorError(
          err instanceof Error ? err.message : 'Failed to clear mentor conversation.',
        );
      }
    }
  }, [isDemoMode, isLocalSession, user]);

  const wipeAuthenticatedAccountData = useCallback(async () => {
    if (isLocalSession) {
      window.localStorage.removeItem(LOCAL_WORKSPACE_KEY);
      setHasSavedLocalWorkspace(false);
      await signOutUser();
      return;
    }
    if (!user) return;
    try {
      await deleteAllUserData(user.uid);
      await loadAuthenticatedWorkspace(user);
    } catch (err) {
      const msg = err instanceof Error ? err.message : 'Failed to reset cloud workspace.';
      setOrchestratorError(msg);
      throw err;
    }
  }, [isLocalSession, user, signOutUser, loadAuthenticatedWorkspace]);

  return (
    <AppContext.Provider
      value={{
        currentPage,
        setCurrentPage,
        user,
        authReady,
        isDemoMode,
        isLocalSession,
        isLoadingWorkspace,
        isOrchestrating,
        orchestratorError,
        authErrorCode,
        clearError,
        agentStatuses,
        profile,
        skills,
        analysis,
        careerMatches,
        profileInsight,
        careerAdvice,
        roadmap,
        tasks,
        resources,
        attempts,
        progress,
        agentLogs,
        mentorMessages,
        signInWithGoogle,
        signInWithGoogleRedirect,
        createLocalLearnerWorkspace,
        resumeLocalLearnerWorkspace,
        hasSavedLocalWorkspace,
        signOutUser,
        enterDemoMode,
        resetDemoScenario,
        saveProfileAndSkills,
        switchCareerGoal,
        refreshSkillGapOnly,
        runOrchestrationNow,
        submitAssessment,
        runDemoScenario,
        updateStageStatus,
        toggleResourceFlag,
        askMentor,
        clearMentorChat,
        wipeAuthenticatedAccountData,
      }}
    >
      {children}
    </AppContext.Provider>
  );
}

export function useApp() {
  const ctx = useContext(AppContext);
  if (!ctx) throw new Error('useApp must be used inside AppProvider');
  return ctx;
}
