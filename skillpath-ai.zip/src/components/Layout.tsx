import React, { useState } from 'react';
import {
  Activity,
  AlertCircle,
  BookOpen,
  Bot,
  Compass,
  FileCheck2,
  GitBranch,
  LayoutDashboard,
  Loader2,
  LogOut,
  Menu,
  Play,
  RotateCcw,
  Settings,
  Sparkles,
  TrendingUp,
  UserCheck,
  X,
} from 'lucide-react';
import { useApp } from '../context/AppContext.tsx';
import type { PageId } from '../shared/types.ts';

interface NavItem {
  id: PageId;
  label: string;
  icon: React.ComponentType<{ className?: string }>;
}

const NAV_ITEMS: NavItem[] = [
  { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
  { id: 'profile', label: 'Learner Profile', icon: UserCheck },
  { id: 'skills', label: 'Skill Analysis', icon: GitBranch },
  { id: 'careers', label: 'Career Matching', icon: Compass },
  { id: 'roadmap', label: 'Learning Roadmap', icon: Sparkles },
  { id: 'resources', label: 'Learning Resources', icon: BookOpen },
  { id: 'assessments', label: 'Assessments', icon: FileCheck2 },
  { id: 'progress', label: 'Progress Tracking', icon: TrendingUp },
  { id: 'mentor', label: 'AI Mentor', icon: Bot },
  { id: 'agents', label: 'Agent Activity Center', icon: Activity },
  { id: 'settings', label: 'Settings', icon: Settings },
];

export function Layout({ children }: { children: React.ReactNode }) {
  const {
    currentPage,
    setCurrentPage,
    profile,
    user,
    isDemoMode,
    isLocalSession,
    isOrchestrating,
    agentStatuses,
    orchestratorError,
    clearError,
    signOutUser,
    resetDemoScenario,
    runDemoScenario,
    runOrchestrationNow,
  } = useApp();

  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const activeNav = NAV_ITEMS.find((n) => n.id === currentPage);
  const runningAgents = Object.entries(agentStatuses)
    .filter(([, status]) => status === 'running')
    .map(([name]) => name);

  const handleNavigate = (id: PageId) => {
    setCurrentPage(id);
    setMobileMenuOpen(false);
  };

  return (
    <div className="min-h-screen bg-transparent text-slate-100 flex">
      {/* Desktop Sidebar */}
      <aside className="hidden lg:flex lg:w-64 lg:flex-col lg:fixed lg:inset-y-0 bg-[#040813]/96 border-r border-sky-500/15">
        <div className="h-16 px-6 flex items-center justify-between border-b border-sky-500/15">
          <button
            type="button"
            onClick={() => handleNavigate('dashboard')}
            className="font-display text-lg font-bold tracking-tight text-white whitespace-nowrap shrink-0 hover:text-sky-300 transition-colors"
          >
            SkillPath AI
          </button>
        </div>

        <nav aria-label="Primary Sidebar" className="flex-1 overflow-y-auto px-3 py-4 space-y-1">
          {NAV_ITEMS.map((item) => {
            const Icon = item.icon;
            const active = currentPage === item.id;
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => handleNavigate(item.id)}
                className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-colors whitespace-nowrap ${
                  active
                    ? 'bg-sky-500/14 text-white border border-sky-400/45 shadow-[inset_0_1px_0_0_rgba(125,211,252,0.12)]'
                    : 'text-slate-400 hover:text-slate-100 hover:bg-slate-800/45 border border-transparent'
                }`}
              >
                <Icon className={`w-4 h-4 shrink-0 ${active ? 'text-sky-400' : 'text-slate-500'}`} />
                <span className="truncate">{item.label}</span>
              </button>
            );
          })}
        </nav>

        <div className="p-4 border-t border-sky-500/15 space-y-3">
          <div className="text-xs text-slate-400 space-y-1">
            <div className="font-medium text-slate-200 truncate">{profile?.name ?? 'Learner'}</div>
            <div className="truncate text-slate-400">
              {isDemoMode
                ? 'Demo Sandbox · Sample Data'
                : isLocalSession
                  ? profile?.email ?? 'Personal Local Workspace'
                  : user?.email ?? 'Authenticated'}
            </div>
          </div>
          <button
            type="button"
            onClick={() => (isDemoMode ? setCurrentPage('auth') : signOutUser())}
            className="w-full flex items-center justify-center gap-2 px-3 py-2 rounded-lg text-xs font-medium sp-btn-secondary whitespace-nowrap"
          >
            <LogOut className="w-3.5 h-3.5" />
            <span>{isDemoMode ? 'Switch to Real Account' : 'Sign Out'}</span>
          </button>
        </div>
      </aside>

      {/* Mobile Drawer */}
      {mobileMenuOpen && (
        <div className="fixed inset-0 z-50 lg:hidden flex">
          <div
            className="fixed inset-0 bg-black/75"
            onClick={() => setMobileMenuOpen(false)}
          />
          <aside className="relative z-10 w-72 max-w-[85vw] bg-[#040813] border-r border-sky-500/20 flex flex-col h-full">
            <div className="h-14 px-5 flex items-center justify-between border-b border-sky-500/15">
              <span className="font-display text-base font-bold text-white">SkillPath AI</span>
              <button
                type="button"
                aria-label="Close navigation"
                onClick={() => setMobileMenuOpen(false)}
                className="p-2 text-slate-400 hover:text-white rounded-lg"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            <nav className="flex-1 overflow-y-auto p-3 space-y-1">
              {NAV_ITEMS.map((item) => {
                const Icon = item.icon;
                const active = currentPage === item.id;
                return (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => handleNavigate(item.id)}
                    className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-colors whitespace-nowrap ${
                      active
                        ? 'bg-sky-500/14 text-white border border-sky-400/45'
                        : 'text-slate-400 hover:text-slate-100 hover:bg-slate-800/50 border border-transparent'
                    }`}
                  >
                    <Icon className={`w-4 h-4 shrink-0 ${active ? 'text-sky-400' : 'text-slate-500'}`} />
                    <span className="truncate">{item.label}</span>
                  </button>
                );
              })}
            </nav>
            <div className="p-4 border-t border-sky-500/15">
              <button
                type="button"
                onClick={() => {
                  setMobileMenuOpen(false);
                  if (isDemoMode) setCurrentPage('auth');
                  else signOutUser();
                }}
                className="w-full flex items-center justify-center gap-2 px-3 py-2.5 rounded-lg text-xs font-medium sp-btn-secondary"
              >
                <LogOut className="w-4 h-4" />
                <span>{isDemoMode ? 'Sign In with Google' : 'Sign Out'}</span>
              </button>
            </div>
          </aside>
        </div>
      )}

      {/* Main Content Area */}
      <div className="flex-1 lg:pl-64 flex flex-col min-w-0">
        {/* Top Header */}
        <header className="sticky top-0 z-30 h-16 bg-[#040813]/96 border-b border-sky-500/15 px-4 sm:px-8 flex items-center justify-between gap-4">
          <div className="flex items-center gap-3 min-w-0">
            <button
              type="button"
              aria-label="Open navigation menu"
              onClick={() => setMobileMenuOpen(true)}
              className="lg:hidden p-2 rounded-lg text-slate-300 hover:text-white hover:bg-slate-800/60"
            >
              <Menu className="w-5 h-5" />
            </button>
            <div className="flex items-center gap-2 text-sm min-w-0">
              <span className="text-slate-500 hidden sm:inline">Workspace</span>
              <span className="text-slate-600 hidden sm:inline">/</span>
              <h1 className="font-display font-semibold text-slate-100 truncate">
                {activeNav?.label ?? 'SkillPath AI'}
              </h1>
            </div>
          </div>

          <div className="flex items-center gap-3 shrink-0">
            <span className="hidden md:inline text-xs text-slate-400 whitespace-nowrap">
              {profile?.careerGoal ?? 'Full Stack Developer'} ·{' '}
              {isDemoMode
                ? 'Sample Demo: Alex'
                : isLocalSession
                  ? 'Personal Local Workspace'
                  : 'Cloud Firestore Synced'}
            </span>
            <button
              type="button"
              disabled={isOrchestrating}
              onClick={() => runOrchestrationNow()}
              className="px-4 py-2 rounded-lg text-xs font-semibold sp-btn-primary disabled:opacity-50 whitespace-nowrap shrink-0 flex items-center gap-2"
            >
              {isOrchestrating ? (
                <Loader2 className="w-3.5 h-3.5 animate-spin" />
              ) : (
                <Play className="w-3.5 h-3.5" />
              )}
              <span>{isOrchestrating ? 'Running Agents...' : 'Run AI Orchestrator'}</span>
            </button>
          </div>
        </header>

        {/* Real-Time Multi-Agent Pipeline Progress Strip (visible strictly during real execution) */}
        {isOrchestrating && runningAgents.length > 0 && (
          <div className="bg-[#071126]/95 border-b border-sky-400/30 px-4 sm:px-8 py-2 flex items-center justify-between gap-3 text-xs">
            <div className="flex items-center gap-2.5 text-sky-200 min-w-0">
              <Loader2 className="w-3.5 h-3.5 text-sky-400 animate-spin shrink-0" />
              <span className="truncate">
                Active Agent Execution: <strong className="text-white">{runningAgents.join(' · ')}</strong>
              </span>
            </div>
            <button
              type="button"
              onClick={() => setCurrentPage('agents')}
              className="text-sky-300 hover:text-white font-medium whitespace-nowrap shrink-0"
            >
              Inspect Logs
            </button>
          </div>
        )}

        {/* Demo Mode Banner */}
        {isDemoMode && (
          <div className="bg-[#060D1E]/95 border-b border-sky-500/20 px-4 sm:px-8 py-2.5 flex flex-wrap items-center justify-between gap-3 text-xs">
            <div className="text-slate-200">
              <span className="font-semibold text-sky-300">Demo Sandbox Active (Sample Learner: Alex Rivera)</span>
              <span className="text-slate-400"> · Separate from authenticated Cloud Firestore accounts</span>
            </div>
            <div className="flex flex-wrap items-center gap-2">
              <button
                type="button"
                disabled={isOrchestrating}
                onClick={() => runDemoScenario('A')}
                className="px-3 py-1.5 rounded-md sp-btn-secondary font-medium whitespace-nowrap disabled:opacity-50"
              >
                Scenario A: 40% JS (Recovery)
              </button>
              <button
                type="button"
                disabled={isOrchestrating}
                onClick={() => runDemoScenario('B')}
                className="px-3 py-1.5 rounded-md sp-btn-secondary font-medium whitespace-nowrap disabled:opacity-50"
              >
                Scenario B: 90% JS (Progression)
              </button>
              <button
                type="button"
                disabled={isOrchestrating}
                onClick={() => runDemoScenario('C')}
                className="px-3 py-1.5 rounded-md sp-btn-secondary font-medium whitespace-nowrap disabled:opacity-50"
              >
                Scenario C: Switch to Data Analyst
              </button>
              <button
                type="button"
                disabled={isOrchestrating}
                onClick={() => resetDemoScenario()}
                className="px-3 py-1.5 rounded-md sp-btn-secondary font-medium whitespace-nowrap flex items-center gap-1 disabled:opacity-50"
              >
                <RotateCcw className="w-3 h-3" />
                <span>Reset Alex</span>
              </button>
            </div>
          </div>
        )}

        {/* Global Error Banner */}
        {orchestratorError && (
          <div
            role="alert"
            className="mx-4 sm:mx-8 mt-4 p-4 rounded-xl bg-rose-950/60 border border-rose-500/40 text-rose-200 text-sm flex items-start justify-between gap-4"
          >
            <div className="flex items-start gap-3">
              <AlertCircle className="w-5 h-5 text-rose-400 shrink-0 mt-0.5" />
              <div>
                <div className="font-semibold text-rose-100">Execution Notice</div>
                <p className="text-rose-200/90 mt-0.5">{orchestratorError}</p>
              </div>
            </div>
            <button
              type="button"
              onClick={clearError}
              className="text-xs font-medium text-rose-300 hover:text-white px-2 py-1"
            >
              Dismiss
            </button>
          </div>
        )}

        <main className="flex-1 px-4 sm:px-8 py-6 max-w-7xl w-full mx-auto">
          {children}
        </main>
      </div>
    </div>
  );
}
