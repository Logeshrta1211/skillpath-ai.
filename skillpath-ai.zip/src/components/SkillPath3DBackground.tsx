import React, { useEffect, useRef } from 'react';
import * as THREE from 'three';
import { RoomEnvironment } from 'three/addons/environments/RoomEnvironment.js';
import type { AdaptiveMode } from '../shared/types.ts';

interface SkillPath3DBackgroundProps {
  adaptiveMode?: AdaptiveMode;
  readinessScore?: number;
  intensity?: 'hero' | 'workspace';
}

const _dummyObj = new THREE.Object3D();
const _targetColor = new THREE.Color();
const _ringTargetColor = new THREE.Color();
const _vecA = new THREE.Vector3();
const _vecB = new THREE.Vector3();
const _vecLerp = new THREE.Vector3();

function createArchitecturalGridTexture(anisotropy: number): THREE.CanvasTexture {
  const size = 512;
  const canvas = document.createElement('canvas');
  canvas.width = size;
  canvas.height = size;
  const ctx = canvas.getContext('2d');

  if (ctx) {
    ctx.fillStyle = '#03060E';
    ctx.fillRect(0, 0, size, size);

    // Subtle sub-grid
    ctx.strokeStyle = 'rgba(56, 189, 248, 0.09)';
    ctx.lineWidth = 1;
    const step = 64;
    for (let i = 0; i <= size; i += step) {
      ctx.beginPath();
      ctx.moveTo(i, 0);
      ctx.lineTo(i, size);
      ctx.stroke();

      ctx.beginPath();
      ctx.moveTo(0, i);
      ctx.lineTo(size, i);
      ctx.stroke();
    }

    // Major architectural coordinate lines
    ctx.strokeStyle = 'rgba(37, 99, 235, 0.28)';
    ctx.lineWidth = 2;
    ctx.strokeRect(0, 0, size, size);

    // Precision crosshair ticks at intersections
    ctx.fillStyle = 'rgba(56, 189, 248, 0.55)';
    for (let x = 0; x <= size; x += 256) {
      for (let y = 0; y <= size; y += 256) {
        ctx.fillRect(x - 3, y - 3, 6, 6);
      }
    }
  }

  const texture = new THREE.CanvasTexture(canvas);
  texture.colorSpace = THREE.SRGBColorSpace;
  texture.wrapS = THREE.RepeatWrapping;
  texture.wrapT = THREE.RepeatWrapping;
  texture.repeat.set(14, 14);
  texture.anisotropy = Math.min(8, Math.max(1, anisotropy));
  return texture;
}

function createAstrolabeDialTexture(anisotropy: number): THREE.CanvasTexture {
  const size = 512;
  const canvas = document.createElement('canvas');
  canvas.width = size;
  canvas.height = size;
  const ctx = canvas.getContext('2d');

  if (ctx) {
    ctx.clearRect(0, 0, size, size);
    const cx = size / 2;
    const cy = size / 2;

    ctx.strokeStyle = 'rgba(56, 189, 248, 0.35)';
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    ctx.arc(cx, cy, 224, 0, Math.PI * 2);
    ctx.stroke();

    ctx.strokeStyle = 'rgba(148, 163, 184, 0.22)';
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.arc(cx, cy, 200, 0, Math.PI * 2);
    ctx.stroke();

    for (let deg = 0; deg < 360; deg += 5) {
      const rad = (deg * Math.PI) / 180;
      const isMajor = deg % 30 === 0;
      const innerR = isMajor ? 198 : 210;
      const outerR = 224;
      ctx.strokeStyle = isMajor ? 'rgba(56, 189, 248, 0.65)' : 'rgba(148, 163, 184, 0.28)';
      ctx.lineWidth = isMajor ? 2 : 1;
      ctx.beginPath();
      ctx.moveTo(cx + Math.cos(rad) * innerR, cy + Math.sin(rad) * innerR);
      ctx.lineTo(cx + Math.cos(rad) * outerR, cy + Math.sin(rad) * outerR);
      ctx.stroke();
    }
  }

  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.anisotropy = Math.min(8, Math.max(1, anisotropy));
  return tex;
}

export function SkillPath3DBackground({
  adaptiveMode = 'baseline',
  readinessScore = 25,
  intensity = 'workspace',
}: SkillPath3DBackgroundProps) {
  const mountRef = useRef<HTMLDivElement | null>(null);
  const stateRef = useRef({
    adaptiveMode,
    readinessScore,
    intensity,
    pointerX: 0,
    pointerY: 0,
  });

  useEffect(() => {
    stateRef.current.adaptiveMode = adaptiveMode;
    stateRef.current.readinessScore = readinessScore;
    stateRef.current.intensity = intensity;
  }, [adaptiveMode, readinessScore, intensity]);

  useEffect(() => {
    const container = mountRef.current;
    if (!container) return;

    const prefersReducedMotion =
      typeof window !== 'undefined' &&
      window.matchMedia('(prefers-reduced-motion: reduce)').matches;

    const isSoftwareGl = (() => {
      try {
        const gl = document.createElement('canvas').getContext('webgl2');
        if (!gl) return true;
        const ext = gl.getExtension('WEBGL_debug_renderer_info');
        const param = ext ? ext.UNMASKED_RENDERER_WEBGL : gl.RENDERER;
        const gpu = String(gl.getParameter(param));
        gl.getExtension('WEBGL_lose_context')?.loseContext();
        return /SwiftShader|llvmpipe|softpipe|Software|Basic Render/i.test(gpu);
      } catch {
        return true;
      }
    })();

    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0x03060e);
    scene.fog = new THREE.FogExp2(0x03060e, 0.02);

    const width = container.clientWidth || window.innerWidth;
    const height = container.clientHeight || window.innerHeight;

    const camera = new THREE.PerspectiveCamera(45, width / height, 0.1, 150);
    camera.position.set(0, 1.4, 18.5);

    const renderer = new THREE.WebGLRenderer({
      antialias: !isSoftwareGl,
      powerPreference: 'high-performance',
      alpha: false,
    });
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.2;
    renderer.setPixelRatio(isSoftwareGl ? 1 : Math.min(window.devicePixelRatio, 2));
    renderer.setSize(width, height);
    renderer.domElement.style.display = 'block';
    renderer.domElement.style.width = '100%';
    renderer.domElement.style.height = '100%';
    container.appendChild(renderer.domElement);

    const pmremGenerator = new THREE.PMREMGenerator(renderer);
    const envTexture = pmremGenerator.fromScene(new RoomEnvironment(), 0.04).texture;
    scene.environment = envTexture;
    pmremGenerator.dispose();

    // Warm/cool studio lighting rig aligned with Astral Obsidian + Luminous Sapphire
    const hemiLight = new THREE.HemisphereLight(0xbae6fd, 0x03060e, 1.15);
    scene.add(hemiLight);

    const keyLight = new THREE.DirectionalLight(0xf0f9ff, 2.4);
    keyLight.position.set(9, 14, 11);
    scene.add(keyLight);

    const rimLight = new THREE.PointLight(0x38bdf8, 24, 52, 1.4);
    rimLight.position.set(-10, -2, 9);
    scene.add(rimLight);

    const accentLight = new THREE.PointLight(0x2563eb, 22, 52, 1.4);
    accentLight.position.set(10, 6, -6);
    scene.add(accentLight);

    const geometries: THREE.BufferGeometry[] = [];
    const materials: THREE.Material[] = [];
    const textures: THREE.Texture[] = [];

    const maxAnisotropy = renderer.capabilities.getMaxAnisotropy();

    // 1. Procedural High-Anisotropy Architectural Horizon Grid
    const gridTexture = createArchitecturalGridTexture(maxAnisotropy);
    textures.push(gridTexture);

    const gridGeo = new THREE.PlaneGeometry(92, 92, isSoftwareGl ? 12 : 42, isSoftwareGl ? 12 : 42);
    gridGeo.rotateX(-Math.PI / 2);
    geometries.push(gridGeo);

    const gridUniforms = { uTime: { value: 0 } };
    const gridMat = new THREE.MeshStandardMaterial({
      map: gridTexture,
      roughness: 0.7,
      metalness: 0.35,
      transparent: true,
      opacity: 0.45,
    });

    if (!isSoftwareGl) {
      gridMat.onBeforeCompile = (shader) => {
        shader.uniforms.uTime = gridUniforms.uTime;
        shader.vertexShader = shader.vertexShader
          .replace(
            '#include <common>',
            `#include <common>
             uniform float uTime;`,
          )
          .replace(
            '#include <begin_vertex>',
            `#include <begin_vertex>
             transformed.y += sin(transformed.x * 0.16 + uTime * 0.45) * 0.24 + cos(transformed.z * 0.16 + uTime * 0.35) * 0.24;`,
          );
      };
    }

    materials.push(gridMat);
    const gridMesh = new THREE.Mesh(gridGeo, gridMat);
    gridMesh.position.set(0, -6.2, -10);
    scene.add(gridMesh);

    // 2. Composite Career Astrolabe Gyroscope Core (11 procedural parts)
    const coreGroup = new THREE.Group();
    coreGroup.position.set(intensity === 'hero' ? 3.9 : 5.0, 0.35, -2.2);
    scene.add(coreGroup);

    const kernelGeo = new THREE.OctahedronGeometry(1.5, 0);
    geometries.push(kernelGeo);
    const kernelMat = new THREE.MeshPhysicalMaterial({
      color: 0x38bdf8,
      emissive: 0x0c4a6e,
      emissiveIntensity: 0.85,
      metalness: 0.45,
      roughness: 0.12,
      clearcoat: 1.0,
      clearcoatRoughness: 0.08,
    });
    materials.push(kernelMat);
    const kernelMesh = new THREE.Mesh(kernelGeo, kernelMat);
    coreGroup.add(kernelMesh);

    const latticeGeo = new THREE.IcosahedronGeometry(2.25, 1);
    geometries.push(latticeGeo);
    const latticeMat = new THREE.MeshBasicMaterial({
      color: 0x38bdf8,
      wireframe: true,
      transparent: true,
      opacity: 0.22,
    });
    materials.push(latticeMat);
    const latticeMesh = new THREE.Mesh(latticeGeo, latticeMat);
    coreGroup.add(latticeMesh);

    // Equatorial degree-graduated astrolabe dial plane
    const dialTexture = createAstrolabeDialTexture(maxAnisotropy);
    textures.push(dialTexture);
    const dialGeo = new THREE.PlaneGeometry(7.6, 7.6);
    geometries.push(dialGeo);
    const dialMat = new THREE.MeshBasicMaterial({
      map: dialTexture,
      transparent: true,
      opacity: 0.55,
      side: THREE.DoubleSide,
      depthWrite: false,
    });
    materials.push(dialMat);
    const dialMesh = new THREE.Mesh(dialGeo, dialMat);
    dialMesh.rotation.x = Math.PI / 2.35;
    coreGroup.add(dialMesh);

    // Brushed titanium equatorial telemetry collar
    const collarGeo = new THREE.TorusGeometry(2.7, 0.024, 14, 100);
    geometries.push(collarGeo);
    const collarMat = new THREE.MeshPhysicalMaterial({
      color: 0xcbd5e1,
      metalness: 0.94,
      roughness: 0.18,
      anisotropy: 0.8,
    });
    materials.push(collarMat);
    const collarMesh = new THREE.Mesh(collarGeo, collarMat);
    collarMesh.rotation.x = Math.PI / 2;
    coreGroup.add(collarMesh);

    const ringConfigs = [
      { radius: 3.22, tube: 0.044, color: 0x38bdf8, metalness: 0.92, roughness: 0.14, tiltX: 0.78, tiltZ: 0.22 },
      { radius: 3.98, tube: 0.036, color: 0x2563eb, metalness: 0.88, roughness: 0.24, tiltX: -0.58, tiltZ: 0.68 },
      { radius: 4.72, tube: 0.028, color: 0xf59e0b, metalness: 0.84, roughness: 0.28, tiltX: 0.28, tiltZ: -0.84 },
    ];

    const orbitalRings: THREE.Mesh[] = [];
    const primaryRingMat: THREE.MeshPhysicalMaterial[] = [];
    for (const rc of ringConfigs) {
      const rGeo = new THREE.TorusGeometry(rc.radius, rc.tube, 16, 100);
      geometries.push(rGeo);
      const rMat = new THREE.MeshPhysicalMaterial({
        color: rc.color,
        emissive: rc.color,
        emissiveIntensity: 0.26,
        metalness: rc.metalness,
        roughness: rc.roughness,
        anisotropy: 0.75,
      });
      materials.push(rMat);
      primaryRingMat.push(rMat);
      const rMesh = new THREE.Mesh(rGeo, rMat);
      rMesh.rotation.set(rc.tiltX, 0, rc.tiltZ);
      coreGroup.add(rMesh);
      orbitalRings.push(rMesh);
    }

    const spireGeo = new THREE.ConeGeometry(0.16, 0.96, 6);
    geometries.push(spireGeo);
    const spireMat = new THREE.MeshStandardMaterial({
      color: 0x7dd3fc,
      metalness: 0.94,
      roughness: 0.16,
    });
    materials.push(spireMat);
    const topSpire = new THREE.Mesh(spireGeo, spireMat);
    topSpire.position.y = 2.6;
    coreGroup.add(topSpire);
    const bottomSpire = new THREE.Mesh(spireGeo, spireMat);
    bottomSpire.position.y = -2.6;
    bottomSpire.rotation.x = Math.PI;
    coreGroup.add(bottomSpire);

    // 3. 16 Skill Beacons + Dynamic Constellation Edges + Traveling Agent Signal Pulses
    const nodeCount = 16;
    const nodeGeo = new THREE.OctahedronGeometry(0.21, 0);
    const haloGeo = new THREE.TorusGeometry(0.36, 0.016, 8, 32);
    geometries.push(nodeGeo, haloGeo);

    const nodeMatSky = new THREE.MeshStandardMaterial({
      color: 0x38bdf8,
      emissive: 0x0284c7,
      emissiveIntensity: 0.65,
      metalness: 0.78,
      roughness: 0.18,
    });
    const nodeMatCobalt = new THREE.MeshStandardMaterial({
      color: 0x60a5fa,
      emissive: 0x1d4ed8,
      emissiveIntensity: 0.58,
      metalness: 0.78,
      roughness: 0.22,
    });
    const nodeMatGold = new THREE.MeshStandardMaterial({
      color: 0xfbbf24,
      emissive: 0xd97706,
      emissiveIntensity: 0.45,
      metalness: 0.84,
      roughness: 0.22,
    });
    const haloMat = new THREE.MeshBasicMaterial({
      color: 0x7dd3fc,
      transparent: true,
      opacity: 0.44,
    });
    materials.push(nodeMatSky, nodeMatCobalt, nodeMatGold, haloMat);

    const skillNodes: Array<{
      group: THREE.Group;
      basePos: THREE.Vector3;
      phase: number;
    }> = [];

    for (let i = 0; i < nodeCount; i++) {
      const phi = Math.acos(1 - (2 * (i + 0.5)) / nodeCount);
      const theta = Math.PI * (1 + Math.sqrt(5)) * i;
      const radius = 5.45 + (i % 3) * 1.15;
      const basePos = new THREE.Vector3(
        radius * Math.sin(phi) * Math.cos(theta),
        radius * Math.cos(phi) * 0.74,
        radius * Math.sin(phi) * Math.sin(theta),
      );

      const nGroup = new THREE.Group();
      nGroup.position.copy(basePos);
      const mat = i % 5 === 0 ? nodeMatGold : i % 2 === 0 ? nodeMatSky : nodeMatCobalt;
      const body = new THREE.Mesh(nodeGeo, mat);
      const halo = new THREE.Mesh(haloGeo, haloMat);
      halo.rotation.x = Math.PI / 2.4;
      nGroup.add(body, halo);
      coreGroup.add(nGroup);

      skillNodes.push({
        group: nGroup,
        basePos,
        phase: i * 0.52,
      });
    }

    const linePositions = new Float32Array(nodeCount * 2 * 3 * 2);
    const lineGeo = new THREE.BufferGeometry();
    lineGeo.setAttribute('position', new THREE.BufferAttribute(linePositions, 3));
    geometries.push(lineGeo);
    const lineMat = new THREE.LineBasicMaterial({
      color: 0x38bdf8,
      transparent: true,
      opacity: 0.26,
    });
    materials.push(lineMat);
    const constellationLines = new THREE.LineSegments(lineGeo, lineMat);
    coreGroup.add(constellationLines);

    // Traveling agent pulses along constellation links
    const pulseCount = nodeCount;
    const pulseGeo = new THREE.SphereGeometry(0.075, 10, 10);
    geometries.push(pulseGeo);
    const pulseMat = new THREE.MeshBasicMaterial({
      color: 0x7dd3fc,
      transparent: true,
      opacity: 0.92,
    });
    materials.push(pulseMat);
    const pulseMesh = new THREE.InstancedMesh(pulseGeo, pulseMat, pulseCount);
    pulseMesh.frustumCulled = false;
    coreGroup.add(pulseMesh);

    // 4. Instanced Ambient Telemetry Motes (240 particles)
    const moteCount = 240;
    const moteGeo = new THREE.OctahedronGeometry(0.048, 0);
    geometries.push(moteGeo);
    const moteMat = new THREE.MeshBasicMaterial({
      color: 0xffffff,
      transparent: true,
      opacity: 0.62,
    });
    materials.push(moteMat);
    const moteMesh = new THREE.InstancedMesh(moteGeo, moteMat, moteCount);
    moteMesh.frustumCulled = false;

    const moteData: Array<{
      radius: number;
      angle: number;
      speed: number;
      y: number;
      scale: number;
    }> = [];

    const palette = [
      new THREE.Color(0x38bdf8),
      new THREE.Color(0x2563eb),
      new THREE.Color(0x10b981),
      new THREE.Color(0xf59e0b),
    ];

    for (let i = 0; i < moteCount; i++) {
      const radius = 3.8 + Math.random() * 15.5;
      const angle = Math.random() * Math.PI * 2;
      const speed = (0.03 + Math.random() * 0.075) * (i % 2 === 0 ? 1 : -1);
      const y = (Math.random() - 0.45) * 12.5;
      const scale = 0.6 + Math.random() * 0.85;
      moteData.push({ radius, angle, speed, y, scale });

      _dummyObj.position.set(Math.cos(angle) * radius, y, Math.sin(angle) * radius - 3);
      _dummyObj.scale.setScalar(scale);
      _dummyObj.updateMatrix();
      moteMesh.setMatrixAt(i, _dummyObj.matrix);
      moteMesh.setColorAt(i, palette[i % palette.length]);
    }
    moteMesh.instanceMatrix.needsUpdate = true;
    if (moteMesh.instanceColor) moteMesh.instanceColor.needsUpdate = true;
    moteMesh.computeBoundingSphere();
    scene.add(moteMesh);

    if (!isSoftwareGl) {
      renderer.compile(scene, camera);
    }

    const onPointerMove = (e: PointerEvent) => {
      stateRef.current.pointerX = (e.clientX / window.innerWidth) * 2 - 1;
      stateRef.current.pointerY = -(e.clientY / window.innerHeight) * 2 + 1;
    };
    window.addEventListener('pointermove', onPointerMove, { passive: true });

    const onResize = () => {
      if (!container) return;
      const w = container.clientWidth || window.innerWidth;
      const h = container.clientHeight || window.innerHeight;
      camera.aspect = w / h;
      camera.updateProjectionMatrix();
      renderer.setSize(w, h);
    };
    window.addEventListener('resize', onResize);

    const clock = new THREE.Clock();
    let frameId = 0;
    let disposed = false;
    let contextLost = false;

    const onContextLost = (e: Event) => {
      e.preventDefault();
      contextLost = true;
      cancelAnimationFrame(frameId);
      clearTimeout(frameId);
    };

    const onContextRestored = () => {
      contextLost = false;
      tick();
    };

    renderer.domElement.addEventListener('webglcontextlost', onContextLost, false);
    renderer.domElement.addEventListener('webglcontextrestored', onContextRestored, false);

    function afterDraw(cb: () => void) {
      const gl = renderer.getContext() as WebGL2RenderingContext;
      if (!gl || typeof gl.fenceSync !== 'function') {
        frameId = window.setTimeout(cb, 80);
        return;
      }
      const sync = gl.fenceSync(gl.SYNC_GPU_COMMANDS_COMPLETE, 0);
      gl.flush();
      const poll = () => {
        if (disposed || contextLost) return;
        const state = sync && gl.getSyncParameter(sync, gl.SYNC_STATUS);
        if (state === gl.UNSIGNALED) {
          frameId = window.setTimeout(poll, 5);
        } else {
          if (sync) gl.deleteSync(sync);
          frameId = window.setTimeout(cb, 80);
        }
      };
      frameId = window.setTimeout(poll, 5);
    }

    function tick() {
      if (disposed || contextLost) return;
      const delta = Math.min(clock.getDelta(), 0.1);
      const elapsed = clock.getElapsedTime();
      const {
        adaptiveMode: mode,
        readinessScore: score,
        pointerX,
        pointerY,
        intensity: viewMode,
      } = stateRef.current;

      gridUniforms.uTime.value = elapsed;

      if (mode === 'recovery') {
        _targetColor.setHex(0xf43f5e);
        _ringTargetColor.setHex(0xfb7185);
      } else if (mode === 'practice') {
        _targetColor.setHex(0xf59e0b);
        _ringTargetColor.setHex(0xfbbf24);
      } else if (mode === 'progression') {
        _targetColor.setHex(0x10b981);
        _ringTargetColor.setHex(0x34d399);
      } else if (mode === 'career_switch') {
        _targetColor.setHex(0x6366f1);
        _ringTargetColor.setHex(0x818cf8);
      } else {
        _targetColor.setHex(0x38bdf8);
        _ringTargetColor.setHex(0x38bdf8);
      }

      const colorDamp = 1 - Math.exp(-3 * delta);
      kernelMat.color.lerp(_targetColor, colorDamp);
      primaryRingMat[0].color.lerp(_ringTargetColor, colorDamp);
      primaryRingMat[0].emissive.lerp(_ringTargetColor, colorDamp);
      rimLight.color.lerp(_targetColor, colorDamp);

      const targetScale = 0.92 + Math.min(100, Math.max(0, score)) * 0.0017;
      coreGroup.scale.setScalar(THREE.MathUtils.damp(coreGroup.scale.x, targetScale, 2.5, delta));

      const targetCoreX = viewMode === 'hero' ? 3.9 : 5.1;
      coreGroup.position.x = THREE.MathUtils.damp(coreGroup.position.x, targetCoreX, 3, delta);

      camera.position.x = THREE.MathUtils.damp(camera.position.x, pointerX * 1.15, 2.5, delta);
      camera.position.y = THREE.MathUtils.damp(camera.position.y, 1.35 + pointerY * 0.68, 2.5, delta);
      camera.lookAt(1.3, -0.2, -2.2);

      if (!prefersReducedMotion) {
        coreGroup.rotation.y += delta * 0.11;
        kernelMesh.rotation.y -= delta * 0.24;
        kernelMesh.rotation.x += delta * 0.13;
        latticeMesh.rotation.y += delta * 0.075;
        dialMesh.rotation.z += delta * 0.05;
        collarMesh.rotation.z -= delta * 0.18;

        orbitalRings[0].rotation.z += delta * 0.22;
        orbitalRings[1].rotation.y -= delta * 0.16;
        orbitalRings[2].rotation.x += delta * 0.14;

        const posAttr = lineGeo.getAttribute('position') as THREE.BufferAttribute;
        let ptr = 0;
        for (let i = 0; i < nodeCount; i++) {
          const n = skillNodes[i];
          const bob = Math.sin(elapsed * 0.85 + n.phase) * 0.22;
          n.group.position.set(n.basePos.x, n.basePos.y + bob, n.basePos.z);
          n.group.rotation.y += delta * 0.55;
        }

        for (let i = 0; i < nodeCount; i++) {
          const a = skillNodes[i].group.position;
          const b = skillNodes[(i + 1) % nodeCount].group.position;
          const c = skillNodes[(i + 5) % nodeCount].group.position;
          posAttr.setXYZ(ptr++, a.x, a.y, a.z);
          posAttr.setXYZ(ptr++, b.x, b.y, b.z);
          posAttr.setXYZ(ptr++, a.x, a.y, a.z);
          posAttr.setXYZ(ptr++, c.x, c.y, c.z);

          const t = (elapsed * 0.4 + i * 0.15) % 1;
          _vecA.copy(a);
          _vecB.copy(c);
          _vecLerp.lerpVectors(_vecA, _vecB, t);
          _dummyObj.position.copy(_vecLerp);
          _dummyObj.rotation.set(0, 0, 0);
          _dummyObj.scale.setScalar(0.8 + Math.sin(t * Math.PI) * 0.48);
          _dummyObj.updateMatrix();
          pulseMesh.setMatrixAt(i, _dummyObj.matrix);
        }
        posAttr.needsUpdate = true;
        pulseMesh.instanceMatrix.needsUpdate = true;

        for (let i = 0; i < moteCount; i++) {
          const m = moteData[i];
          m.angle += delta * m.speed;
          _dummyObj.position.set(
            Math.cos(m.angle) * m.radius,
            m.y + Math.sin(elapsed * 0.45 + i) * 0.22,
            Math.sin(m.angle) * m.radius - 3,
          );
          _dummyObj.rotation.set(elapsed * 0.35 + i, elapsed * 0.25, 0);
          _dummyObj.scale.setScalar(m.scale);
          _dummyObj.updateMatrix();
          moteMesh.setMatrixAt(i, _dummyObj.matrix);
        }
        moteMesh.instanceMatrix.needsUpdate = true;
      }

      renderer.render(scene, camera);

      if (prefersReducedMotion) return;
      if (isSoftwareGl) {
        afterDraw(tick);
      } else {
        frameId = requestAnimationFrame(tick);
      }
    }

    tick();

    return () => {
      disposed = true;
      cancelAnimationFrame(frameId);
      clearTimeout(frameId);
      window.removeEventListener('pointermove', onPointerMove);
      window.removeEventListener('resize', onResize);
      renderer.domElement.removeEventListener('webglcontextlost', onContextLost);
      renderer.domElement.removeEventListener('webglcontextrestored', onContextRestored);

      for (const t of textures) t.dispose();
      for (const g of geometries) g.dispose();
      for (const m of materials) m.dispose();
      envTexture.dispose();
      renderer.dispose();
      if (renderer.domElement.parentNode === container) {
        container.removeChild(renderer.domElement);
      }
    };
  }, []);

  return (
    <div
      ref={mountRef}
      className="fixed inset-0 z-0 pointer-events-none overflow-hidden"
      aria-hidden="true"
    />
  );
}
