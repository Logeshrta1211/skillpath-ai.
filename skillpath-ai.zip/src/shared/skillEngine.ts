import { ASSESSMENT_BANK, CAREER_CATALOG, SKILLS_CATALOG, VERIFIED_RESOURCES } from './catalog.ts';
import type {
  AdaptiveMode,
  CareerGoal,
  CareerMatchResult,
  CareerProfile,
  LearnerProfile,
  ProficiencyLevel,
  RoadmapStage,
  SkillGapAnalysis,
  SkillGapItem,
  UserSkill,
} from './types.ts';
import { PROFICIENCY_LABELS } from './types.ts';

export function getCareerProfile(goal: CareerGoal): CareerProfile {
  return CAREER_CATALOG.find((c) => c.title === goal) ?? CAREER_CATALOG[0];
}

export function getSkillProficiencyMap(skills: UserSkill[]): Record<string, UserSkill> {
  const map: Record<string, UserSkill> = {};
  for (const s of skills) {
    map[s.skillId] = s;
  }
  return map;
}

/**
 * Deterministic Readiness Formula:
 * Readiness = SUM(weight * MIN(currentProficiency / requiredProficiency, 1)) / SUM(weight) * 100
 */
export function calculateSkillGaps(
  userId: string,
  careerGoal: CareerGoal,
  skills: UserSkill[],
  aiExplanations?: Array<{ skillId: string; reason: string }>,
): SkillGapAnalysis {
  const career = getCareerProfile(careerGoal);
  const skillMap = getSkillProficiencyMap(skills);
  const aiMap = new Map((aiExplanations ?? []).map((e) => [e.skillId, e.reason]));

  let weightedScoreSum = 0;
  let totalWeight = 0;

  const strongSkills: SkillGapItem[] = [];
  const weakSkills: SkillGapItem[] = [];
  const missingSkills: SkillGapItem[] = [];
  const allItems: SkillGapItem[] = [];

  for (const req of career.requirements) {
    const userSkill = skillMap[req.skillId];
    const currentProficiency: ProficiencyLevel = userSkill ? userSkill.proficiency : 0;
    const ratio = req.requiredProficiency > 0
      ? Math.min(currentProficiency / req.requiredProficiency, 1)
      : 1;

    weightedScoreSum += req.weight * ratio;
    totalWeight += req.weight;

    const gap = Math.max(0, req.requiredProficiency - currentProficiency);
    const unmetPrerequisites = req.prerequisites.filter((prereqId) => {
      const prereqSkill = skillMap[prereqId];
      return !prereqSkill || prereqSkill.proficiency < 2;
    });
    const prerequisitesMet = unmetPrerequisites.length === 0;

    let status: 'strong' | 'weak' | 'missing' = 'strong';
    if (currentProficiency === 0) {
      status = 'missing';
    } else if (currentProficiency < req.requiredProficiency) {
      status = 'weak';
    }

    const prereqNames = unmetPrerequisites.map(
      (id) => SKILLS_CATALOG.find((s) => s.skillId === id)?.skillName ?? id,
    );

    const defaultExplanation =
      status === 'strong'
        ? `${req.skillName} meets the ${PROFICIENCY_LABELS[req.requiredProficiency]} benchmark for ${careerGoal}.`
        : status === 'missing'
          ? `${req.skillName} is currently absent (0/${req.requiredProficiency}) and carries a ${req.weight.toFixed(1)}x career weight${
              prereqNames.length > 0 ? `; build ${prereqNames.join(', ')} first.` : '.'
            }`
          : `${req.skillName} is at ${PROFICIENCY_LABELS[currentProficiency]} (${currentProficiency}/${req.requiredProficiency}), leaving a ${gap}-level gap for ${careerGoal}.`;

    const priorityScore = Number(
      (gap * req.weight * (prerequisitesMet ? 1.25 : 0.85)).toFixed(2),
    );

    const item: SkillGapItem = {
      skillId: req.skillId,
      skillName: req.skillName,
      category: req.category,
      currentProficiency,
      requiredProficiency: req.requiredProficiency,
      weight: req.weight,
      gap,
      priorityScore,
      prerequisites: req.prerequisites,
      prerequisitesMet,
      unmetPrerequisites,
      status,
      explanation: aiMap.get(req.skillId) ?? defaultExplanation,
    };

    allItems.push(item);
    if (status === 'strong') strongSkills.push(item);
    else if (status === 'weak') weakSkills.push(item);
    else missingSkills.push(item);
  }

  const readinessScore = totalWeight > 0
    ? Math.round((weightedScoreSum / totalWeight) * 1000) / 10
    : 0;

  const prioritySkills = [...weakSkills, ...missingSkills].sort((a, b) => {
    if (a.prerequisitesMet !== b.prerequisitesMet) {
      return a.prerequisitesMet ? -1 : 1;
    }
    return b.priorityScore - a.priorityScore;
  });

  const explanations = allItems.map((item) => ({
    skillId: item.skillId,
    skillName: item.skillName,
    reason: item.explanation,
  }));

  return {
    userId,
    careerGoal,
    readinessScore,
    strongSkills,
    weakSkills,
    missingSkills,
    prioritySkills,
    explanations,
  };
}

export function matchAllCareers(
  userId: string,
  skills: UserSkill[],
): CareerMatchResult[] {
  return CAREER_CATALOG.map((career) => {
    const analysis = calculateSkillGaps(userId, career.title, skills);
    return {
      careerId: career.careerId,
      careerGoal: career.title,
      description: career.description,
      readinessScore: analysis.readinessScore,
      strongCount: analysis.strongSkills.length,
      weakCount: analysis.weakSkills.length,
      missingCount: analysis.missingSkills.length,
      topMissingSkills: analysis.prioritySkills.slice(0, 3).map((s) => s.skillName),
    };
  }).sort((a, b) => b.readinessScore - a.readinessScore);
}

export function determineAdaptiveMode(
  score: number,
  recoveryThreshold = 50,
  progressionThreshold = 85,
): 'recovery' | 'practice' | 'progression' {
  if (score < recoveryThreshold) return 'recovery';
  if (score >= progressionThreshold) return 'progression';
  return 'practice';
}

export function buildDeterministicRoadmapStages(
  profile: LearnerProfile,
  skills: UserSkill[],
  analysis: SkillGapAnalysis,
  adaptiveMode: AdaptiveMode,
  focusSkillId?: string,
  weakTopics: string[] = [],
): RoadmapStage[] {
  const skillMap = getSkillProficiencyMap(skills);
  const weeklyHours = Math.max(1, profile.learningPreferences.weeklyHours || 10);

  // Order priority skills topologically by prerequisites first, then priorityScore
  const remaining = [...analysis.prioritySkills];
  const ordered: SkillGapItem[] = [];
  const covered = new Set(analysis.strongSkills.map((s) => s.skillId));

  let safety = 0;
  while (remaining.length > 0 && safety < 30) {
    safety += 1;
    // If recovery or progression targets a specific skill, prioritize it once prerequisites are met
    let pickIndex = remaining.findIndex((item) => {
      const prereqsSatisfied = item.prerequisites.every(
        (p) => covered.has(p) || (skillMap[p]?.proficiency ?? 0) >= 2,
      );
      return item.skillId === focusSkillId && prereqsSatisfied;
    });

    if (pickIndex === -1) {
      pickIndex = remaining.findIndex((item) =>
        item.prerequisites.every((p) => covered.has(p) || (skillMap[p]?.proficiency ?? 0) >= 2),
      );
    }

    if (pickIndex === -1) {
      pickIndex = 0;
    }

    const [picked] = remaining.splice(pickIndex, 1);
    ordered.push(picked);
    covered.add(picked.skillId);
  }

  // In progression mode on a skill that already met basic threshold, still ensure an advanced stage exists
  if (adaptiveMode === 'progression' && focusSkillId && !ordered.some((o) => o.skillId === focusSkillId)) {
    const targetReq = getCareerProfile(profile.careerGoal).requirements.find((r) => r.skillId === focusSkillId);
    if (targetReq) {
      ordered.unshift({
        skillId: targetReq.skillId,
        skillName: targetReq.skillName,
        category: targetReq.category,
        currentProficiency: skillMap[targetReq.skillId]?.proficiency ?? 3,
        requiredProficiency: targetReq.requiredProficiency,
        weight: targetReq.weight,
        gap: 0,
        priorityScore: 10,
        prerequisites: targetReq.prerequisites,
        prerequisitesMet: true,
        unmetPrerequisites: [],
        status: 'strong',
        explanation: `Advancing ${targetReq.skillName} into production-grade architecture and edge cases.`,
      });
    }
  }

  return ordered.map((item, idx) => {
    const resources = VERIFIED_RESOURCES.filter((r) => r.skillId === item.skillId);
    const matchingAssessment =
      (adaptiveMode === 'progression' && item.skillId === focusSkillId
        ? ASSESSMENT_BANK.find((a) => a.skillId === item.skillId && a.difficulty === 'Advanced') ??
          ASSESSMENT_BANK.find((a) => a.skillId === item.skillId)
        : ASSESSMENT_BANK.find((a) => a.skillId === item.skillId)) ?? ASSESSMENT_BANK[0];

    const isFocusedRecovery = adaptiveMode === 'recovery' && item.skillId === focusSkillId;
    const isFocusedPractice = adaptiveMode === 'practice' && item.skillId === focusSkillId;
    const isFocusedProgression = adaptiveMode === 'progression' && item.skillId === focusSkillId;

    const baseHours = Math.max(4, item.gap * 6 + (isFocusedRecovery ? 4 : 0));
    const weeks = Math.max(1, Math.ceil(baseHours / weeklyHours));

    let priorityTag: RoadmapStage['priorityTag'] = item.status === 'missing' ? 'Critical Gap' : 'Foundation';
    let learningObjective = `Elevate ${item.skillName} from ${PROFICIENCY_LABELS[item.currentProficiency]} to ${PROFICIENCY_LABELS[item.requiredProficiency]} for ${profile.careerGoal}.`;
    let activities = [
      `Study core ${item.skillName} specifications and patterns (${resources[0]?.platform ?? 'Official Docs'}).`,
      `Complete guided coding drills covering ${item.skillName} fundamentals.`,
      `Take the ${matchingAssessment.title} checkpoint quiz.`,
    ];
    let practicalExercise = `Build a focused ${item.skillName} mini-module integrated into a ${profile.careerGoal} workflow.`;

    if (isFocusedRecovery) {
      priorityTag = 'Recovery Revision';
      const topicLabel = weakTopics.length > 0 ? weakTopics.join(', ') : 'core foundations';
      learningObjective = `Recovery Revision: Rebuild ${item.skillName} fundamentals with emphasis on ${topicLabel}.`;
      activities = [
        `Review beginner explanations for ${topicLabel}.`,
        `Work through step-by-step foundational exercises before moving forward.`,
        `Retake the ${item.skillName} diagnostic assessment after completing revision.`,
      ];
      practicalExercise = `Write 5 small isolated drills specifically practicing ${topicLabel} without external libraries.`;
    } else if (isFocusedPractice) {
      priorityTag = 'Focused Practice';
      const topicLabel = weakTopics.length > 0 ? weakTopics.join(', ') : 'intermediate concepts';
      learningObjective = `Targeted reinforcement on ${item.skillName} (${topicLabel}) to cross the 85% progression threshold.`;
      activities = [
        `Complete targeted practice problems on ${topicLabel}.`,
        `Refactor an existing snippet using clean ${item.skillName} patterns.`,
        `Reattempt ${matchingAssessment.title} to verify consistency.`,
      ];
      practicalExercise = `Build an interactive ${item.skillName} feature exercising ${topicLabel}.`;
    } else if (isFocusedProgression) {
      priorityTag = 'Advanced Progression';
      learningObjective = `Progression Unlocked: Master advanced ${item.skillName} architecture, concurrency, and optimization patterns.`;
      activities = [
        `Explore advanced ${item.skillName} internals and performance patterns.`,
        `Complete the ${matchingAssessment.title} challenge.`,
        `Integrate advanced ${item.skillName} patterns into your capstone project.`,
      ];
      practicalExercise = `Implement an async, production-hardened ${item.skillName} module with full error handling.`;
    }

    return {
      stageId: `stage-${item.skillId}-${idx + 1}`,
      order: idx + 1,
      skillId: item.skillId,
      skillName: item.skillName,
      priorityTag,
      learningObjective,
      estimatedHours: baseHours,
      estimatedDurationLabel: `${baseHours} hrs · ~${weeks} wk${weeks > 1 ? 's' : ''}`,
      activities,
      resources,
      practicalExercise,
      assessmentId: matchingAssessment.assessmentId,
      assessmentTitle: matchingAssessment.title,
      status: 'pending',
      focusTopics: item.skillId === focusSkillId ? weakTopics : [],
    };
  });
}

export function normalizeProficiency(val: number): ProficiencyLevel {
  if (val <= 0) return 0;
  if (val === 1) return 1;
  if (val === 2) return 2;
  if (val === 3) return 3;
  return 4;
}
