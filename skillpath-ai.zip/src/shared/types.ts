export type CareerGoal =
  | 'Full Stack Developer'
  | 'Frontend Developer'
  | 'Backend Developer'
  | 'Data Analyst';

export type ProficiencyLevel = 0 | 1 | 2 | 3 | 4;

export const PROFICIENCY_LABELS: Record<ProficiencyLevel, string> = {
  0: 'No knowledge',
  1: 'Beginner',
  2: 'Basic',
  3: 'Intermediate',
  4: 'Advanced',
};

export type AdaptiveMode =
  | 'baseline'
  | 'recovery'
  | 'practice'
  | 'progression'
  | 'career_switch';

export type TaskStatus = 'pending' | 'in_progress' | 'completed';

export type PageId =
  | 'landing'
  | 'auth'
  | 'dashboard'
  | 'profile'
  | 'skills'
  | 'careers'
  | 'roadmap'
  | 'resources'
  | 'assessments'
  | 'progress'
  | 'mentor'
  | 'agents'
  | 'settings';

export interface ProjectItem {
  id: string;
  title: string;
  description: string;
  techStack: string[];
}

export interface LearningPreferences {
  weeklyHours: number;
  learningStyle: string;
  pace: string;
}

export interface AdaptiveConfig {
  recoveryThreshold: number; // default 50 (< 50% => recovery)
  progressionThreshold: number; // default 85 (>= 85% => progression)
}

export interface LearnerProfile {
  userId: string;
  name: string;
  email: string;
  education: string;
  college: string;
  department: string;
  yearOfStudy: string;
  careerGoal: CareerGoal;
  certifications: string[];
  projects: ProjectItem[];
  learningPreferences: LearningPreferences;
  adaptiveConfig: AdaptiveConfig;
  createdAt?: unknown;
  updatedAt?: unknown;
}

export interface UserSkill {
  id?: string;
  userId: string;
  skillId: string;
  skillName: string;
  category: string;
  proficiency: ProficiencyLevel;
  evidenceCount: number;
  weakTopics: string[];
  mastered: boolean;
  createdAt?: unknown;
  updatedAt?: unknown;
}

export interface SkillDefinition {
  skillId: string;
  skillName: string;
  category: 'Frontend' | 'Backend' | 'Data' | 'Core Engineering';
  description: string;
}

export interface CareerSkillRequirement {
  skillId: string;
  skillName: string;
  category: string;
  requiredProficiency: ProficiencyLevel;
  weight: number;
  prerequisites: string[];
}

export interface CareerProfile {
  careerId: string;
  title: CareerGoal;
  description: string;
  salaryBand: string;
  requirements: CareerSkillRequirement[];
}

export interface SkillGapItem {
  skillId: string;
  skillName: string;
  category: string;
  currentProficiency: ProficiencyLevel;
  requiredProficiency: ProficiencyLevel;
  weight: number;
  gap: number;
  priorityScore: number;
  prerequisites: string[];
  prerequisitesMet: boolean;
  unmetPrerequisites: string[];
  status: 'strong' | 'weak' | 'missing';
  explanation: string;
}

export interface SkillGapAnalysis {
  id?: string;
  userId: string;
  careerGoal: CareerGoal;
  readinessScore: number;
  strongSkills: SkillGapItem[];
  weakSkills: SkillGapItem[];
  missingSkills: SkillGapItem[];
  prioritySkills: SkillGapItem[];
  explanations: Array<{ skillId: string; skillName: string; reason: string }>;
  createdAt?: unknown;
  updatedAt?: unknown;
}

export interface VerifiedResource {
  resourceId: string;
  skillId: string;
  skillName: string;
  title: string;
  platform: string;
  url: string;
  level: 'Beginner' | 'Intermediate' | 'Advanced';
  format: 'Documentation' | 'Interactive Course' | 'Guide' | 'Practice';
  estimatedHours: number;
}

export interface UserResourceState extends VerifiedResource {
  userId: string;
  bookmarked: boolean;
  completed: boolean;
}

export interface RoadmapStage {
  stageId: string;
  order: number;
  skillId: string;
  skillName: string;
  priorityTag: 'Critical Gap' | 'Recovery Revision' | 'Focused Practice' | 'Advanced Progression' | 'Foundation';
  learningObjective: string;
  estimatedHours: number;
  estimatedDurationLabel: string;
  activities: string[];
  resources: VerifiedResource[];
  practicalExercise: string;
  assessmentId: string;
  assessmentTitle: string;
  status: TaskStatus;
  focusTopics?: string[];
}

export interface LearningRoadmap {
  id?: string;
  userId: string;
  careerGoal: CareerGoal;
  adaptiveMode: AdaptiveMode;
  adaptationReason: string;
  summary: string;
  stages: RoadmapStage[];
  createdAt?: unknown;
  updatedAt?: unknown;
}

export interface LearningTask {
  id?: string;
  userId: string;
  roadmapId: string;
  skillId: string;
  title: string;
  stageOrder: number;
  status: TaskStatus;
  estimatedHours: number;
  createdAt?: unknown;
  updatedAt?: unknown;
}

export interface QuizQuestion {
  id: string;
  topic: string;
  difficulty: 'Beginner' | 'Intermediate' | 'Advanced';
  question: string;
  options: [string, string, string, string];
  correctIndex: number;
  explanation: string;
}

export interface AssessmentSpec {
  assessmentId: string;
  skillId: string;
  skillName: string;
  title: string;
  difficulty: 'Beginner' | 'Intermediate' | 'Advanced';
  description: string;
  questions: QuizQuestion[];
}

export interface TopicPerformance {
  topic: string;
  total: number;
  correct: number;
  accuracy: number;
}

export interface AssessmentAttempt {
  id?: string;
  userId: string;
  assessmentId: string;
  skillId: string;
  skillName: string;
  score: number;
  totalQuestions: number;
  correctCount: number;
  adaptiveMode: 'recovery' | 'practice' | 'progression';
  weakTopics: string[];
  topicBreakdown: TopicPerformance[];
  evaluationSummary: string;
  createdAt?: unknown;
  timestampIso?: string;
}

export interface ProgressRecord {
  id?: string;
  userId: string;
  eventType: 'assessment' | 'task_completed' | 'goal_switch' | 'profile_update' | 'adaptation';
  skillId: string;
  skillName: string;
  readinessScore: number;
  detail: string;
  createdAt?: unknown;
  timestampIso?: string;
}

export type AgentName =
  | 'Profile Analysis Agent'
  | 'Skill Gap Analysis Agent'
  | 'Career Matching Agent'
  | 'Learning Recommendation Agent'
  | 'Progress Evaluation Agent'
  | 'AI Mentor Agent';

export type AgentRuntimeStatus = 'idle' | 'running' | 'completed' | 'error';

export interface AgentLogEntry {
  id?: string;
  userId: string;
  runId: string;
  agentName: AgentName;
  stepOrder: number;
  status: 'completed' | 'error';
  inputSummary: string;
  outputSummary: string;
  errorMessage: string;
  durationMs: number;
  createdAt?: unknown;
  timestampIso?: string;
}

export interface MentorMessage {
  id?: string;
  userId: string;
  role: 'user' | 'mentor';
  content: string;
  careerGoal: CareerGoal;
  createdAt?: unknown;
  timestampIso?: string;
}

export interface CareerMatchResult {
  careerId: string;
  careerGoal: CareerGoal;
  description: string;
  readinessScore: number;
  strongCount: number;
  weakCount: number;
  missingCount: number;
  topMissingSkills: string[];
  aiRationale?: string;
}
