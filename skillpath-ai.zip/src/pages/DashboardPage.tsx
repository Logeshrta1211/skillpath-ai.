import React from 'react';
import {
  Bar,
  BarChart,
  CartesianGrid,
  Legend,
  Line,
  LineChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from 'recharts';
import { ArrowRight, BookOpen, CheckCircle2, FileCheck2, Sparkles } from 'lucide-react';
import { useApp } from '../context/AppContext.tsx';
import { PROFICIENCY_LABELS } from '../shared/types.ts';

export function DashboardPage() {
  const {
    profile,
    skills,
    analysis,
    roadmap,
    attempts,
    progress,
    profileInsight,
    setCurrentPage,
    isLoadingWorkspace,
  } = useApp();

  if (isLoadingWorkspace || !profile || !analysis) {
    return (
      <div className="space-y-6">
        <div className="h-24 rounded-xl sp-card" />
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {[1, 2, 3, 4].map((i) => (
            <div key={i} className="h-28 rounded-xl sp-card" />
          ))}
        </div>
        <div className="h-80 rounded-xl sp-card" />
      </div>
    );
  }

  const skillsMasteredCount = skills.filter((s) => s.mastered || s.proficiency >= 4).length;
  const skillsInProgressCount = skills.filter((s) => s.proficiency > 0 && !s.mastered && s.proficiency < 4).length;
  const missingSkillsCount = analysis.missingSkills.length;

  const totalStages = roadmap?.stages.length ?? 0;
  const completedStages = roadmap?.stages.filter((s) => s.status === 'completed').length ?? 0;
  const roadmapCompletionPct = totalStages > 0 ? Math.round((completedStages / totalStages) * 100) : 0;

  const nextStage =
    roadmap?.stages.find((s) => s.status !== 'completed') ?? roadmap?.stages[0] ?? null;

  const gapChartData = [
    ...analysis.strongSkills,
    ...analysis.weakSkills,
    ...analysis.missingSkills,
  ].map((item) => ({
    name: item.skillName.length > 12 ? `${item.skillName.slice(0, 11)}…` : item.skillName,
    Current: item.currentProficiency,
    Required: item.requiredProficiency,
  }));

  const attemptTrendData = [...attempts]
    .reverse()
    .map((att, index) => ({
      attempt: `#${index + 1} ${att.skillName}`,
      score: att.score,
    }));

  const averageAssessmentScore =
    attempts.length > 0
      ? Math.round(attempts.reduce((sum, a) => sum + a.score, 0) / attempts.length)
      : null;

  return (
    <div className="space-y-8">
      {/* Header Summary */}
      <section className="rounded-xl sp-card p-6 flex flex-col lg:flex-row lg:items-center justify-between gap-6">
        <div className="space-y-2 max-w-2xl">
          <div className="text-xs font-medium text-sky-400">
            Target Role: {profile.careerGoal} · Adaptive Mode: {(roadmap?.adaptiveMode ?? 'baseline').replace('_', ' ').toUpperCase()}
          </div>
          <h2 className="font-display text-2xl sm:text-3xl font-bold text-white text-balance">
            Welcome back, {profile.name}
          </h2>
          <p className="text-sm text-slate-300 leading-relaxed">
            {profileInsight?.headline ??
              roadmap?.adaptationReason ??
              `Your deterministic readiness for ${profile.careerGoal} is ${analysis.readinessScore}%.`}
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-3 shrink-0">
          <button
            type="button"
            onClick={() => setCurrentPage('assessments')}
            className="px-4 py-2.5 rounded-lg text-xs font-semibold sp-btn-primary flex items-center gap-2 whitespace-nowrap"
          >
            <FileCheck2 className="w-4 h-4" />
            <span>Take Assessment</span>
          </button>
          <button
            type="button"
            onClick={() => setCurrentPage('roadmap')}
            className="px-4 py-2.5 rounded-lg text-xs font-semibold sp-btn-secondary flex items-center gap-2 whitespace-nowrap"
          >
            <Sparkles className="w-4 h-4 text-sky-400" />
            <span>View Roadmap</span>
          </button>
        </div>
      </section>

      {/* KPI Strip */}
      <section className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
        <div className="rounded-xl sp-card p-5 space-y-1">
          <div className="text-xs text-slate-400">Career Readiness</div>
          <div className="font-mono text-3xl font-bold text-sky-400 tabular-nums">
            {analysis.readinessScore}%
          </div>
          <div className="text-xs text-slate-400">Deterministic weighted score</div>
        </div>

        <div className="rounded-xl sp-card p-5 space-y-1">
          <div className="text-xs text-slate-400">Skills Mastered</div>
          <div className="font-mono text-3xl font-bold text-emerald-400 tabular-nums">
            {skillsMasteredCount}
          </div>
          <div className="text-xs text-slate-400">Multi-assessment verified</div>
        </div>

        <div className="rounded-xl sp-card p-5 space-y-1">
          <div className="text-xs text-slate-400">Skills in Progress</div>
          <div className="font-mono text-3xl font-bold text-amber-400 tabular-nums">
            {skillsInProgressCount}
          </div>
          <div className="text-xs text-slate-400">Active proficiency 1–3</div>
        </div>

        <div className="rounded-xl sp-card p-5 space-y-1">
          <div className="text-xs text-slate-400">Missing Skills</div>
          <div className="font-mono text-3xl font-bold text-rose-400 tabular-nums">
            {missingSkillsCount}
          </div>
          <div className="text-xs text-slate-400">Required at 0/4 proficiency</div>
        </div>

        <div className="rounded-xl sp-card p-5 space-y-1">
          <div className="text-xs text-slate-400">Roadmap Completion</div>
          <div className="font-mono text-3xl font-bold text-white tabular-nums">
            {roadmapCompletionPct}%
          </div>
          <div className="text-xs text-slate-400 tabular-nums">
            {completedStages} / {totalStages} stages done
          </div>
        </div>
      </section>

      {/* Recommended Next Action */}
      {nextStage && (
        <section className="rounded-xl sp-card-accent p-6 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-1.5">
            <div className="text-xs font-medium text-sky-300">
              Recommended Next Action · Stage {nextStage.order} · {nextStage.priorityTag}
            </div>
            <h3 className="font-display text-lg font-semibold text-white">
              Focus on {nextStage.skillName}: {nextStage.learningObjective}
            </h3>
            <p className="text-xs text-slate-400">
              Estimated effort: {nextStage.estimatedDurationLabel} · Linked Quiz: {nextStage.assessmentTitle}
            </p>
          </div>
          <div className="flex items-center gap-3 shrink-0">
            <button
              type="button"
              onClick={() => setCurrentPage('roadmap')}
              className="px-4 py-2.5 rounded-lg text-xs font-semibold sp-btn-primary flex items-center gap-2 whitespace-nowrap"
            >
              <span>Start Stage</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </section>
      )}

      {/* Charts Row */}
      <section className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <div className="lg:col-span-7 rounded-xl sp-card p-6 space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="font-display text-base font-semibold text-white">
                Current vs Required Proficiency ({profile.careerGoal})
              </h3>
              <p className="text-xs text-slate-400">
                Scale: 0 (None) to 4 (Advanced) across required career skills
              </p>
            </div>
          </div>

          <div className="h-72 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={gapChartData} margin={{ top: 10, right: 12, left: -16, bottom: 20 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#16223B" />
                <XAxis
                  dataKey="name"
                  tick={{ fill: '#94A3B8', fontSize: 11 }}
                  angle={-20}
                  textAnchor="end"
                  height={48}
                />
                <YAxis domain={[0, 4]} ticks={[0, 1, 2, 3, 4]} tick={{ fill: '#94A3B8', fontSize: 11 }} />
                <Tooltip
                  contentStyle={{
                    backgroundColor: '#030712',
                    borderColor: '#1E293B',
                    borderRadius: '8px',
                    fontSize: '12px',
                    color: '#F1F5F9',
                  }}
                />
                <Legend wrapperStyle={{ fontSize: '12px' }} />
                <Bar dataKey="Current" fill="#38BDF8" radius={[4, 4, 0, 0]} />
                <Bar dataKey="Required" fill="#2563EB" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="lg:col-span-5 rounded-xl sp-card p-6 space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="font-display text-base font-semibold text-white">
                Assessment Performance
              </h3>
              <p className="text-xs text-slate-400 tabular-nums">
                {averageAssessmentScore !== null
                  ? `Average score: ${averageAssessmentScore}% across ${attempts.length} attempt(s)`
                  : 'No assessments submitted yet'}
              </p>
            </div>
          </div>

          {attemptTrendData.length > 0 ? (
            <div className="h-72 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={attemptTrendData} margin={{ top: 10, right: 12, left: -16, bottom: 20 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#16223B" />
                  <XAxis dataKey="attempt" tick={{ fill: '#94A3B8', fontSize: 11 }} />
                  <YAxis domain={[0, 100]} tick={{ fill: '#94A3B8', fontSize: 11 }} />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: '#030712',
                      borderColor: '#1E293B',
                      borderRadius: '8px',
                      fontSize: '12px',
                      color: '#F1F5F9',
                    }}
                  />
                  <Line
                    type="monotone"
                    dataKey="score"
                    stroke="#38BDF8"
                    strokeWidth={2.5}
                    dot={{ r: 4, fill: '#10B981' }}
                  />
                </LineChart>
              </ResponsiveContainer>
            </div>
          ) : (
            <div className="h-72 flex flex-col items-center justify-center text-center p-6 border border-dashed border-slate-800 rounded-lg space-y-3">
              <BookOpen className="w-7 h-7 text-slate-500" />
              <div className="text-sm font-medium text-slate-200">No Assessment History Yet</div>
              <p className="text-xs text-slate-400 max-w-xs">
                Complete a skill assessment to evaluate weak topics and trigger adaptive roadmap adjustments.
              </p>
              <button
                type="button"
                onClick={() => setCurrentPage('assessments')}
                className="px-4 py-2 rounded-lg text-xs font-semibold sp-btn-primary"
              >
                Open Assessments
              </button>
            </div>
          )}
        </div>
      </section>

      {/* Priority Gaps & Recent Activity */}
      <section className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <div className="lg:col-span-6 rounded-xl sp-card p-6 space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="font-display text-base font-semibold text-white">Priority Skill Gaps</h3>
            <button
              type="button"
              onClick={() => setCurrentPage('skills')}
              className="text-xs text-sky-400 hover:text-sky-300 font-medium"
            >
              Full Breakdown
            </button>
          </div>
          {analysis.prioritySkills.length === 0 ? (
            <div className="text-sm text-emerald-400 flex items-center gap-2 py-4">
              <CheckCircle2 className="w-4 h-4" />
              <span>All required skills meet or exceed target benchmarks.</span>
            </div>
          ) : (
            <div className="divide-y divide-slate-800/80">
              {analysis.prioritySkills.slice(0, 5).map((item) => (
                <div key={item.skillId} className="py-3 flex items-center justify-between gap-4">
                  <div className="min-w-0">
                    <div className="text-sm font-medium text-white truncate">{item.skillName}</div>
                    <div className="text-xs text-slate-400 truncate">
                      {item.status === 'missing' ? 'Missing' : 'Weak'} · Weight {item.weight}x ·{' '}
                      {item.prerequisitesMet
                        ? 'Prerequisites met'
                        : `Needs ${item.unmetPrerequisites.join(', ')}`}
                    </div>
                  </div>
                  <div className="font-mono text-xs text-slate-200 tabular-nums shrink-0">
                    {PROFICIENCY_LABELS[item.currentProficiency]} ({item.currentProficiency}/{item.requiredProficiency})
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        <div className="lg:col-span-6 rounded-xl sp-card p-6 space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="font-display text-base font-semibold text-white">Recent Learning Activity</h3>
            <button
              type="button"
              onClick={() => setCurrentPage('progress')}
              className="text-xs text-sky-400 hover:text-sky-300 font-medium"
            >
              View All
            </button>
          </div>
          {progress.length === 0 ? (
            <div className="text-sm text-slate-400 py-4">
              Activity events appear as you complete assessments, finish stages, or update goals.
            </div>
          ) : (
            <div className="divide-y divide-slate-800/80">
              {progress.slice(0, 5).map((item, idx) => (
                <div key={item.id ?? idx} className="py-3 space-y-1">
                  <div className="flex items-center justify-between text-xs text-slate-400">
                    <span className="font-medium text-sky-300">{item.skillName}</span>
                    <span className="font-mono tabular-nums">
                      Readiness {item.readinessScore}%
                    </span>
                  </div>
                  <div className="text-sm text-slate-200">{item.detail}</div>
                </div>
              ))}
            </div>
          )}
        </div>
      </section>
    </div>
  );
}
