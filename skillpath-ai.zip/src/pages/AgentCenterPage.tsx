import React, { useState } from 'react';
import { Activity, AlertCircle, CheckCircle2, Clock, Play } from 'lucide-react';
import { useApp } from '../context/AppContext.tsx';
import type { AgentName } from '../shared/types.ts';

const AGENT_SPECS: Array<{
  name: AgentName;
  order: number;
  responsibility: string;
}> = [
  {
    name: 'Profile Analysis Agent',
    order: 1,
    responsibility: 'Analyzes learner academic background, project stack, certifications, and weekly bandwidth (Parallel Tier).',
  },
  {
    name: 'Skill Gap Analysis Agent',
    order: 2,
    responsibility: 'Explains deterministic skill gaps, prerequisite blockers, and high-weight priority skills (Parallel Tier).',
  },
  {
    name: 'Career Matching Agent',
    order: 3,
    responsibility: 'Evaluates readiness across Full Stack, Frontend, Backend, and Data Analyst tracks (Parallel Tier).',
  },
  {
    name: 'Learning Recommendation Agent',
    order: 4,
    responsibility: 'Synthesizes upstream outputs from Agents 1–3 into sequenced roadmaps with verified free resources (Deep Synthesis).',
  },
  {
    name: 'Progress Evaluation Agent',
    order: 5,
    responsibility: 'Diagnoses assessment scores and weak subtopics to drive Recovery, Practice, and Progression adaptations (Deep Reasoning).',
  },
  {
    name: 'AI Mentor Agent',
    order: 6,
    responsibility: 'Delivers grounded coaching with 3-step action plans, metric citations, and verified resource recommendations.',
  },
];

export function AgentCenterPage() {
  const { agentStatuses, agentLogs, runOrchestrationNow, isOrchestrating } = useApp();
  const [runError, setRunError] = useState<string | null>(null);

  const handleRunPipeline = async () => {
    setRunError(null);
    try {
      await runOrchestrationNow();
    } catch (err) {
      setRunError(err instanceof Error ? err.message : 'Agent orchestrator encountered an error.');
    }
  };

  return (
    <div className="space-y-8">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="font-display text-2xl font-bold text-white">Agent Activity Center</h2>
          <p className="text-sm text-slate-400">
            Displays real orchestrator execution states, structured inputs/outputs, durations, and persisted error logs only.
          </p>
        </div>
        <button
          type="button"
          disabled={isOrchestrating}
          onClick={handleRunPipeline}
          className="px-4 py-2.5 rounded-lg text-xs font-semibold sp-btn-primary disabled:opacity-50 flex items-center gap-2 whitespace-nowrap shrink-0"
        >
          <Play className="w-3.5 h-3.5" />
          <span>{isOrchestrating ? 'Executing Pipeline...' : 'Run Orchestrator Pipeline'}</span>
        </button>
      </div>

      {runError && (
        <div className="p-4 rounded-xl bg-rose-950/70 border border-rose-500/40 text-sm text-rose-200">
          {runError}
        </div>
      )}

      {/* Six Agents Grid */}
      <section className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
        {AGENT_SPECS.map((spec) => {
          const status = agentStatuses[spec.name];
          const latestLog = agentLogs.find((l) => l.agentName === spec.name);
          return (
            <div
              key={spec.name}
              className={`rounded-xl p-5 space-y-3 ${
                status === 'running'
                  ? 'sp-card-accent border-sky-400/70'
                  : status === 'error'
                    ? 'sp-card border-rose-500/60'
                    : status === 'completed'
                      ? 'sp-card border-emerald-500/40'
                      : 'sp-card'
              }`}
            >
              <div className="flex items-center justify-between gap-2">
                <span className="font-mono text-xs text-slate-400">0{spec.order}. AGENT</span>
                <span className="text-xs font-semibold flex items-center gap-1.5">
                  {status === 'running' && (
                    <>
                      <Activity className="w-3.5 h-3.5 text-sky-400 animate-spin" />
                      <span className="text-sky-300">Running</span>
                    </>
                  )}
                  {status === 'completed' && (
                    <>
                      <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                      <span className="text-emerald-300">Completed</span>
                    </>
                  )}
                  {status === 'error' && (
                    <>
                      <AlertCircle className="w-3.5 h-3.5 text-rose-400" />
                      <span className="text-rose-300">Error</span>
                    </>
                  )}
                  {status === 'idle' && (
                    <>
                      <Clock className="w-3.5 h-3.5 text-slate-500" />
                      <span className="text-slate-400">Standby</span>
                    </>
                  )}
                </span>
              </div>

              <h3 className="font-display text-base font-semibold text-white">{spec.name}</h3>
              <p className="text-xs text-slate-400 leading-relaxed">{spec.responsibility}</p>

              {latestLog && (
                <div className="pt-3 border-t border-slate-800/80 text-xs space-y-1">
                  <div className="text-slate-400 font-mono tabular-nums">
                    Last run: {latestLog.durationMs} ms ·{' '}
                    {latestLog.timestampIso
                      ? new Date(latestLog.timestampIso).toLocaleTimeString()
                      : 'Saved'}
                  </div>
                  <div className="text-slate-200 line-clamp-2">{latestLog.outputSummary}</div>
                </div>
              )}
            </div>
          );
        })}
      </section>

      {/* Real Execution Log Ledger */}
      <section className="rounded-xl sp-card overflow-hidden">
        <div className="px-6 py-4 border-b border-slate-800/80 flex items-center justify-between">
          <h3 className="font-display text-base font-semibold text-white">
            Recorded Execution Log Ledger
          </h3>
          <span className="font-mono text-xs text-slate-400 tabular-nums">
            {agentLogs.length} real execution record(s)
          </span>
        </div>

        {agentLogs.length === 0 ? (
          <div className="p-8 text-center text-sm text-slate-400">
            No agent execution logs recorded yet. Click &ldquo;Run Orchestrator Pipeline&rdquo;, save your profile, submit an assessment, or message the AI Mentor to record real agent runs.
          </div>
        ) : (
          <div className="divide-y divide-slate-800/80">
            {agentLogs.map((log, idx) => (
              <div key={log.id ?? `${log.runId}-${log.stepOrder}-${idx}`} className="p-5 space-y-2">
                <div className="flex flex-wrap items-center justify-between gap-2 text-xs">
                  <div className="font-semibold text-white">
                    Step {log.stepOrder} · {log.agentName} ·{' '}
                    <span className={log.status === 'completed' ? 'text-emerald-400' : 'text-rose-400'}>
                      {log.status.toUpperCase()}
                    </span>
                  </div>
                  <div className="font-mono text-slate-400 tabular-nums">
                    {log.durationMs} ms ·{' '}
                    {log.timestampIso ? new Date(log.timestampIso).toLocaleString() : 'Timestamped'}
                  </div>
                </div>
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-3 text-xs">
                  <div className="p-3 rounded-lg sp-inset">
                    <div className="text-slate-400 font-medium mb-1">Input Summary</div>
                    <div className="text-slate-200 leading-relaxed">{log.inputSummary}</div>
                  </div>
                  <div className="p-3 rounded-lg sp-inset">
                    <div className="text-slate-400 font-medium mb-1">
                      {log.status === 'error' ? 'Error Details' : 'Validated Output Summary'}
                    </div>
                    <div
                      className={`leading-relaxed ${
                        log.status === 'error' ? 'text-rose-300' : 'text-sky-200'
                      }`}
                    >
                      {log.status === 'error' ? log.errorMessage || log.outputSummary : log.outputSummary}
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </section>
    </div>
  );
}
