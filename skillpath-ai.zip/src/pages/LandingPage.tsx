import React from 'react';
import {
  Activity,
  ArrowRight,
  Bot,
  Compass,
  GitBranch,
  Layers,
  ShieldCheck,
  TrendingUp,
} from 'lucide-react';
import { useApp } from '../context/AppContext.tsx';

export function LandingPage() {
  const { setCurrentPage, enterDemoMode, isOrchestrating } = useApp();

  const agents = [
    {
      index: '01',
      name: 'Profile Analysis Agent',
      desc: 'Evaluates academic background, project stack, certifications, and weekly study bandwidth.',
      icon: Layers,
    },
    {
      index: '02',
      name: 'Skill Gap Analysis Agent',
      desc: 'Pairs deterministic gap scoring with prerequisite dependency explanations.',
      icon: GitBranch,
    },
    {
      index: '03',
      name: 'Career Matching Agent',
      desc: 'Compares learner readiness across Full Stack, Frontend, Backend, and Data Analyst tracks.',
      icon: Compass,
    },
    {
      index: '04',
      name: 'Learning Recommendation Agent',
      desc: 'Builds sequenced roadmaps linking verified free documentation, exercises, and quizzes.',
      icon: TrendingUp,
    },
    {
      index: '05',
      name: 'Progress Evaluation Agent',
      desc: 'Diagnoses weak assessment topics and reorders roadmap stages across Recovery, Practice, and Progression modes.',
      icon: Activity,
    },
    {
      index: '06',
      name: 'AI Mentor Agent',
      desc: 'Provides contextual guidance anchored in your actual readiness score, gaps, and quiz history.',
      icon: Bot,
    },
  ];

  return (
    <div className="min-h-screen bg-transparent text-slate-100 flex flex-col">
      {/* 3-Zone Top Bar Contract */}
      <header className="border-b border-sky-500/15 bg-[#040813]/96 sticky top-0 z-30">
        <div className="max-w-7xl mx-auto px-6 h-16 flex items-center justify-between gap-8">
          <button
            type="button"
            onClick={() => setCurrentPage('landing')}
            className="font-display text-lg font-bold tracking-tight text-white whitespace-nowrap shrink-0"
          >
            SkillPath AI
          </button>

          <nav className="hidden md:flex items-center gap-6 text-sm font-medium text-slate-300">
            <a href="#engine" className="hover:text-white transition-colors whitespace-nowrap shrink-0">
              Skill Engine
            </a>
            <a href="#agents" className="hover:text-white transition-colors whitespace-nowrap shrink-0">
              Six Agents
            </a>
            <a href="#adaptive" className="hover:text-white transition-colors whitespace-nowrap shrink-0">
              Adaptive Loop
            </a>
            <button
              type="button"
              onClick={() => enterDemoMode()}
              className="hover:text-sky-300 transition-colors whitespace-nowrap shrink-0"
            >
              Demo Scenario
            </button>
          </nav>

          <div className="flex items-center gap-3 shrink-0">
            <button
              type="button"
              onClick={() => setCurrentPage('auth')}
              className="px-4 py-2 rounded-lg text-xs font-semibold sp-btn-primary whitespace-nowrap shrink-0"
            >
              Sign In
            </button>
          </div>
        </div>
      </header>

      <main className="flex-1">
        {/* Hero */}
        <section className="max-w-7xl mx-auto px-6 pt-16 pb-20 grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          <div className="lg:col-span-7 space-y-6">
            <div className="text-xs font-medium text-sky-400 tracking-wide">
              Multi-Agent Adaptive Career Platform · Deterministic Readiness + Gemini Orchestration
            </div>
            <h1 className="font-display text-4xl sm:text-5xl lg:text-6xl font-bold tracking-tight text-white text-balance leading-[1.08]">
              Discover Your Gaps. Build Your Skills. Achieve Your Career.
            </h1>
            <p className="text-base sm:text-lg text-slate-300 max-w-2xl leading-relaxed">
              SkillPath AI combines a transparent, deterministic skill-gap engine with six specialized Gemini agents to map your current abilities against industry role matrices, sequence verified free resources, and adapt your roadmap automatically after every assessment.
            </p>
            <div className="flex flex-wrap items-center gap-4 pt-2">
              <button
                type="button"
                onClick={() => setCurrentPage('auth')}
                className="px-6 py-3 rounded-lg text-sm font-semibold sp-btn-primary flex items-center gap-2 whitespace-nowrap"
              >
                <span>Create Learner Workspace</span>
                <ArrowRight className="w-4 h-4" />
              </button>
              <button
                type="button"
                disabled={isOrchestrating}
                onClick={() => enterDemoMode()}
                className="px-6 py-3 rounded-lg text-sm font-semibold sp-btn-secondary whitespace-nowrap disabled:opacity-60"
              >
                {isOrchestrating ? 'Initializing Alex Demo...' : 'Launch Alex Demo Sandbox'}
              </button>
            </div>
          </div>

          <div className="lg:col-span-5">
            <div className="rounded-xl sp-card-accent p-6 space-y-5">
              <div className="flex items-center justify-between border-b border-slate-800/80 pb-4">
                <div>
                  <div className="text-xs text-slate-400">Deterministic Readiness Formula</div>
                  <div className="font-display text-lg font-semibold text-white mt-0.5">
                    Transparent Career Scoring
                  </div>
                </div>
                <ShieldCheck className="w-5 h-5 text-sky-400" />
              </div>

              <div className="font-mono text-xs sp-inset rounded-lg p-4 text-sky-300 leading-relaxed">
                Readiness = SUM(weight × MIN(current / required, 1)) / SUM(weight) × 100
              </div>

              <div className="space-y-2 text-sm">
                <div className="flex items-center justify-between py-2.5 border-b border-slate-800/70">
                  <span className="text-slate-300">Below 50% Quiz Score</span>
                  <span className="font-mono text-rose-400 font-medium">Recovery Mode</span>
                </div>
                <div className="flex items-center justify-between py-2.5 border-b border-slate-800/70">
                  <span className="text-slate-300">50% – 84% Quiz Score</span>
                  <span className="font-mono text-amber-400 font-medium">Practice Mode</span>
                </div>
                <div className="flex items-center justify-between py-2.5">
                  <span className="text-slate-300">85% and Above</span>
                  <span className="font-mono text-emerald-400 font-medium">Progression Mode</span>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Skill Engine Overview */}
        <section id="engine" className="border-t border-sky-500/15 bg-[#050A17]/88">
          <div className="max-w-7xl mx-auto px-6 py-16 grid grid-cols-1 md:grid-cols-3 gap-10">
            <div className="space-y-2">
              <div className="text-xs font-mono text-sky-400">01. Deterministic Math</div>
              <h2 className="font-display text-xl font-semibold text-white">No Invented Percentages</h2>
              <p className="text-sm text-slate-400 leading-relaxed">
                Readiness scores and missing-skill rankings are calculated mathematically from weighted role requirements and 0–4 proficiency evidence before any AI agent generates explanations.
              </p>
            </div>
            <div className="space-y-2">
              <div className="text-xs font-mono text-amber-400">02. Multi-Quiz Evidence</div>
              <h2 className="font-display text-xl font-semibold text-white">Evidence-Backed Mastery</h2>
              <p className="text-sm text-slate-400 leading-relaxed">
                A single quiz never grants skill mastery. Assessments record topic-level accuracy, surface weak subtopics, and require repeated mastery plus met prerequisites to unlock advanced stages.
              </p>
            </div>
            <div className="space-y-2">
              <div className="text-xs font-mono text-emerald-400">03. Firestore Ownership</div>
              <h2 className="font-display text-xl font-semibold text-white">Persistent &amp; Isolated</h2>
              <p className="text-sm text-slate-400 leading-relaxed">
                Authenticated learners store profiles, roadmaps, assessment attempts, and agent logs across 12 Firestore collections protected by strict owner-verified security rules.
              </p>
            </div>
          </div>
        </section>

        {/* Six Agents */}
        <section id="agents" className="max-w-7xl mx-auto px-6 py-16 space-y-10">
          <div className="max-w-2xl space-y-2">
            <h2 className="font-display text-3xl font-bold text-white text-balance">
              Six Specialized AI Agents Under One Orchestrator
            </h2>
            <p className="text-sm text-slate-400">
              Every agent execution is validated with structured JSON schemas and logged with real timestamps and latency in the Agent Activity Center.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {agents.map((agent) => {
              const Icon = agent.icon;
              return (
                <div
                  key={agent.name}
                  className="p-6 rounded-xl sp-card space-y-3"
                >
                  <div className="flex items-center justify-between">
                    <Icon className="w-5 h-5 text-sky-400" />
                    <span className="font-mono text-xs text-slate-500">{agent.index}</span>
                  </div>
                  <h3 className="font-display text-base font-semibold text-white">{agent.name}</h3>
                  <p className="text-sm text-slate-400 leading-relaxed">{agent.desc}</p>
                </div>
              );
            })}
          </div>
        </section>

        {/* Adaptive Loop & Judge Demo CTA */}
        <section id="adaptive" className="border-t border-sky-500/15 bg-[#050A17]/88">
          <div className="max-w-7xl mx-auto px-6 py-16 flex flex-col lg:flex-row items-start lg:items-center justify-between gap-8">
            <div className="space-y-2 max-w-2xl">
              <h2 className="font-display text-2xl font-bold text-white">
                Explore the Interactive Alex Rivera Scenario
              </h2>
              <p className="text-sm text-slate-400 leading-relaxed">
                Test Scenario A (40% JavaScript triggering Recovery Mode), Scenario B (90% triggering Advanced Progression), and Scenario C (switching goal from Full Stack Developer to Data Analyst) directly inside the Demo Sandbox.
              </p>
            </div>
            <div className="flex flex-wrap items-center gap-3 shrink-0">
              <button
                type="button"
                onClick={() => enterDemoMode()}
                className="px-5 py-2.5 rounded-lg text-sm font-semibold sp-btn-primary whitespace-nowrap"
              >
                Open Demo Sandbox
              </button>
              <button
                type="button"
                onClick={() => setCurrentPage('auth')}
                className="px-5 py-2.5 rounded-lg text-sm font-semibold sp-btn-secondary whitespace-nowrap"
              >
                Sign In with Google
              </button>
            </div>
          </div>
        </section>
      </main>

      <footer className="border-t border-sky-500/15 py-6 px-6 text-xs text-slate-500">
        <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-4">
          <span>SkillPath AI · Adaptive Career Learning Platform</span>
          <span>Powered by Gemini API &amp; Cloud Firestore</span>
        </div>
      </footer>
    </div>
  );
}
