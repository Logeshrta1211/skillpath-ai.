import React, { useMemo, useState } from 'react';
import { Bookmark, CheckCircle2, ExternalLink, Search } from 'lucide-react';
import { useApp } from '../context/AppContext.tsx';

export function ResourcesPage() {
  const { resources, toggleResourceFlag } = useApp();
  const [search, setSearch] = useState('');
  const [skillFilter, setSkillFilter] = useState('all');
  const [onlyBookmarked, setOnlyBookmarked] = useState(false);

  const skillOptions = useMemo(() => {
    const unique = new Map<string, string>();
    for (const r of resources) {
      unique.set(r.skillId, r.skillName);
    }
    return Array.from(unique.entries());
  }, [resources]);

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    return resources.filter((r) => {
      if (skillFilter !== 'all' && r.skillId !== skillFilter) return false;
      if (onlyBookmarked && !r.bookmarked) return false;
      if (!q) return true;
      return (
        r.title.toLowerCase().includes(q) ||
        r.platform.toLowerCase().includes(q) ||
        r.skillName.toLowerCase().includes(q)
      );
    });
  }, [resources, search, skillFilter, onlyBookmarked]);

  return (
    <div className="space-y-8">
      <div>
        <h2 className="font-display text-2xl font-bold text-white">Verified Free Learning Resources</h2>
        <p className="text-sm text-slate-400">
          Curated official documentation and free interactive courses. Track completion and bookmarks persistently.
        </p>
      </div>

      {/* Filters */}
      <section className="rounded-xl sp-card p-4 flex flex-col md:flex-row gap-3 items-stretch md:items-center justify-between">
        <div className="relative flex-1">
          <Search className="w-4 h-4 text-slate-500 absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Search by skill, platform (MDN, freeCodeCamp, React.dev), or title..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full pl-10 pr-4 py-2 rounded-lg sp-input text-sm"
          />
        </div>
        <div className="flex flex-wrap items-center gap-3">
          <select
            aria-label="Filter by skill"
            value={skillFilter}
            onChange={(e) => setSkillFilter(e.target.value)}
            className="px-3.5 py-2 rounded-lg sp-input text-xs text-slate-200"
          >
            <option value="all">All Skills ({resources.length})</option>
            {skillOptions.map(([id, name]) => (
              <option key={id} value={id}>
                {name}
              </option>
            ))}
          </select>
          <button
            type="button"
            onClick={() => setOnlyBookmarked((v) => !v)}
            className={`px-3.5 py-2 rounded-lg text-xs font-semibold border transition-colors whitespace-nowrap ${
              onlyBookmarked
                ? 'bg-sky-500/20 border-sky-400/60 text-sky-100'
                : 'sp-btn-secondary'
            }`}
          >
            Bookmarked Only
          </button>
        </div>
      </section>

      {/* Grid */}
      {filtered.length === 0 ? (
        <div className="rounded-xl sp-card p-8 text-center text-sm text-slate-400">
          No verified resources match your filter criteria.
        </div>
      ) : (
        <section className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {filtered.map((res) => (
            <div
              key={res.resourceId}
              className="rounded-xl sp-card p-5 flex flex-col justify-between gap-4"
            >
              <div className="space-y-2">
                <div className="text-xs text-slate-400">
                  {res.skillName} · {res.platform} · {res.level}
                </div>
                <h3 className="font-display text-base font-semibold text-white leading-snug">
                  {res.title}
                </h3>
                <div className="text-xs text-slate-400 font-mono tabular-nums">
                  {res.format} · Est. {res.estimatedHours} hrs
                </div>
              </div>

              <div className="flex items-center justify-between gap-2 pt-3 border-t border-slate-800/80">
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => toggleResourceFlag(res.resourceId, 'bookmarked')}
                    className={`p-2 rounded-lg border text-xs transition-colors ${
                      res.bookmarked
                        ? 'bg-sky-500/20 border-sky-400/60 text-sky-300'
                        : 'sp-btn-secondary text-slate-400'
                    }`}
                    title="Bookmark resource"
                    aria-label={`Bookmark ${res.title}`}
                  >
                    <Bookmark className="w-3.5 h-3.5" />
                  </button>
                  <button
                    type="button"
                    onClick={() => toggleResourceFlag(res.resourceId, 'completed')}
                    className={`px-3 py-1.5 rounded-lg border text-xs font-medium flex items-center gap-1.5 transition-colors whitespace-nowrap ${
                      res.completed
                        ? 'bg-emerald-950/60 border-emerald-500/40 text-emerald-300'
                        : 'sp-btn-secondary'
                    }`}
                  >
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    <span>{res.completed ? 'Done' : 'Mark Done'}</span>
                  </button>
                </div>

                <a
                  href={res.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="px-3 py-1.5 rounded-lg sp-btn-secondary text-xs font-semibold text-sky-300 flex items-center gap-1.5 whitespace-nowrap"
                >
                  <span>Open</span>
                  <ExternalLink className="w-3.5 h-3.5" />
                </a>
              </div>
            </div>
          ))}
        </section>
      )}
    </div>
  );
}
