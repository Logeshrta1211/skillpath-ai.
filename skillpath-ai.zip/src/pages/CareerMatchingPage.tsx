import React, { useState } from 'react';
import { ArrowRight, CheckCircle2, Compass } from 'lucide-react';
import { useApp } from '../context/AppContext.tsx';
import { CAREER_CATALOG } from '../shared/catalog.ts';
import type { CareerGoal } from '../shared/types.ts';

export function CareerMatchingPage() {
  const {
    profile,
    careerMatches,
    careerAdvice,
    switchCareerGoal,
    isOrchestrating,
    setCurrentPage,
  } = useApp();

  const [switchError, setSwitchError] = useState<string | null>(null);

  if (!profile) return null;

  const handleSelectCareer = async (goal: CareerGoal) => {
    if (goal === profile.careerGoal) return;
    setSwitchError(null);
    try {
      await switchCareerGoal(goal);
    } catch (err) {
      setSwitchError(err instanceof Error ? err.message : 'Unable to switch career goal.');
    }
  };

  return (
    <div className="space-y-8">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="font-display text-2xl font-bold text-white">Career Matching &amp; Role Fit</h2>
          <p className="text-sm text-slate-400">
            Deterministic readiness calculated across all 4 industry roles. Switching goals preserves completed history.
          </p>
        </div>
        <button
          type="button"
          onClick={() => setCurrentPage('roadmap')}
          className="px-4 py-2 rounded-lg text-xs font-semibold sp-btn-secondary flex items-center gap-2 whitespace-nowrap shrink-0"
        >
          <span>View Active Roadmap</span>
          <ArrowRight className="w-3.5 h-3.5 text-sky-400" />
        </button>
      </div>

      {switchError && (
        <div className="p-4 rounded-xl bg-rose-950/70 border border-rose-500/40 text-sm text-rose-200">
          {switchError}
        </div>
      )}

      {careerAdvice && (
        <section className="rounded-xl sp-card-accent p-6 space-y-2">
          <div className="text-xs font-medium text-sky-400">Career Matching Agent Assessment</div>
          <p className="text-sm text-slate-200 leading-relaxed">{careerAdvice}</p>
        </section>
      )}

      <section className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {careerMatches.map((match) => {
          const isCurrent = match.careerGoal === profile.careerGoal;
          const catalogItem = CAREER_CATALOG.find((c) => c.title === match.careerGoal);
          return (
            <div
              key={match.careerId}
              className={`rounded-xl p-6 flex flex-col justify-between gap-5 ${
                isCurrent ? 'sp-card-accent' : 'sp-card'
              }`}
            >
              <div className="space-y-4">
                <div className="flex items-start justify-between gap-4">
                  <div>
                    <div className="text-xs text-slate-400">
                      {isCurrent ? 'Active Career Goal' : 'Alternative Career Track'} · {catalogItem?.salaryBand ?? ''}
                    </div>
                    <h3 className="font-display text-xl font-bold text-white mt-0.5">
                      {match.careerGoal}
                    </h3>
                  </div>
                  <div className="text-right shrink-0">
                    <div className="font-mono text-2xl font-bold text-sky-400 tabular-nums">
                      {match.readinessScore}%
                    </div>
                    <div className="text-xs text-slate-400">Readiness</div>
                  </div>
                </div>

                {/* Progress Bar */}
                <div className="h-2 rounded-full bg-slate-950 border border-slate-800/80 overflow-hidden">
                  <div
                    className="h-full bg-gradient-to-r from-sky-400 to-blue-600 transition-all duration-300"
                    style={{ width: `${Math.min(100, Math.max(2, match.readinessScore))}%` }}
                  />
                </div>

                <p className="text-sm text-slate-300 leading-relaxed">
                  {match.aiRationale ?? match.description}
                </p>

                <div className="grid grid-cols-3 gap-3 pt-1 text-xs border-t border-slate-800/80">
                  <div className="pt-3">
                    <div className="text-slate-400">Strong</div>
                    <div className="font-mono text-base font-semibold text-emerald-400 tabular-nums">
                      {match.strongCount}
                    </div>
                  </div>
                  <div className="pt-3">
                    <div className="text-slate-400">Weak</div>
                    <div className="font-mono text-base font-semibold text-amber-400 tabular-nums">
                      {match.weakCount}
                    </div>
                  </div>
                  <div className="pt-3">
                    <div className="text-slate-400">Missing</div>
                    <div className="font-mono text-base font-semibold text-rose-400 tabular-nums">
                      {match.missingCount}
                    </div>
                  </div>
                </div>

                {match.topMissingSkills.length > 0 && (
                  <div className="text-xs text-slate-400">
                    <span className="text-slate-300 font-medium">Top Priorities:</span>{' '}
                    {match.topMissingSkills.join(' · ')}
                  </div>
                )}
              </div>

              <div className="pt-2">
                {isCurrent ? (
                  <div className="w-full py-2.5 px-4 rounded-lg text-xs font-semibold bg-sky-950/60 border border-sky-400/40 text-sky-300 flex items-center justify-center gap-2">
                    <CheckCircle2 className="w-4 h-4" />
                    <span>Active Target Career</span>
                  </div>
                ) : (
                  <button
                    type="button"
                    disabled={isOrchestrating}
                    onClick={() => handleSelectCareer(match.careerGoal)}
                    className="w-full py-2.5 px-4 rounded-lg text-xs font-semibold sp-btn-primary flex items-center justify-center gap-2 disabled:opacity-50 whitespace-nowrap"
                  >
                    <Compass className="w-4 h-4" />
                    <span>{isOrchestrating ? 'Recalculating...' : `Switch Goal to ${match.careerGoal}`}</span>
                  </button>
                )}
              </div>
            </div>
          );
        })}
      </section>
    </div>
  );
}
