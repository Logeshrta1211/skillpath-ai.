import React, { useState } from 'react';
import { ArrowLeft, ArrowRight, CheckCircle2, FileCheck2, Play, XCircle } from 'lucide-react';
import { useApp } from '../context/AppContext.tsx';
import { ASSESSMENT_BANK } from '../shared/catalog.ts';
import type { AssessmentAttempt, AssessmentSpec } from '../shared/types.ts';

export function AssessmentsPage() {
  const {
    profile,
    submitAssessment,
    isOrchestrating,
    isDemoMode,
    runDemoScenario,
    setCurrentPage,
  } = useApp();

  const [activeAssessment, setActiveAssessment] = useState<AssessmentSpec | null>(null);
  const [answers, setAnswers] = useState<number[]>([]);
  const [lastResult, setLastResult] = useState<{
    attempt: AssessmentAttempt;
    spec: AssessmentSpec;
    submittedAnswers: number[];
  } | null>(null);
  const [submitError, setSubmitError] = useState<string | null>(null);

  if (!profile) return null;

  const startQuiz = (spec: AssessmentSpec) => {
    setActiveAssessment(spec);
    setAnswers(new Array(spec.questions.length).fill(-1));
    setLastResult(null);
    setSubmitError(null);
  };

  const selectOption = (qIndex: number, optIndex: number) => {
    setAnswers((prev) => prev.map((v, i) => (i === qIndex ? optIndex : v)));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeAssessment) return;
    if (answers.some((a) => a === -1)) {
      setSubmitError('Please answer every question before submitting for AI evaluation.');
      return;
    }
    setSubmitError(null);
    try {
      const attempt = await submitAssessment(activeAssessment, answers);
      setLastResult({
        attempt,
        spec: activeAssessment,
        submittedAnswers: [...answers],
      });
      setActiveAssessment(null);
    } catch (err) {
      setSubmitError(err instanceof Error ? err.message : 'Failed to evaluate assessment.');
    }
  };

  const handleDemoScenario = async (scenario: 'A' | 'B') => {
    setSubmitError(null);
    try {
      await runDemoScenario(scenario);
    } catch (err) {
      setSubmitError(err instanceof Error ? err.message : 'Unable to execute demo scenario.');
    }
  };

  return (
    <div className="space-y-8">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="font-display text-2xl font-bold text-white">Adaptive Skill Assessments</h2>
          <p className="text-sm text-slate-400">
            Submitting any assessment runs the Progress Evaluation Agent and adapts your roadmap. Thresholds: &lt;
            {profile.adaptiveConfig.recoveryThreshold}% Recovery · &ge;
            {profile.adaptiveConfig.progressionThreshold}% Progression.
          </p>
        </div>
        {isDemoMode && (
          <div className="flex flex-wrap gap-2 shrink-0">
            <button
              type="button"
              disabled={isOrchestrating}
              onClick={() => handleDemoScenario('A')}
              className="px-3.5 py-2 rounded-lg text-xs font-semibold bg-rose-950/60 border border-rose-500/40 text-rose-200 hover:border-rose-400 disabled:opacity-50 whitespace-nowrap"
            >
              Demo Scenario A (40% JS)
            </button>
            <button
              type="button"
              disabled={isOrchestrating}
              onClick={() => handleDemoScenario('B')}
              className="px-3.5 py-2 rounded-lg text-xs font-semibold bg-emerald-950/60 border border-emerald-500/40 text-emerald-200 hover:border-emerald-400 disabled:opacity-50 whitespace-nowrap"
            >
              Demo Scenario B (90% JS)
            </button>
          </div>
        )}
      </div>

      {submitError && !activeAssessment && (
        <div className="p-4 rounded-xl bg-rose-950/70 border border-rose-500/40 text-sm text-rose-200">
          {submitError}
        </div>
      )}

      {/* Evaluation Result View */}
      {lastResult && (
        <section className="rounded-xl sp-card-accent p-6 space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-800/80 pb-4">
            <div>
              <div className="text-xs font-semibold text-sky-400 uppercase tracking-wider">
                Progress Evaluation Agent Report · Mode: {lastResult.attempt.adaptiveMode}
              </div>
              <h3 className="font-display text-xl font-bold text-white mt-1">
                {lastResult.spec.title}
              </h3>
            </div>
            <div className="text-right">
              <div className="font-mono text-3xl font-bold text-white tabular-nums">
                {lastResult.attempt.score}%
              </div>
              <div className="text-xs text-slate-400 tabular-nums">
                {lastResult.attempt.correctCount} / {lastResult.attempt.totalQuestions} correct
              </div>
            </div>
          </div>

          <p className="text-sm text-slate-200 leading-relaxed">
            {lastResult.attempt.evaluationSummary}
          </p>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
            {lastResult.attempt.topicBreakdown.map((t) => (
              <div key={t.topic} className="p-3 rounded-lg sp-inset space-y-1">
                <div className="flex items-center justify-between text-xs">
                  <span className="font-medium text-white">{t.topic}</span>
                  <span
                    className={`font-mono tabular-nums ${
                      t.accuracy < 70 ? 'text-rose-400' : 'text-emerald-400'
                    }`}
                  >
                    {t.accuracy}%
                  </span>
                </div>
                <div className="text-xs text-slate-400 tabular-nums">
                  {t.correct}/{t.total} questions passed
                </div>
              </div>
            ))}
          </div>

          <div className="space-y-3 pt-2 border-t border-slate-800/80">
            <div className="text-xs font-semibold text-slate-300">Answer Review &amp; Explanations</div>
            {lastResult.spec.questions.map((q, idx) => {
              const userAns = lastResult.submittedAnswers[idx];
              const isCorrect = userAns === q.correctIndex;
              return (
                <div key={q.id} className="p-4 rounded-lg sp-inset space-y-1.5 text-sm">
                  <div className="flex items-start justify-between gap-3">
                    <span className="font-medium text-white">
                      {idx + 1}. {q.question}
                    </span>
                    {isCorrect ? (
                      <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                    ) : (
                      <XCircle className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
                    )}
                  </div>
                  <div className="text-xs text-slate-400">
                    Your answer: <span className={isCorrect ? 'text-emerald-300' : 'text-rose-300'}>{q.options[userAns]}</span>
                    {!isCorrect && (
                      <>
                        {' · '}Correct: <span className="text-emerald-300">{q.options[q.correctIndex]}</span>
                      </>
                    )}
                  </div>
                  <div className="text-xs text-slate-300">{q.explanation}</div>
                </div>
              );
            })}
          </div>

          <div className="flex flex-wrap items-center gap-3">
            <button
              type="button"
              onClick={() => setCurrentPage('roadmap')}
              className="px-4 py-2.5 rounded-lg text-xs font-semibold sp-btn-primary flex items-center gap-2 whitespace-nowrap"
            >
              <span>Inspect Updated Roadmap</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
            <button
              type="button"
              onClick={() => setLastResult(null)}
              className="px-4 py-2.5 rounded-lg text-xs font-semibold sp-btn-secondary whitespace-nowrap"
            >
              Back to Assessment Catalog
            </button>
          </div>
        </section>
      )}

      {/* Active Quiz Runner */}
      {activeAssessment && (
        <form onSubmit={handleSubmit} className="rounded-xl sp-card p-6 space-y-6">
          <div className="flex items-center justify-between gap-4 border-b border-slate-800/80 pb-4">
            <div>
              <button
                type="button"
                onClick={() => setActiveAssessment(null)}
                className="text-xs text-slate-400 hover:text-white inline-flex items-center gap-1.5 mb-2"
              >
                <ArrowLeft className="w-3.5 h-3.5" />
                <span>Cancel Assessment</span>
              </button>
              <h3 className="font-display text-xl font-bold text-white">{activeAssessment.title}</h3>
              <p className="text-xs text-slate-400 mt-0.5">
                {activeAssessment.skillName} · {activeAssessment.difficulty} ·{' '}
                {activeAssessment.questions.length} questions
              </p>
            </div>
            <div className="font-mono text-xs text-sky-300 tabular-nums">
              {answers.filter((a) => a !== -1).length} / {activeAssessment.questions.length} answered
            </div>
          </div>

          {submitError && (
            <div className="p-3 rounded-lg bg-rose-950/70 border border-rose-500/40 text-xs text-rose-200">
              {submitError}
            </div>
          )}

          <div className="space-y-6">
            {activeAssessment.questions.map((q, qIdx) => (
              <div key={q.id} className="p-5 rounded-xl sp-inset space-y-3">
                <div className="text-xs text-slate-400">
                  Question {qIdx + 1} · {q.topic} · {q.difficulty}
                </div>
                <div className="text-sm font-medium text-white leading-relaxed">{q.question}</div>
                <div className="grid grid-cols-1 gap-2">
                  {q.options.map((opt, optIdx) => {
                    const selected = answers[qIdx] === optIdx;
                    return (
                      <button
                        key={optIdx}
                        type="button"
                        onClick={() => selectOption(qIdx, optIdx)}
                        className={`text-left px-4 py-3 rounded-lg border text-sm transition-colors ${
                          selected
                            ? 'bg-sky-500/20 border-sky-400 text-white'
                            : 'bg-[#070D1D] border-slate-800 text-slate-300 hover:border-slate-600'
                        }`}
                      >
                        {opt}
                      </button>
                    );
                  })}
                </div>
              </div>
            ))}
          </div>

          <div className="flex justify-end">
            <button
              type="submit"
              disabled={isOrchestrating}
              className="px-6 py-3 rounded-lg text-sm font-semibold sp-btn-primary disabled:opacity-50 flex items-center gap-2 whitespace-nowrap"
            >
              <FileCheck2 className="w-4 h-4" />
              <span>{isOrchestrating ? 'Evaluating with Agent 5...' : 'Submit Assessment'}</span>
            </button>
          </div>
        </form>
      )}

      {/* Assessment Catalog */}
      {!activeAssessment && (
        <section className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {ASSESSMENT_BANK.map((spec) => (
            <div
              key={spec.assessmentId}
              className="rounded-xl sp-card p-6 flex flex-col justify-between gap-4"
            >
              <div className="space-y-2">
                <div className="text-xs text-slate-400">
                  {spec.skillName} · {spec.difficulty} · {spec.questions.length} Questions
                </div>
                <h3 className="font-display text-base font-semibold text-white">{spec.title}</h3>
                <p className="text-xs text-slate-400 leading-relaxed">{spec.description}</p>
              </div>
              <button
                type="button"
                onClick={() => startQuiz(spec)}
                className="w-full py-2.5 px-4 rounded-lg text-xs font-semibold sp-btn-primary flex items-center justify-center gap-2 whitespace-nowrap"
              >
                <Play className="w-3.5 h-3.5" />
                <span>Start Assessment</span>
              </button>
            </div>
          ))}
        </section>
      )}
    </div>
  );
}
