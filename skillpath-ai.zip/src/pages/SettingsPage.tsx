import React, { useEffect, useState } from 'react';
import { Download, RotateCcw, Save, Trash2 } from 'lucide-react';
import { useApp } from '../context/AppContext.tsx';

export function SettingsPage() {
  const {
    profile,
    skills,
    analysis,
    roadmap,
    attempts,
    isDemoMode,
    isLocalSession,
    saveProfileAndSkills,
    resetDemoScenario,
    wipeAuthenticatedAccountData,
    isOrchestrating,
  } = useApp();

  const [recoveryThreshold, setRecoveryThreshold] = useState(50);
  const [progressionThreshold, setProgressionThreshold] = useState(85);
  const [weeklyHours, setWeeklyHours] = useState(12);
  const [message, setMessage] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [confirmWipe, setConfirmWipe] = useState(false);

  useEffect(() => {
    if (profile) {
      setRecoveryThreshold(profile.adaptiveConfig.recoveryThreshold);
      setProgressionThreshold(profile.adaptiveConfig.progressionThreshold);
      setWeeklyHours(profile.learningPreferences.weeklyHours);
    }
  }, [profile]);

  if (!profile) return null;

  const handleSaveSettings = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setMessage(null);

    if (recoveryThreshold >= progressionThreshold) {
      setError('Recovery threshold must be strictly lower than Progression threshold.');
      return;
    }

    const updated = {
      ...profile,
      learningPreferences: {
        ...profile.learningPreferences,
        weeklyHours,
      },
      adaptiveConfig: {
        recoveryThreshold,
        progressionThreshold,
      },
    };

    try {
      await saveProfileAndSkills(updated, skills);
      setMessage('Adaptive engine thresholds and study pace saved.');
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unable to save adaptive configuration.');
    }
  };

  const handleResetDemo = async () => {
    setError(null);
    setMessage(null);
    try {
      await resetDemoScenario();
      setMessage('Alex demo baseline restored.');
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unable to reset demo baseline.');
    }
  };

  const handleWipeWorkspace = async () => {
    setError(null);
    setMessage(null);
    try {
      await wipeAuthenticatedAccountData();
      setConfirmWipe(false);
      setMessage(
        isLocalSession
          ? 'Local workspace reset to clean baseline.'
          : 'Authenticated Firestore workspace reset to defaults.',
      );
    } catch (err) {
      setConfirmWipe(false);
      setError(err instanceof Error ? err.message : 'Unable to reset workspace data.');
    }
  };

  const handleExportJson = () => {
    const payload = {
      exportedAt: new Date().toISOString(),
      mode: isDemoMode ? 'demo_sandbox' : isLocalSession ? 'local_workspace' : 'authenticated_firestore',
      profile,
      skills,
      analysis,
      roadmap,
      attempts,
    };
    const blob = new Blob([JSON.stringify(payload, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `skillpath-ai-${profile.name.toLowerCase().replace(/\s+/g, '-')}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-8 max-w-3xl">
      <div>
        <h2 className="font-display text-2xl font-bold text-white">Adaptive Engine &amp; Workspace Settings</h2>
        <p className="text-sm text-slate-400">
          Configure assessment adaptation thresholds, weekly learning capacity, and workspace data export.
        </p>
      </div>

      {error && (
        <div className="p-4 rounded-xl bg-rose-950/70 border border-rose-500/40 text-sm text-rose-200">
          {error}
        </div>
      )}
      {message && (
        <div className="p-4 rounded-xl bg-emerald-950/60 border border-emerald-500/40 text-sm text-emerald-200">
          {message}
        </div>
      )}

      <form
        onSubmit={handleSaveSettings}
        className="rounded-xl sp-card p-6 space-y-6"
      >
        <h3 className="font-display text-base font-semibold text-white">
          Configurable Adaptive Thresholds
        </h3>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <label className="block space-y-1.5 text-xs">
            <span className="text-slate-300 font-medium">Recovery Mode (&lt; %)</span>
            <input
              type="number"
              min={20}
              max={70}
              value={recoveryThreshold}
              onChange={(e) => setRecoveryThreshold(Number(e.target.value))}
              className="w-full px-3.5 py-2.5 rounded-lg sp-input text-sm font-mono tabular-nums"
            />
            <span className="text-slate-500">Default: 50%</span>
          </label>

          <label className="block space-y-1.5 text-xs">
            <span className="text-slate-300 font-medium">Progression Mode (&ge; %)</span>
            <input
              type="number"
              min={70}
              max={95}
              value={progressionThreshold}
              onChange={(e) => setProgressionThreshold(Number(e.target.value))}
              className="w-full px-3.5 py-2.5 rounded-lg sp-input text-sm font-mono tabular-nums"
            />
            <span className="text-slate-500">Default: 85%</span>
          </label>

          <label className="block space-y-1.5 text-xs">
            <span className="text-slate-300 font-medium">Weekly Study Hours</span>
            <input
              type="number"
              min={1}
              max={80}
              value={weeklyHours}
              onChange={(e) => setWeeklyHours(Number(e.target.value))}
              className="w-full px-3.5 py-2.5 rounded-lg sp-input text-sm font-mono tabular-nums"
            />
            <span className="text-slate-500">Calibrates roadmap duration</span>
          </label>
        </div>

        <button
          type="submit"
          disabled={isOrchestrating}
          className="px-5 py-2.5 rounded-lg text-xs font-semibold sp-btn-primary disabled:opacity-50 flex items-center gap-2 whitespace-nowrap"
        >
          <Save className="w-3.5 h-3.5" />
          <span>{isOrchestrating ? 'Saving...' : 'Save Configuration'}</span>
        </button>
      </form>

      <section className="rounded-xl sp-card p-6 space-y-4">
        <h3 className="font-display text-base font-semibold text-white">Data Portability &amp; Reset</h3>
        <div className="flex flex-wrap gap-3">
          <button
            type="button"
            onClick={handleExportJson}
            className="px-4 py-2.5 rounded-lg text-xs font-semibold sp-btn-secondary flex items-center gap-2 whitespace-nowrap"
          >
            <Download className="w-3.5 h-3.5 text-sky-400" />
            <span>Export Workspace JSON</span>
          </button>

          {isDemoMode ? (
            <button
              type="button"
              disabled={isOrchestrating}
              onClick={handleResetDemo}
              className="px-4 py-2.5 rounded-lg text-xs font-semibold sp-btn-secondary flex items-center gap-2 whitespace-nowrap disabled:opacity-50"
            >
              <RotateCcw className="w-3.5 h-3.5 text-sky-400" />
              <span>Reset Alex Demo Baseline</span>
            </button>
          ) : !confirmWipe ? (
            <button
              type="button"
              onClick={() => setConfirmWipe(true)}
              className="px-4 py-2.5 rounded-lg text-xs font-semibold bg-rose-950/50 border border-rose-500/40 text-rose-200 hover:border-rose-400 transition-colors flex items-center gap-2 whitespace-nowrap"
            >
              <Trash2 className="w-3.5 h-3.5" />
              <span>{isLocalSession ? 'Clear Local Workspace' : 'Reset Cloud Workspace'}</span>
            </button>
          ) : (
            <div className="flex items-center gap-2">
              <button
                type="button"
                disabled={isOrchestrating}
                onClick={handleWipeWorkspace}
                className="px-4 py-2.5 rounded-lg text-xs font-semibold bg-rose-600 hover:bg-rose-500 text-white disabled:opacity-50 whitespace-nowrap"
              >
                Confirm Reset
              </button>
              <button
                type="button"
                onClick={() => setConfirmWipe(false)}
                className="px-3.5 py-2.5 rounded-lg text-xs font-medium sp-btn-secondary whitespace-nowrap"
              >
                Cancel
              </button>
            </div>
          )}
        </div>
      </section>
    </div>
  );
}
