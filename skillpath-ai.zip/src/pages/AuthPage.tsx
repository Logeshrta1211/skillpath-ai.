import React, { useState } from 'react';
import {
  ArrowLeft,
  ArrowRight,
  Bot,
  Compass,
  GitBranch,
  Globe,
  KeyRound,
  Play,
  RefreshCw,
  ShieldCheck,
  Sparkles,
  UserPlus,
} from 'lucide-react';
import { useApp } from '../context/AppContext.tsx';
import { CAREER_CATALOG } from '../shared/catalog.ts';
import type { CareerGoal } from '../shared/types.ts';

export function AuthPage() {
  const {
    signInWithGoogle,
    signInWithGoogleRedirect,
    createLocalLearnerWorkspace,
    resumeLocalLearnerWorkspace,
    hasSavedLocalWorkspace,
    enterDemoMode,
    setCurrentPage,
    orchestratorError,
    authErrorCode,
    clearError,
  } = useApp();

  const [authTab, setAuthTab] = useState<'google' | 'workspace'>('google');
  const [signingIn, setSigningIn] = useState(false);
  const [redirecting, setRedirecting] = useState(false);

  const [learnerName, setLearnerName] = useState('');
  const [learnerEmail, setLearnerEmail] = useState('');
  const [careerGoal, setCareerGoal] = useState<CareerGoal>('Full Stack Developer');
  const [weeklyHours, setWeeklyHours] = useState(12);
  const [formError, setFormError] = useState<string | null>(null);

  const currentHost = typeof window !== 'undefined' ? window.location.hostname : '';

  const handleGoogleSignIn = async () => {
    setSigningIn(true);
    try {
      await signInWithGoogle();
    } catch {
      // handled cleanly in context
    } finally {
      setSigningIn(false);
    }
  };

  const handleGoogleRedirect = async () => {
    setRedirecting(true);
    try {
      await signInWithGoogleRedirect();
    } catch {
      setRedirecting(false);
    }
  };

  const handleCreatePersonalWorkspace = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormError(null);
    if (!learnerName.trim()) {
      setFormError('Please enter your full name.');
      return;
    }
    if (!learnerEmail.trim() || !learnerEmail.includes('@')) {
      setFormError('Please enter a valid email address.');
      return;
    }
    await createLocalLearnerWorkspace({
      name: learnerName.trim(),
      email: learnerEmail.trim(),
      careerGoal,
      weeklyHours,
    });
  };

  return (
    <div className="min-h-screen bg-transparent text-slate-100 flex flex-col justify-between px-6 py-8 lg:px-12">
      {/* Top Bar */}
      <div className="max-w-6xl w-full mx-auto flex items-center justify-between">
        <button
          type="button"
          onClick={() => {
            clearError();
            setCurrentPage('landing');
          }}
          className="inline-flex items-center gap-2 text-xs font-medium text-slate-300 hover:text-sky-300 transition-colors"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Back to SkillPath AI</span>
        </button>

        <div className="font-mono text-xs text-sky-300/90 tracking-wide hidden sm:block">
          Neural Skill Constellation · Six-Agent Adaptive Engine
        </div>
      </div>

      {/* Main Split Command Login */}
      <div className="max-w-6xl w-full mx-auto my-auto py-8 grid grid-cols-1 lg:grid-cols-12 gap-10 items-center">
        {/* Left: Career Architecture Showcase */}
        <div className="lg:col-span-6 space-y-6">
          <div className="space-y-3">
            <div className="text-xs font-mono tracking-wide text-sky-400">
              SkillPath AI Workspace Access
            </div>
            <h1 className="font-display text-3xl sm:text-4xl lg:text-5xl font-bold text-white tracking-tight text-balance leading-[1.1]">
              Map Your Capabilities. Adapt Every Milestone.
            </h1>
            <p className="text-sm sm:text-base text-slate-300 leading-relaxed max-w-xl">
              Enter a spatial neural skill workspace powered by deterministic weighted readiness scoring and six coordinated Gemini agents that evolve with every quiz you submit.
            </p>
          </div>

          <div className="rounded-xl sp-card p-6 space-y-5">
            <div className="flex items-center justify-between border-b border-slate-800/80 pb-3">
              <div>
                <div className="text-xs text-slate-400">Career Intelligence Engine</div>
                <div className="font-display text-base font-semibold text-white">
                  Deterministic Readiness &amp; Adaptive Loops
                </div>
              </div>
              <ShieldCheck className="w-5 h-5 text-sky-400 shrink-0" />
            </div>

            <div className="font-mono text-xs sp-inset rounded-lg p-3.5 text-sky-300 leading-relaxed">
              Readiness = SUM(weight × MIN(current / required, 1)) / SUM(weight) × 100
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs pt-1">
              <div className="space-y-1">
                <div className="flex items-center gap-1.5 text-sky-300 font-semibold">
                  <GitBranch className="w-3.5 h-3.5" />
                  <span>Skill Gap Engine</span>
                </div>
                <p className="text-slate-400 leading-relaxed">
                  Exact 0–4 gap calculation and prerequisite chains.
                </p>
              </div>
              <div className="space-y-1">
                <div className="flex items-center gap-1.5 text-amber-300 font-semibold">
                  <Compass className="w-3.5 h-3.5" />
                  <span>4 Career Tracks</span>
                </div>
                <p className="text-slate-400 leading-relaxed">
                  Full Stack, Frontend, Backend, and Data Analyst.
                </p>
              </div>
              <div className="space-y-1">
                <div className="flex items-center gap-1.5 text-emerald-300 font-semibold">
                  <Bot className="w-3.5 h-3.5" />
                  <span>6 Gemini Agents</span>
                </div>
                <p className="text-slate-400 leading-relaxed">
                  Parallel analysis, roadmap curation, and AI Mentor.
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Right: Authentication & Workspace Launch Card */}
        <div className="lg:col-span-6 space-y-4">
          <div className="rounded-xl sp-card-accent p-6 sm:p-8 space-y-6">
            {/* Access Method Switcher */}
            <div className="grid grid-cols-2 gap-2 p-1 rounded-lg sp-inset">
              <button
                type="button"
                onClick={() => {
                  clearError();
                  setFormError(null);
                  setAuthTab('google');
                }}
                className={`py-2 px-3 rounded-md text-xs font-semibold transition-colors flex items-center justify-center gap-2 ${
                  authTab === 'google'
                    ? 'sp-btn-primary'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                <KeyRound className="w-3.5 h-3.5" />
                <span>Google Cloud Sync</span>
              </button>
              <button
                type="button"
                onClick={() => {
                  clearError();
                  setFormError(null);
                  setAuthTab('workspace');
                }}
                className={`py-2 px-3 rounded-md text-xs font-semibold transition-colors flex items-center justify-center gap-2 ${
                  authTab === 'workspace'
                    ? 'sp-btn-primary'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                <UserPlus className="w-3.5 h-3.5" />
                <span>Personal Workspace</span>
              </button>
            </div>

            {orchestratorError && (
              <div
                role="alert"
                className="p-3.5 rounded-lg bg-rose-950/75 border border-rose-500/40 text-xs text-rose-100 space-y-2"
              >
                <div className="font-semibold text-rose-200">Authentication Notice</div>
                <p className="leading-relaxed text-rose-100/90">{orchestratorError}</p>
                {authErrorCode === 'auth/unauthorized-domain' && (
                  <div className="pt-1 flex flex-wrap items-center gap-2">
                    <span className="font-mono text-[11px] bg-black/40 px-2 py-1 rounded text-sky-300">
                      {currentHost}
                    </span>
                    <button
                      type="button"
                      onClick={() => setAuthTab('workspace')}
                      className="text-sky-300 underline font-semibold hover:text-sky-200"
                    >
                      Use Personal Workspace instead
                    </button>
                  </div>
                )}
              </div>
            )}

            {authTab === 'google' ? (
              <div className="space-y-5">
                <div className="space-y-1.5">
                  <h2 className="font-display text-xl font-bold text-white">
                    Sign In with Google
                  </h2>
                  <p className="text-xs text-slate-400 leading-relaxed">
                    Connect your Google account to persist profiles, skills, roadmaps, and assessments in Cloud Firestore.
                  </p>
                </div>

                <div className="space-y-3">
                  <button
                    type="button"
                    disabled={signingIn || redirecting}
                    onClick={handleGoogleSignIn}
                    className="w-full py-3 px-4 rounded-lg text-sm font-semibold sp-btn-primary flex items-center justify-center gap-2.5 disabled:opacity-60"
                  >
                    <KeyRound className="w-4 h-4" />
                    <span>{signingIn ? 'Opening Google Sign-In...' : 'Continue with Google'}</span>
                  </button>

                  <button
                    type="button"
                    disabled={signingIn || redirecting}
                    onClick={handleGoogleRedirect}
                    className="w-full py-2.5 px-4 rounded-lg text-xs font-medium sp-btn-secondary flex items-center justify-center gap-2 disabled:opacity-60"
                  >
                    <Globe className="w-3.5 h-3.5 text-sky-400" />
                    <span>
                      {redirecting
                        ? 'Redirecting to Google...'
                        : 'Popup blocked? Continue via Google Redirect'}
                    </span>
                  </button>
                </div>

                <div className="pt-3 border-t border-slate-800/90 flex items-center justify-between gap-3 text-xs text-slate-400">
                  <span>Prefer instant access without domain setup?</span>
                  <button
                    type="button"
                    onClick={() => setAuthTab('workspace')}
                    className="text-sky-300 hover:text-sky-200 font-semibold whitespace-nowrap"
                  >
                    Create Local Workspace
                  </button>
                </div>
              </div>
            ) : (
              <form onSubmit={handleCreatePersonalWorkspace} className="space-y-4">
                <div className="space-y-1">
                  <h2 className="font-display text-xl font-bold text-white">
                    Create Your Learner Workspace
                  </h2>
                  <p className="text-xs text-slate-400 leading-relaxed">
                    Launch an instant persistent personal workspace with full access to all 6 live Gemini AI agents.
                  </p>
                </div>

                {formError && (
                  <div className="p-3 rounded-lg bg-rose-950/70 border border-rose-500/40 text-xs text-rose-200">
                    {formError}
                  </div>
                )}

                {hasSavedLocalWorkspace && (
                  <button
                    type="button"
                    onClick={() => resumeLocalLearnerWorkspace()}
                    className="w-full py-2.5 px-4 rounded-lg text-xs font-semibold bg-sky-950/70 border border-sky-400/40 hover:border-sky-300 text-sky-200 flex items-center justify-center gap-2"
                  >
                    <RefreshCw className="w-3.5 h-3.5" />
                    <span>Resume Saved Personal Workspace</span>
                  </button>
                )}

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <label className="block space-y-1 text-xs">
                    <span className="text-slate-300 font-medium">Full Name</span>
                    <input
                      type="text"
                      required
                      placeholder="e.g., Priya Nair"
                      value={learnerName}
                      onChange={(e) => setLearnerName(e.target.value)}
                      className="w-full px-3 py-2.5 rounded-lg sp-input text-sm"
                    />
                  </label>
                  <label className="block space-y-1 text-xs">
                    <span className="text-slate-300 font-medium">Email Address</span>
                    <input
                      type="email"
                      required
                      placeholder="priya@university.edu"
                      value={learnerEmail}
                      onChange={(e) => setLearnerEmail(e.target.value)}
                      className="w-full px-3 py-2.5 rounded-lg sp-input text-sm"
                    />
                  </label>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <label className="block space-y-1 text-xs">
                    <span className="text-slate-300 font-medium">Target Career Track</span>
                    <select
                      value={careerGoal}
                      onChange={(e) => setCareerGoal(e.target.value as CareerGoal)}
                      className="w-full px-3 py-2.5 rounded-lg sp-input text-sm"
                    >
                      {CAREER_CATALOG.map((c) => (
                        <option key={c.careerId} value={c.title}>
                          {c.title}
                        </option>
                      ))}
                    </select>
                  </label>
                  <label className="block space-y-1 text-xs">
                    <span className="text-slate-300 font-medium">Weekly Study Hours</span>
                    <input
                      type="number"
                      min={1}
                      max={80}
                      value={weeklyHours}
                      onChange={(e) => setWeeklyHours(Number(e.target.value) || 10)}
                      className="w-full px-3 py-2.5 rounded-lg sp-input text-sm font-mono"
                    />
                  </label>
                </div>

                <button
                  type="submit"
                  className="w-full py-3 px-4 rounded-lg text-sm font-semibold sp-btn-primary flex items-center justify-center gap-2"
                >
                  <Sparkles className="w-4 h-4" />
                  <span>Launch Personal SkillPath Workspace</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </form>
            )}
          </div>

          {/* Demo Sandbox Card */}
          <div className="rounded-xl sp-card p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div className="space-y-1">
              <div className="text-sm font-semibold text-white">Interactive Demo Sandbox (Alex Rivera)</div>
              <p className="text-xs text-slate-400 leading-relaxed">
                Preloaded sample learner to test 40% Recovery, 90% Progression, and Data Analyst switching.
              </p>
            </div>
            <button
              type="button"
              onClick={() => enterDemoMode()}
              className="px-4 py-2.5 rounded-lg text-xs font-semibold sp-btn-secondary flex items-center justify-center gap-2 whitespace-nowrap shrink-0"
            >
              <Play className="w-3.5 h-3.5 text-sky-400" />
              <span>Enter Demo</span>
            </button>
          </div>
        </div>
      </div>

      {/* Footer Note */}
      <div className="max-w-6xl w-full mx-auto text-xs text-slate-500 flex flex-wrap items-center justify-between gap-2">
        <span>SkillPath AI · Multi-Agent Adaptive Career Platform</span>
        <span>Cloud Firestore Owner Isolation · Gemini Multi-Agent Runtime</span>
      </div>
    </div>
  );
}
