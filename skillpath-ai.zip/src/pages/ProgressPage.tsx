import React from 'react';
import {
  Area,
  AreaChart,
  CartesianGrid,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from 'recharts';
import { useApp } from '../context/AppContext.tsx';
import { PROFICIENCY_LABELS } from '../shared/types.ts';

export function ProgressPage() {
  const { skills, attempts, progress, analysis } = useApp();

  const readinessTimeline = [...progress]
    .reverse()
    .map((p, idx) => ({
      step: `#${idx + 1} ${p.skillName}`,
      readiness: p.readinessScore,
    }));

  return (
    <div className="space-y-8">
      <div>
        <h2 className="font-display text-2xl font-bold text-white">Progress Tracking &amp; Skill Evidence</h2>
        <p className="text-sm text-slate-400">
          Tracks verified assessment attempts, topic weaknesses, and longitudinal readiness progression. Mastery requires multi-quiz evidence.
        </p>
      </div>

      {/* Readiness Progression Chart */}
      <section className="rounded-xl sp-card p-6 space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="font-display text-base font-semibold text-white">
              Readiness Score Trajectory
            </h3>
            <p className="text-xs text-slate-400 tabular-nums">
              Current Career Readiness: {analysis?.readinessScore ?? 0}%
            </p>
          </div>
        </div>

        {readinessTimeline.length > 0 ? (
          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={readinessTimeline} margin={{ top: 10, right: 16, left: -16, bottom: 10 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#16223B" />
                <XAxis dataKey="step" tick={{ fill: '#94A3B8', fontSize: 11 }} />
                <YAxis domain={[0, 100]} tick={{ fill: '#94A3B8', fontSize: 11 }} />
                <Tooltip
                  contentStyle={{
                    backgroundColor: '#030712',
                    borderColor: '#1E293B',
                    borderRadius: '8px',
                    fontSize: '12px',
                    color: '#F1F5F9',
                  }}
                />
                <Area
                  type="monotone"
                  dataKey="readiness"
                  stroke="#38BDF8"
                  fill="#38BDF8"
                  fillOpacity={0.18}
                  strokeWidth={2.5}
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        ) : (
          <div className="text-sm text-slate-400 py-8 text-center">
            Progress milestones will chart here as you update skills, finish roadmap stages, or submit assessments.
          </div>
        )}
      </section>

      {/* Skill Evidence Table */}
      <section className="rounded-xl sp-card overflow-hidden">
        <div className="px-6 py-4 border-b border-slate-800/80">
          <h3 className="font-display text-base font-semibold text-white">
            Skill Evidence &amp; Mastery Ledger
          </h3>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-sm">
            <thead>
              <tr className="border-b border-slate-800 text-xs text-slate-400 bg-[#030712]/90">
                <th className="py-3 px-6 font-medium">Skill</th>
                <th className="py-3 px-4 font-medium">Proficiency</th>
                <th className="py-3 px-4 font-medium text-right">Evidence Count</th>
                <th className="py-3 px-4 font-medium">Mastery Status</th>
                <th className="py-3 px-6 font-medium">Flagged Weak Topics</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/80">
              {skills.map((s) => (
                <tr key={s.skillId} className="hover:bg-sky-500/5 transition-colors">
                  <td className="py-3 px-6 font-medium text-white">{s.skillName}</td>
                  <td className="py-3 px-4 font-mono text-xs text-slate-200 tabular-nums">
                    {s.proficiency}/4 · {PROFICIENCY_LABELS[s.proficiency]}
                  </td>
                  <td className="py-3 px-4 text-right font-mono text-xs text-sky-300 tabular-nums">
                    {s.evidenceCount}
                  </td>
                  <td className="py-3 px-4 text-xs font-medium">
                    {s.mastered ? (
                      <span className="text-emerald-400">Verified Mastered</span>
                    ) : s.evidenceCount === 1 ? (
                      <span className="text-amber-300">In Progress (needs 2+ assessments)</span>
                    ) : (
                      <span className="text-slate-400">Developing</span>
                    )}
                  </td>
                  <td className="py-3 px-6 text-xs text-slate-300">
                    {s.weakTopics.length > 0 ? s.weakTopics.join(', ') : 'None flagged'}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>

      {/* Assessment Attempt History */}
      <section className="rounded-xl sp-card overflow-hidden">
        <div className="px-6 py-4 border-b border-slate-800/80">
          <h3 className="font-display text-base font-semibold text-white">Assessment Attempts</h3>
        </div>
        {attempts.length === 0 ? (
          <div className="p-6 text-sm text-slate-400">No assessment attempts recorded yet.</div>
        ) : (
          <div className="divide-y divide-slate-800/80">
            {attempts.map((att, idx) => (
              <div key={att.id ?? idx} className="p-5 space-y-1.5">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <div className="text-sm font-semibold text-white">
                    {att.skillName} · {att.adaptiveMode.toUpperCase()} MODE
                  </div>
                  <div className="font-mono text-sm font-bold text-sky-400 tabular-nums">
                    {att.score}% ({att.correctCount}/{att.totalQuestions})
                  </div>
                </div>
                <p className="text-xs text-slate-300 leading-relaxed">{att.evaluationSummary}</p>
                {att.weakTopics.length > 0 && (
                  <div className="text-xs text-rose-300">
                    Weak topics identified: {att.weakTopics.join(' · ')}
                  </div>
                )}
              </div>
            ))}
          </div>
        )}
      </section>
    </div>
  );
}
