import React, { useState } from 'react';
import { Bot, Loader2, Send, Trash2, User } from 'lucide-react';
import { useApp } from '../context/AppContext.tsx';

const STARTER_PROMPTS = [
  'What should I learn next?',
  'Why is JavaScript important?',
  'How can I become a Full Stack Developer?',
  'Why did my roadmap change?',
  'What project should I build?',
];

export function MentorPage() {
  const {
    profile,
    analysis,
    roadmap,
    mentorMessages,
    askMentor,
    clearMentorChat,
    isOrchestrating,
  } = useApp();

  const [input, setInput] = useState('');
  const [mentorError, setMentorError] = useState<string | null>(null);

  if (!profile || !analysis) return null;

  const handleSend = async (text: string) => {
    const trimmed = text.trim();
    if (!trimmed || isOrchestrating) return;
    setMentorError(null);
    setInput('');
    try {
      await askMentor(trimmed);
    } catch (err) {
      setMentorError(err instanceof Error ? err.message : 'Unable to reach AI Mentor.');
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    await handleSend(input);
  };

  const handleClear = async () => {
    setMentorError(null);
    try {
      await clearMentorChat();
    } catch (err) {
      setMentorError(err instanceof Error ? err.message : 'Unable to clear conversation history.');
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="font-display text-2xl font-bold text-white">AI Career Mentor</h2>
          <p className="text-sm text-slate-400">
            Grounded in {profile.name}’s real readiness ({analysis.readinessScore}%), active gaps, roadmap mode ({roadmap?.adaptiveMode ?? 'baseline'}), and assessment history.
          </p>
        </div>
        {mentorMessages.length > 0 && (
          <button
            type="button"
            onClick={handleClear}
            className="px-3.5 py-2 rounded-lg text-xs font-medium sp-btn-secondary hover:border-rose-400 flex items-center gap-1.5 whitespace-nowrap shrink-0"
          >
            <Trash2 className="w-3.5 h-3.5 text-rose-400" />
            <span>Clear Thread</span>
          </button>
        )}
      </div>

      {mentorError && (
        <div className="p-3.5 rounded-xl bg-rose-950/70 border border-rose-500/40 text-xs text-rose-200">
          {mentorError}
        </div>
      )}

      {/* Quick Prompts */}
      <div className="flex flex-wrap gap-2">
        {STARTER_PROMPTS.map((prompt) => (
          <button
            key={prompt}
            type="button"
            disabled={isOrchestrating}
            onClick={() => handleSend(prompt)}
            className="px-3 py-1.5 rounded-lg text-xs font-medium sp-btn-secondary disabled:opacity-50"
          >
            {prompt}
          </button>
        ))}
      </div>

      {/* Chat Thread */}
      <section className="rounded-xl sp-card flex flex-col min-h-[420px]">
        <div className="flex-1 p-6 space-y-4 overflow-y-auto max-h-[540px]">
          {mentorMessages.length === 0 ? (
            <div className="py-12 text-center space-y-2">
              <Bot className="w-8 h-8 text-sky-400 mx-auto" />
              <div className="font-display text-base font-semibold text-white">
                Ask Your Context-Aware AI Mentor
              </div>
              <p className="text-xs text-slate-400 max-w-md mx-auto leading-relaxed">
                Ask about your next roadmap stage, why an adaptation occurred, how to close priority gaps, or what portfolio project fits your current proficiency.
              </p>
            </div>
          ) : (
            mentorMessages.map((msg, idx) => (
              <div
                key={msg.id ?? idx}
                className={`flex items-start gap-3 ${
                  msg.role === 'user' ? 'justify-end' : 'justify-start'
                }`}
              >
                {msg.role === 'mentor' && (
                  <div className="w-8 h-8 rounded-lg bg-sky-500/15 border border-sky-400/35 flex items-center justify-center shrink-0">
                    <Bot className="w-4 h-4 text-sky-400" />
                  </div>
                )}
                <div
                  className={`max-w-2xl rounded-xl p-4 text-sm leading-relaxed whitespace-pre-wrap ${
                    msg.role === 'user'
                      ? 'bg-sky-600/20 border border-sky-400/40 text-white'
                      : 'sp-inset text-slate-200'
                  }`}
                >
                  {msg.content}
                </div>
                {msg.role === 'user' && (
                  <div className="w-8 h-8 rounded-lg bg-slate-800 border border-slate-700 flex items-center justify-center shrink-0">
                    <User className="w-4 h-4 text-slate-300" />
                  </div>
                )}
              </div>
            ))
          )}
          {isOrchestrating && (
            <div className="flex items-center gap-3 text-xs text-sky-300">
              <Loader2 className="w-4 h-4 animate-spin" />
              <span>AI Mentor Agent is synthesizing your profile, gaps, resources, and assessment context...</span>
            </div>
          )}
        </div>

        <form onSubmit={handleSubmit} className="p-4 border-t border-slate-800/80 flex gap-3">
          <input
            type="text"
            placeholder="Ask a career, skill gap, or roadmap question..."
            value={input}
            onChange={(e) => setInput(e.target.value)}
            disabled={isOrchestrating}
            className="flex-1 px-4 py-2.5 rounded-lg sp-input text-sm"
          />
          <button
            type="submit"
            disabled={isOrchestrating || !input.trim()}
            className="px-5 py-2.5 rounded-lg text-xs font-semibold sp-btn-primary disabled:opacity-50 flex items-center gap-2 whitespace-nowrap"
          >
            <Send className="w-3.5 h-3.5" />
            <span>Send</span>
          </button>
        </form>
      </section>
    </div>
  );
}
