import React from 'react';
import { RefreshCw } from 'lucide-react';
import { useApp } from '../context/AppContext.tsx';
import { PROFICIENCY_LABELS } from '../shared/types.ts';

export function SkillAnalysisPage() {
  const { profile, analysis, refreshSkillGapOnly, isOrchestrating, setCurrentPage } = useApp();

  if (!profile || !analysis) return null;

  const allItems = [
    ...analysis.prioritySkills,
    ...analysis.strongSkills,
  ];

  return (
    <div className="space-y-8">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="font-display text-2xl font-bold text-white">Deterministic Skill Gap Analysis</h2>
          <p className="text-sm text-slate-400">
            Target Role: {profile.careerGoal} · Deterministic score calculated prior to AI explanation
          </p>
        </div>
        <button
          type="button"
          disabled={isOrchestrating}
          onClick={() => refreshSkillGapOnly()}
          className="px-4 py-2.5 rounded-lg text-xs font-semibold sp-btn-primary disabled:opacity-50 flex items-center gap-2 whitespace-nowrap shrink-0"
        >
          <RefreshCw className={`w-3.5 h-3.5 ${isOrchestrating ? 'animate-spin' : ''}`} />
          <span>{isOrchestrating ? 'Re-Evaluating...' : 'Refresh Gap Analysis'}</span>
        </button>
      </div>

      {/* Deterministic Formula Banner */}
      <section className="rounded-xl sp-card-accent p-6 grid grid-cols-1 lg:grid-cols-12 gap-6 items-center">
        <div className="lg:col-span-3 space-y-1">
          <div className="text-xs text-slate-400">Career Readiness</div>
          <div className="font-mono text-4xl font-bold text-sky-400 tabular-nums">
            {analysis.readinessScore}%
          </div>
          <div className="text-xs text-slate-400 tabular-nums">
            {analysis.strongSkills.length} strong · {analysis.weakSkills.length} weak · {analysis.missingSkills.length} missing
          </div>
        </div>
        <div className="lg:col-span-9 space-y-2">
          <div className="text-xs font-medium text-slate-300">Deterministic Scoring Formula</div>
          <div className="font-mono text-xs sp-inset rounded-lg p-3.5 text-sky-300">
            Readiness = SUM(weight × MIN(current_proficiency / required_proficiency, 1)) / SUM(weight) × 100
          </div>
          <p className="text-xs text-slate-400">
            AI agents never fabricate readiness percentages; they explain each gap and prerequisite chain computed above.
          </p>
        </div>
      </section>

      {/* Classification Summary Columns */}
      <section className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="rounded-xl sp-card p-5 space-y-3">
          <div className="flex items-center justify-between">
            <h3 className="font-display text-sm font-semibold text-emerald-400">Strong Skills</h3>
            <span className="font-mono text-xs text-slate-400 tabular-nums">{analysis.strongSkills.length}</span>
          </div>
          {analysis.strongSkills.length === 0 ? (
            <p className="text-xs text-slate-400">No skills currently meet the full target threshold.</p>
          ) : (
            <ul className="space-y-2 text-sm">
              {analysis.strongSkills.map((s) => (
                <li key={s.skillId} className="flex items-center justify-between">
                  <span className="text-slate-200">{s.skillName}</span>
                  <span className="font-mono text-xs text-emerald-300 tabular-nums">
                    {s.currentProficiency}/{s.requiredProficiency}
                  </span>
                </li>
              ))}
            </ul>
          )}
        </div>

        <div className="rounded-xl sp-card p-5 space-y-3">
          <div className="flex items-center justify-between">
            <h3 className="font-display text-sm font-semibold text-amber-400">Weak Skills</h3>
            <span className="font-mono text-xs text-slate-400 tabular-nums">{analysis.weakSkills.length}</span>
          </div>
          {analysis.weakSkills.length === 0 ? (
            <p className="text-xs text-slate-400">No partially learned skills below target.</p>
          ) : (
            <ul className="space-y-2 text-sm">
              {analysis.weakSkills.map((s) => (
                <li key={s.skillId} className="flex items-center justify-between">
                  <span className="text-slate-200">{s.skillName}</span>
                  <span className="font-mono text-xs text-amber-300 tabular-nums">
                    {s.currentProficiency}/{s.requiredProficiency}
                  </span>
                </li>
              ))}
            </ul>
          )}
        </div>

        <div className="rounded-xl sp-card p-5 space-y-3">
          <div className="flex items-center justify-between">
            <h3 className="font-display text-sm font-semibold text-rose-400">Missing Skills</h3>
            <span className="font-mono text-xs text-slate-400 tabular-nums">{analysis.missingSkills.length}</span>
          </div>
          {analysis.missingSkills.length === 0 ? (
            <p className="text-xs text-slate-400">Zero missing skills for this role.</p>
          ) : (
            <ul className="space-y-2 text-sm">
              {analysis.missingSkills.map((s) => (
                <li key={s.skillId} className="flex items-center justify-between">
                  <span className="text-slate-200">{s.skillName}</span>
                  <span className="font-mono text-xs text-rose-300 tabular-nums">
                    0/{s.requiredProficiency}
                  </span>
                </li>
              ))}
            </ul>
          )}
        </div>
      </section>

      {/* Detailed Gap Table */}
      <section className="rounded-xl sp-card overflow-hidden">
        <div className="px-6 py-4 border-b border-slate-800/80 flex items-center justify-between">
          <h3 className="font-display text-base font-semibold text-white">
            Skill-by-Skill Gap Matrix &amp; Agent Explanations
          </h3>
          <button
            type="button"
            onClick={() => setCurrentPage('roadmap')}
            className="text-xs font-medium text-sky-400 hover:text-sky-300 whitespace-nowrap"
          >
            Open Personalized Roadmap
          </button>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-sm">
            <thead>
              <tr className="border-b border-slate-800 text-xs text-slate-400 bg-[#030712]/90">
                <th className="py-3 px-6 font-medium">Skill</th>
                <th className="py-3 px-4 font-medium">Status</th>
                <th className="py-3 px-4 font-medium text-right">Current</th>
                <th className="py-3 px-4 font-medium text-right">Required</th>
                <th className="py-3 px-4 font-medium text-right">Weight</th>
                <th className="py-3 px-6 font-medium">Gap &amp; Prerequisite Explanation</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/80">
              {allItems.map((item) => (
                <tr key={item.skillId} className="hover:bg-sky-500/5 transition-colors">
                  <td className="py-3.5 px-6 font-medium text-white whitespace-nowrap">
                    {item.skillName}
                    <div className="text-xs text-slate-400 font-normal">{item.category}</div>
                  </td>
                  <td className="py-3.5 px-4 whitespace-nowrap text-xs font-semibold">
                    {item.status === 'strong' && <span className="text-emerald-400">Strong</span>}
                    {item.status === 'weak' && <span className="text-amber-400">Weak</span>}
                    {item.status === 'missing' && <span className="text-rose-400">Missing</span>}
                  </td>
                  <td className="py-3.5 px-4 text-right font-mono text-xs text-slate-200 tabular-nums whitespace-nowrap">
                    {item.currentProficiency} · {PROFICIENCY_LABELS[item.currentProficiency]}
                  </td>
                  <td className="py-3.5 px-4 text-right font-mono text-xs text-slate-300 tabular-nums whitespace-nowrap">
                    {item.requiredProficiency} · {PROFICIENCY_LABELS[item.requiredProficiency]}
                  </td>
                  <td className="py-3.5 px-4 text-right font-mono text-xs text-slate-300 tabular-nums">
                    {item.weight.toFixed(1)}x
                  </td>
                  <td className="py-3.5 px-6 text-xs text-slate-300 leading-relaxed max-w-md">
                    {item.explanation}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>
    </div>
  );
}
