import React, { useEffect, useState } from 'react';
import { Plus, Save, Trash2 } from 'lucide-react';
import { useApp } from '../context/AppContext.tsx';
import { CAREER_CATALOG, SKILLS_CATALOG } from '../shared/catalog.ts';
import type { CareerGoal, LearnerProfile, ProficiencyLevel, ProjectItem, UserSkill } from '../shared/types.ts';
import { PROFICIENCY_LABELS } from '../shared/types.ts';

export function ProfilePage() {
  const { profile, skills, saveProfileAndSkills, isOrchestrating, profileInsight } = useApp();

  const [form, setForm] = useState<LearnerProfile | null>(profile);
  const [skillDraft, setSkillDraft] = useState<UserSkill[]>([]);
  const [newCert, setNewCert] = useState('');
  const [newProjTitle, setNewProjTitle] = useState('');
  const [newProjDesc, setNewProjDesc] = useState('');
  const [newProjStack, setNewProjStack] = useState('');
  const [validationError, setValidationError] = useState<string | null>(null);
  const [savedNotice, setSavedNotice] = useState<string | null>(null);

  useEffect(() => {
    if (profile) {
      setForm(structuredClone(profile));
    }
    const mergedSkills: UserSkill[] = SKILLS_CATALOG.map((cat) => {
      const existing = skills.find((s) => s.skillId === cat.skillId);
      return (
        existing ?? {
          userId: profile?.userId ?? 'unknown',
          skillId: cat.skillId,
          skillName: cat.skillName,
          category: cat.category,
          proficiency: 0,
          evidenceCount: 0,
          weakTopics: [],
          mastered: false,
        }
      );
    });
    setSkillDraft(mergedSkills);
  }, [profile, skills]);

  if (!form) return null;

  const handleAddCert = () => {
    const trimmed = newCert.trim();
    if (!trimmed) return;
    setForm({ ...form, certifications: [...form.certifications, trimmed] });
    setNewCert('');
  };

  const handleRemoveCert = (index: number) => {
    setForm({
      ...form,
      certifications: form.certifications.filter((_, i) => i !== index),
    });
  };

  const handleAddProject = () => {
    if (!newProjTitle.trim()) return;
    const item: ProjectItem = {
      id: `proj_${Date.now()}`,
      title: newProjTitle.trim(),
      description: newProjDesc.trim() || 'Practical portfolio project',
      techStack: newProjStack
        .split(',')
        .map((s) => s.trim())
        .filter(Boolean),
    };
    setForm({ ...form, projects: [...form.projects, item] });
    setNewProjTitle('');
    setNewProjDesc('');
    setNewProjStack('');
  };

  const handleRemoveProject = (id: string) => {
    setForm({ ...form, projects: form.projects.filter((p) => p.id !== id) });
  };

  const handleSkillLevelChange = (skillId: string, level: ProficiencyLevel) => {
    setSkillDraft((prev) =>
      prev.map((s) => (s.skillId === skillId ? { ...s, proficiency: level } : s)),
    );
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setValidationError(null);
    setSavedNotice(null);

    if (!form.name.trim()) {
      setValidationError('Learner name is required.');
      return;
    }
    if (!form.email.trim() || !form.email.includes('@')) {
      setValidationError('A valid email address is required.');
      return;
    }
    if (form.learningPreferences.weeklyHours < 1 || form.learningPreferences.weeklyHours > 80) {
      setValidationError('Weekly study hours must be between 1 and 80.');
      return;
    }

    try {
      await saveProfileAndSkills(form, skillDraft);
      setSavedNotice('Profile saved and multi-agent roadmap updated.');
    } catch (err) {
      setValidationError(err instanceof Error ? err.message : 'Unable to save profile.');
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-8">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="font-display text-2xl font-bold text-white">Learner Profile &amp; Skill Matrix</h2>
          <p className="text-sm text-slate-400">
            Saving updates triggers Profile Analysis, Skill Gap, Career Matching, and Roadmap Recommendation agents.
          </p>
        </div>
        <button
          type="submit"
          disabled={isOrchestrating}
          className="px-5 py-2.5 rounded-lg text-sm font-semibold sp-btn-primary disabled:opacity-50 flex items-center gap-2 whitespace-nowrap shrink-0"
        >
          <Save className="w-4 h-4" />
          <span>{isOrchestrating ? 'Saving & Analyzing...' : 'Save Profile & Re-Analyze'}</span>
        </button>
      </div>

      {validationError && (
        <div className="p-4 rounded-xl bg-rose-950/70 border border-rose-500/40 text-sm text-rose-200">
          {validationError}
        </div>
      )}
      {savedNotice && (
        <div className="p-4 rounded-xl bg-emerald-950/60 border border-emerald-500/40 text-sm text-emerald-200">
          {savedNotice}
        </div>
      )}

      {profileInsight && (
        <section className="rounded-xl sp-card-accent p-6 space-y-3">
          <div className="text-xs font-medium text-sky-400">Profile Analysis Agent Insight</div>
          <div className="font-display text-lg font-semibold text-white">{profileInsight.headline}</div>
          <p className="text-sm text-slate-300 leading-relaxed">{profileInsight.backgroundSummary}</p>
          <div className="text-xs text-slate-400">
            <strong className="text-slate-200">Recommended Study Strategy:</strong> {profileInsight.learningStrategy}
          </div>
        </section>
      )}

      {/* Academic & Career Info */}
      <section className="rounded-xl sp-card p-6 space-y-5">
        <h3 className="font-display text-base font-semibold text-white">Academic &amp; Career Identity</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          <label className="block space-y-1.5 text-xs">
            <span className="text-slate-300 font-medium">Full Name</span>
            <input
              type="text"
              required
              value={form.name}
              onChange={(e) => setForm({ ...form, name: e.target.value })}
              className="w-full px-3.5 py-2.5 rounded-lg sp-input text-sm"
            />
          </label>
          <label className="block space-y-1.5 text-xs">
            <span className="text-slate-300 font-medium">Email</span>
            <input
              type="email"
              required
              value={form.email}
              onChange={(e) => setForm({ ...form, email: e.target.value })}
              className="w-full px-3.5 py-2.5 rounded-lg sp-input text-sm"
            />
          </label>
          <label className="block space-y-1.5 text-xs">
            <span className="text-slate-300 font-medium">Target Career Goal</span>
            <select
              value={form.careerGoal}
              onChange={(e) => setForm({ ...form, careerGoal: e.target.value as CareerGoal })}
              className="w-full px-3.5 py-2.5 rounded-lg sp-input text-sm"
            >
              {CAREER_CATALOG.map((c) => (
                <option key={c.careerId} value={c.title}>
                  {c.title}
                </option>
              ))}
            </select>
          </label>
          <label className="block space-y-1.5 text-xs">
            <span className="text-slate-300 font-medium">Education / Degree</span>
            <input
              type="text"
              value={form.education}
              onChange={(e) => setForm({ ...form, education: e.target.value })}
              className="w-full px-3.5 py-2.5 rounded-lg sp-input text-sm"
            />
          </label>
          <label className="block space-y-1.5 text-xs">
            <span className="text-slate-300 font-medium">College / University</span>
            <input
              type="text"
              value={form.college}
              onChange={(e) => setForm({ ...form, college: e.target.value })}
              className="w-full px-3.5 py-2.5 rounded-lg sp-input text-sm"
            />
          </label>
          <label className="block space-y-1.5 text-xs">
            <span className="text-slate-300 font-medium">Department</span>
            <input
              type="text"
              value={form.department}
              onChange={(e) => setForm({ ...form, department: e.target.value })}
              className="w-full px-3.5 py-2.5 rounded-lg sp-input text-sm"
            />
          </label>
          <label className="block space-y-1.5 text-xs">
            <span className="text-slate-300 font-medium">Year of Study</span>
            <input
              type="text"
              value={form.yearOfStudy}
              onChange={(e) => setForm({ ...form, yearOfStudy: e.target.value })}
              className="w-full px-3.5 py-2.5 rounded-lg sp-input text-sm"
            />
          </label>
          <label className="block space-y-1.5 text-xs">
            <span className="text-slate-300 font-medium">Available Weekly Hours</span>
            <input
              type="number"
              min={1}
              max={80}
              value={form.learningPreferences.weeklyHours}
              onChange={(e) =>
                setForm({
                  ...form,
                  learningPreferences: {
                    ...form.learningPreferences,
                    weeklyHours: Number(e.target.value) || 10,
                  },
                })
              }
              className="w-full px-3.5 py-2.5 rounded-lg sp-input text-sm font-mono tabular-nums"
            />
          </label>
          <label className="block space-y-1.5 text-xs">
            <span className="text-slate-300 font-medium">Learning Preference</span>
            <select
              value={form.learningPreferences.learningStyle || 'Hands-on Projects & Assessments'}
              onChange={(e) =>
                setForm({
                  ...form,
                  learningPreferences: {
                    ...form.learningPreferences,
                    learningStyle: e.target.value,
                  },
                })
              }
              className="w-full px-3.5 py-2.5 rounded-lg sp-input text-sm"
            >
              <option value="Hands-on Projects & Assessments">Hands-on Projects &amp; Assessments</option>
              <option value="Hands-on Projects & Interactive Quizzes">Hands-on Projects &amp; Quizzes</option>
              <option value="Official Documentation & Deep Theory">Official Docs &amp; Deep Theory</option>
              <option value="Guided Practice Drills">Guided Practice Drills</option>
            </select>
          </label>
        </div>
      </section>

      {/* Skill Matrix 0-4 */}
      <section className="rounded-xl sp-card p-6 space-y-4">
        <div>
          <h3 className="font-display text-base font-semibold text-white">Skill Proficiency Matrix (0–4 Scale)</h3>
          <p className="text-xs text-slate-400">
            0 = No knowledge · 1 = Beginner · 2 = Basic · 3 = Intermediate · 4 = Advanced
          </p>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {skillDraft.map((skill) => (
            <div
              key={skill.skillId}
              className="p-4 rounded-lg sp-inset space-y-2"
            >
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium text-white">{skill.skillName}</span>
                <span className="text-xs text-slate-400">{skill.category}</span>
              </div>
              <select
                aria-label={`${skill.skillName} proficiency`}
                value={skill.proficiency}
                onChange={(e) =>
                  handleSkillLevelChange(skill.skillId, Number(e.target.value) as ProficiencyLevel)
                }
                className="w-full px-3 py-2 rounded-md sp-input text-xs text-slate-100"
              >
                {([0, 1, 2, 3, 4] as ProficiencyLevel[]).map((lvl) => (
                  <option key={lvl} value={lvl}>
                    {lvl} — {PROFICIENCY_LABELS[lvl]}
                  </option>
                ))}
              </select>
            </div>
          ))}
        </div>
      </section>

      {/* Certifications & Projects */}
      <section className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="rounded-xl sp-card p-6 space-y-4">
          <h3 className="font-display text-base font-semibold text-white">Certifications</h3>
          <div className="flex gap-2">
            <input
              type="text"
              placeholder="Add certification name..."
              value={newCert}
              onChange={(e) => setNewCert(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter') {
                  e.preventDefault();
                  handleAddCert();
                }
              }}
              className="flex-1 px-3.5 py-2 rounded-lg sp-input text-sm"
            />
            <button
              type="button"
              onClick={handleAddCert}
              className="px-4 py-2 rounded-lg sp-btn-secondary text-xs font-semibold flex items-center gap-1.5 whitespace-nowrap shrink-0"
            >
              <Plus className="w-3.5 h-3.5 text-sky-400" />
              <span>Add</span>
            </button>
          </div>
          {form.certifications.length === 0 ? (
            <div className="text-xs text-slate-400">No certifications added yet.</div>
          ) : (
            <div className="divide-y divide-slate-800/80">
              {form.certifications.map((cert, idx) => (
                <div key={`${cert}-${idx}`} className="py-2.5 flex items-center justify-between text-sm">
                  <span className="text-slate-200">{cert}</span>
                  <button
                    type="button"
                    aria-label={`Remove ${cert}`}
                    onClick={() => handleRemoveCert(idx)}
                    className="text-slate-500 hover:text-rose-400 p-1 transition-colors"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>

        <div className="rounded-xl sp-card p-6 space-y-4">
          <h3 className="font-display text-base font-semibold text-white">Projects</h3>
          <div className="space-y-2">
            <input
              type="text"
              placeholder="Project title"
              value={newProjTitle}
              onChange={(e) => setNewProjTitle(e.target.value)}
              className="w-full px-3.5 py-2 rounded-lg sp-input text-sm"
            />
            <input
              type="text"
              placeholder="Short description"
              value={newProjDesc}
              onChange={(e) => setNewProjDesc(e.target.value)}
              className="w-full px-3.5 py-2 rounded-lg sp-input text-sm"
            />
            <div className="flex gap-2">
              <input
                type="text"
                placeholder="Tech stack (comma separated: React, SQL)"
                value={newProjStack}
                onChange={(e) => setNewProjStack(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter') {
                    e.preventDefault();
                    handleAddProject();
                  }
                }}
                className="flex-1 px-3.5 py-2 rounded-lg sp-input text-sm"
              />
              <button
                type="button"
                onClick={handleAddProject}
                className="px-4 py-2 rounded-lg sp-btn-secondary text-xs font-semibold flex items-center gap-1.5 whitespace-nowrap shrink-0"
              >
                <Plus className="w-3.5 h-3.5 text-sky-400" />
                <span>Add</span>
              </button>
            </div>
          </div>
          {form.projects.length === 0 ? (
            <div className="text-xs text-slate-400">No projects recorded yet.</div>
          ) : (
            <div className="divide-y divide-slate-800/80">
              {form.projects.map((proj) => (
                <div key={proj.id} className="py-3 flex items-start justify-between gap-3">
                  <div className="space-y-0.5">
                    <div className="text-sm font-medium text-white">{proj.title}</div>
                    <div className="text-xs text-slate-400">{proj.description}</div>
                    {proj.techStack.length > 0 && (
                      <div className="text-xs text-sky-400 font-mono">
                        {proj.techStack.join(' · ')}
                      </div>
                    )}
                  </div>
                  <button
                    type="button"
                    aria-label={`Remove ${proj.title}`}
                    onClick={() => handleRemoveProject(proj.id)}
                    className="text-slate-500 hover:text-rose-400 p-1 shrink-0 transition-colors"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>
      </section>
    </form>
  );
}
