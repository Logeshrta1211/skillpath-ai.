import React from 'react';
import { CheckCircle2, Circle, Clock, ExternalLink, FileCheck2, RefreshCw } from 'lucide-react';
import { useApp } from '../context/AppContext.tsx';
import type { TaskStatus } from '../shared/types.ts';

export function RoadmapPage() {
  const {
    profile,
    roadmap,
    updateStageStatus,
    setCurrentPage,
    runOrchestrationNow,
    isOrchestrating,
  } = useApp();

  if (!profile || !roadmap) {
    return (
      <div className="rounded-xl sp-card p-8 text-center space-y-4">
        <div className="font-display text-lg font-semibold text-white">No Roadmap Generated Yet</div>
        <p className="text-sm text-slate-400">
          Run the AI Orchestrator to build a personalized learning roadmap from your skill gaps.
        </p>
        <button
          type="button"
          onClick={() => runOrchestrationNow()}
          className="px-4 py-2 rounded-lg text-xs font-semibold sp-btn-primary"
        >
          Generate Roadmap
        </button>
      </div>
    );
  }

  const completedCount = roadmap.stages.filter((s) => s.status === 'completed').length;

  const nextStatus = (current: TaskStatus): TaskStatus => {
    if (current === 'pending') return 'in_progress';
    if (current === 'in_progress') return 'completed';
    return 'pending';
  };

  return (
    <div className="space-y-8">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="font-display text-2xl font-bold text-white">
            Personalized Learning Roadmap
          </h2>
          <p className="text-sm text-slate-400 tabular-nums">
            {profile.careerGoal} · {completedCount} of {roadmap.stages.length} stages completed ·{' '}
            {profile.learningPreferences.weeklyHours} hrs/week pace
          </p>
        </div>
        <button
          type="button"
          disabled={isOrchestrating}
          onClick={() => runOrchestrationNow()}
          className="px-4 py-2.5 rounded-lg text-xs font-semibold sp-btn-primary disabled:opacity-50 flex items-center gap-2 whitespace-nowrap shrink-0"
        >
          <RefreshCw className={`w-3.5 h-3.5 ${isOrchestrating ? 'animate-spin' : ''}`} />
          <span>{isOrchestrating ? 'Adapting...' : 'Regenerate Roadmap'}</span>
        </button>
      </div>

      {/* Adaptive Engine Reason Banner */}
      <section className="rounded-xl sp-card-accent p-6 space-y-2">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <span className="text-xs font-semibold text-sky-300 uppercase tracking-wider">
            Adaptive Mode: {roadmap.adaptiveMode.replace('_', ' ')}
          </span>
          <span className="text-xs text-slate-400 tabular-nums">
            Thresholds: Recovery &lt; {profile.adaptiveConfig.recoveryThreshold}% · Progression &ge;{' '}
            {profile.adaptiveConfig.progressionThreshold}%
          </span>
        </div>
        <div className="text-sm font-medium text-white">{roadmap.adaptationReason}</div>
        <p className="text-xs text-slate-400 leading-relaxed">{roadmap.summary}</p>
      </section>

      {/* Stages */}
      <section className="space-y-4">
        {roadmap.stages.map((stage) => {
          const isDone = stage.status === 'completed';
          const isActive = stage.status === 'in_progress';
          return (
            <div
              key={stage.stageId}
              className={`rounded-xl sp-card p-6 space-y-5 ${
                isDone
                  ? 'border-emerald-500/40'
                  : stage.priorityTag === 'Recovery Revision'
                    ? 'border-rose-500/45'
                    : stage.priorityTag === 'Advanced Progression'
                      ? 'border-sky-400/45'
                      : ''
              }`}
            >
              <div className="flex flex-col md:flex-row md:items-start justify-between gap-4">
                <div className="space-y-1.5">
                  <div className="text-xs font-medium text-slate-400">
                    Stage {stage.order} · {stage.skillName} ·{' '}
                    <span
                      className={
                        stage.priorityTag === 'Recovery Revision'
                          ? 'text-rose-400'
                          : stage.priorityTag === 'Advanced Progression'
                            ? 'text-emerald-400'
                            : 'text-sky-400'
                      }
                    >
                      {stage.priorityTag}
                    </span>{' '}
                    · <span className="font-mono tabular-nums">{stage.estimatedDurationLabel}</span>
                  </div>
                  <h3 className="font-display text-lg font-semibold text-white">
                    {stage.learningObjective}
                  </h3>
                  {stage.focusTopics && stage.focusTopics.length > 0 && (
                    <div className="text-xs text-amber-300">
                      Targeted Weak Topics: {stage.focusTopics.join(' · ')}
                    </div>
                  )}
                </div>

                <div className="flex items-center gap-2 shrink-0">
                  <button
                    type="button"
                    onClick={() => updateStageStatus(stage.stageId, nextStatus(stage.status))}
                    className={`px-3.5 py-2 rounded-lg text-xs font-semibold border transition-colors flex items-center gap-2 whitespace-nowrap ${
                      isDone
                        ? 'bg-emerald-950/60 border-emerald-500/40 text-emerald-300'
                        : isActive
                          ? 'bg-sky-950/60 border-sky-400/50 text-sky-200'
                          : 'sp-btn-secondary'
                    }`}
                  >
                    {isDone ? (
                      <CheckCircle2 className="w-3.5 h-3.5" />
                    ) : isActive ? (
                      <Clock className="w-3.5 h-3.5" />
                    ) : (
                      <Circle className="w-3.5 h-3.5" />
                    )}
                    <span>
                      {isDone ? 'Completed' : isActive ? 'In Progress' : 'Mark In Progress'}
                    </span>
                  </button>
                </div>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 pt-3 border-t border-slate-800/80">
                <div className="lg:col-span-5 space-y-2">
                  <div className="text-xs font-semibold text-slate-300">Learning Activities</div>
                  <ul className="space-y-1.5 text-sm text-slate-300 list-disc list-inside">
                    {stage.activities.map((act, idx) => (
                      <li key={idx} className="leading-relaxed">
                        {act}
                      </li>
                    ))}
                  </ul>
                  <div className="pt-2 text-xs text-slate-300">
                    <span className="font-semibold text-sky-300">Practical Exercise: </span>
                    {stage.practicalExercise}
                  </div>
                </div>

                <div className="lg:col-span-4 space-y-2">
                  <div className="text-xs font-semibold text-slate-300">Verified Free Resources</div>
                  {stage.resources.length === 0 ? (
                    <div className="text-xs text-slate-400">Use Learning Resources catalog for drills.</div>
                  ) : (
                    <div className="space-y-2">
                      {stage.resources.map((res) => (
                        <a
                          key={res.resourceId}
                          href={res.url}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="block p-2.5 rounded-lg sp-inset hover:border-sky-400/60 transition-colors"
                        >
                          <div className="flex items-center justify-between gap-2 text-xs font-medium text-sky-300">
                            <span className="truncate">{res.title}</span>
                            <ExternalLink className="w-3.5 h-3.5 shrink-0" />
                          </div>
                          <div className="text-xs text-slate-400 mt-0.5 tabular-nums">
                            {res.platform} · {res.level} · {res.estimatedHours}h
                          </div>
                        </a>
                      ))}
                    </div>
                  )}
                </div>

                <div className="lg:col-span-3 flex flex-col justify-between gap-3 sp-inset rounded-lg p-4">
                  <div className="space-y-1">
                    <div className="text-xs text-slate-400">Stage Checkpoint</div>
                    <div className="text-sm font-semibold text-white">{stage.assessmentTitle}</div>
                  </div>
                  <button
                    type="button"
                    onClick={() => setCurrentPage('assessments')}
                    className="w-full py-2 px-3 rounded-lg text-xs font-semibold sp-btn-primary flex items-center justify-center gap-1.5 whitespace-nowrap"
                  >
                    <FileCheck2 className="w-3.5 h-3.5" />
                    <span>Open Assessment</span>
                  </button>
                </div>
              </div>
            </div>
          );
        })}
      </section>
    </div>
  );
}
