/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { AppProvider, useApp } from './context/AppContext.tsx';
import { Layout } from './components/Layout.tsx';
import { SkillPath3DBackground } from './components/SkillPath3DBackground.tsx';
import { LandingPage } from './pages/LandingPage.tsx';
import { AuthPage } from './pages/AuthPage.tsx';
import { DashboardPage } from './pages/DashboardPage.tsx';
import { ProfilePage } from './pages/ProfilePage.tsx';
import { SkillAnalysisPage } from './pages/SkillAnalysisPage.tsx';
import { CareerMatchingPage } from './pages/CareerMatchingPage.tsx';
import { RoadmapPage } from './pages/RoadmapPage.tsx';
import { ResourcesPage } from './pages/ResourcesPage.tsx';
import { AssessmentsPage } from './pages/AssessmentsPage.tsx';
import { ProgressPage } from './pages/ProgressPage.tsx';
import { MentorPage } from './pages/MentorPage.tsx';
import { AgentCenterPage } from './pages/AgentCenterPage.tsx';
import { SettingsPage } from './pages/SettingsPage.tsx';

function AppRouter() {
  const { currentPage, authReady, user, isDemoMode, isLocalSession, roadmap, analysis } = useApp();

  const backgroundIntensity =
    currentPage === 'landing' || currentPage === 'auth' ? 'hero' : 'workspace';

  let content: React.ReactNode;

  if (!authReady) {
    content = (
      <div className="min-h-screen bg-transparent flex items-center justify-center text-sm text-slate-300">
        Initializing SkillPath AI 3D workspace...
      </div>
    );
  } else {
    const isAuthenticatedOrDemo = Boolean(user) || isDemoMode || isLocalSession;

    if (currentPage === 'landing') {
      content = <LandingPage />;
    } else if (currentPage === 'auth' || !isAuthenticatedOrDemo) {
      content = <AuthPage />;
    } else {
      let pageView: React.ReactNode;
      switch (currentPage) {
        case 'dashboard':
          pageView = <DashboardPage />;
          break;
        case 'profile':
          pageView = <ProfilePage />;
          break;
        case 'skills':
          pageView = <SkillAnalysisPage />;
          break;
        case 'careers':
          pageView = <CareerMatchingPage />;
          break;
        case 'roadmap':
          pageView = <RoadmapPage />;
          break;
        case 'resources':
          pageView = <ResourcesPage />;
          break;
        case 'assessments':
          pageView = <AssessmentsPage />;
          break;
        case 'progress':
          pageView = <ProgressPage />;
          break;
        case 'mentor':
          pageView = <MentorPage />;
          break;
        case 'agents':
          pageView = <AgentCenterPage />;
          break;
        case 'settings':
          pageView = <SettingsPage />;
          break;
        default:
          pageView = <DashboardPage />;
      }
      content = <Layout>{pageView}</Layout>;
    }
  }

  return (
    <div className="relative min-h-screen bg-[#03060E]">
      <SkillPath3DBackground
        adaptiveMode={roadmap?.adaptiveMode ?? 'baseline'}
        readinessScore={analysis?.readinessScore ?? 25}
        intensity={backgroundIntensity}
      />
      <div
        className="pointer-events-none fixed inset-0 z-[1]"
        style={{
          background:
            'radial-gradient(ellipse at 18% 15%, rgba(14, 165, 233, 0.075) 0%, transparent 52%), radial-gradient(ellipse at 82% 85%, rgba(37, 99, 235, 0.08) 0%, rgba(3, 6, 14, 0.68) 100%)',
        }}
        aria-hidden="true"
      />
      <div className="relative z-10 min-h-screen">{content}</div>
    </div>
  );
}

export default function App() {
  return (
    <AppProvider>
      <AppRouter />
    </AppProvider>
  );
}
