# SkillPath AI Security Specification

## 1. Data Invariants
1. Every document in all 12 collections is strictly owned by an authenticated, email-verified user (`userId == request.auth.uid`).
2. `learnerProfiles/{userId}` document ID must match `request.auth.uid`, isolating PII (`email`, `name`, `college`) exclusively to the owner.
3. Immutable audit trails (`assessmentAttempts`, `progressRecords`, `agentLogs`, `mentorConversations`) forbid client-side `update` and `delete`.
4. All `createdAt` and `updatedAt` timestamps must match `request.time` on creation/update; `createdAt` and `userId` are immutable once written.
5. Every `allow list` rule evaluates `resource.data.userId == request.auth.uid` directly without `get()` calls or client-delegated filtering.
6. Every document ID and foreign ID (`skillId`, `roadmapId`, `assessmentId`, `runId`) matches `^[a-zA-Z0-9_\-]+$` with length <= 128.
7. Every string and array enforces explicit `.size()` boundaries to prevent resource exhaustion.

## 2. Dirty Dozen Adversarial Payloads (Expected: PERMISSION_DENIED)
1. **Cross-User Profile Read**: User B attempts `get(/learnerProfiles/{userA_uid})` -> DENIED.
2. **Identity Spoofing on Create**: User A writes `/skills/s1` with `userId: userB_uid` -> DENIED.
3. **Ghost Field Injection (Shadow Update)**: User A creates `/learnerProfiles/{userA_uid}` with extra field `isAdmin: true` -> DENIED (`hasOnly` check).
4. **Unverified Email Write**: User with `email_verified: false` attempts to write `/learningRoadmaps/r1` -> DENIED.
5. **Blanket Collection List**: User A lists `/assessmentAttempts` without `where('userId', '==', userA_uid)` -> DENIED.
6. **Immutable Ownership Hijack**: User A updates `/skills/{id}` attempting to change `userId` to `userB_uid` -> DENIED.
7. **Timestamp Forgery**: User A creates `/agentLogs/l1` with forged past `createdAt` timestamp != `request.time` -> DENIED.
8. **Path ID Poisoning**: User A writes `/skills/${'a'.repeat(500)}` (>128 chars) or invalid characters `../admin` -> DENIED (`isValidId`).
9. **Oversized String Exhaustion**: User A writes `/mentorConversations/m1` with `content` > 4000 chars -> DENIED.
10. **Immutable Log Tampering**: User A attempts to `update` or `delete` `/assessmentAttempts/{id}` or `/agentLogs/{id}` -> DENIED.
11. **Invalid Enum Injection**: User A writes `/learningTasks/t1` with `status: "hacked"` -> DENIED.
12. **Out-of-Range Proficiency**: User A writes `/skills/s1` with `proficiency: 99` (outside 0..4) -> DENIED.
